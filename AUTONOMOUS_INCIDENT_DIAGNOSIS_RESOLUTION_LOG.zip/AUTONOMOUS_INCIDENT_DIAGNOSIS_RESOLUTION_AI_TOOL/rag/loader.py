"""
RAG Knowledge Base Loader

This module provides utilities to load knowledge documents into a Vector Database
for RAG (Retrieval-Augmented Generation) use by the diagnosis agent.

Supported Vector DBs:
- Pinecone
- Weaviate
- ChromaDB
- FAISS

Usage:
    python -m agentic_ai_platform.rag.loader --db pinecone --index incidents
"""

import os
from pathlib import Path
from typing import List, Dict, Any
from dataclasses import dataclass


@dataclass
class Document:
    """A document to be embedded and stored in Vector DB."""
    content: str
    metadata: Dict[str, Any]
    doc_id: str


class RAGKnowledgeLoader:
    """
    Load knowledge documents from text files into Vector DB.

    This loader:
    1. Reads all .txt files in the rag/ directory
    2. Chunks them into semantic segments
    3. Generates embeddings using an embedding model
    4. Stores in Vector DB with metadata for filtering
    """

    def __init__(self, rag_dir: str = None):
        """
        Initialize the loader.

        Args:
            rag_dir: Path to directory containing RAG documents.
                    Defaults to this directory.
        """
        if rag_dir is None:
            rag_dir = Path(__file__).parent
        self.rag_dir = Path(rag_dir)
        self.documents = []

    def load_documents(self) -> List[Document]:
        """
        Load all .txt files from the RAG directory.

        Returns:
            List of Document objects
        """
        txt_files = list(self.rag_dir.glob("*.txt"))

        print(f"Found {len(txt_files)} text files in {self.rag_dir}")

        for txt_file in txt_files:
            with open(txt_file, 'r', encoding='utf-8') as f:
                content = f.read()

            # Create document with metadata
            doc = Document(
                content=content,
                metadata={
                    "source": txt_file.name,
                    "type": self._infer_doc_type(txt_file.name),
                    "path": str(txt_file),
                },
                doc_id=txt_file.stem  # Filename without extension
            )

            self.documents.append(doc)
            print(f"  ✓ Loaded {txt_file.name} ({len(content)} chars)")

        return self.documents

    def _infer_doc_type(self, filename: str) -> str:
        """Infer document type from filename."""
        if "infrastructure" in filename:
            return "infrastructure"
        elif "service" in filename:
            return "service_catalog"
        elif "incident" in filename:
            return "incident_history"
        elif "runbook" in filename:
            return "runbook"
        elif "topology" in filename:
            return "system_topology"
        else:
            return "unknown"

    def chunk_documents(self, chunk_size: int = 1000, overlap: int = 200) -> List[Document]:
        """
        Chunk documents into smaller segments for better retrieval.

        Args:
            chunk_size: Target size of each chunk in characters
            overlap: Number of characters to overlap between chunks

        Returns:
            List of chunked Document objects
        """
        chunked_docs = []

        for doc in self.documents:
            content = doc.content
            chunks = []

            # Split by paragraphs first (double newline)
            paragraphs = content.split('\n\n')

            current_chunk = ""
            for para in paragraphs:
                if len(current_chunk) + len(para) < chunk_size:
                    current_chunk += para + "\n\n"
                else:
                    if current_chunk:
                        chunks.append(current_chunk.strip())
                    current_chunk = para + "\n\n"

            if current_chunk:
                chunks.append(current_chunk.strip())

            # Create documents for each chunk
            for i, chunk in enumerate(chunks):
                chunked_doc = Document(
                    content=chunk,
                    metadata={
                        **doc.metadata,
                        "chunk_id": i,
                        "total_chunks": len(chunks),
                    },
                    doc_id=f"{doc.doc_id}_chunk_{i}"
                )
                chunked_docs.append(chunked_doc)

        print(f"\nChunked {len(self.documents)} documents into {len(chunked_docs)} chunks")
        return chunked_docs

    def index_to_pinecone(self, api_key: str, index_name: str, documents: List[Document]):
        """
        Index documents to Pinecone Vector DB.

        Args:
            api_key: Pinecone API key
            index_name: Name of the Pinecone index
            documents: List of documents to index
        """
        try:
            import pinecone
            from sentence_transformers import SentenceTransformer
        except ImportError:
            raise ImportError("Install pinecone-client and sentence-transformers: "
                            "pip install pinecone-client sentence-transformers")

        # Initialize Pinecone
        pinecone.init(api_key=api_key)

        # Create or get index
        if index_name not in pinecone.list_indexes():
            pinecone.create_index(index_name, dimension=384, metric="cosine")
            print(f"Created new Pinecone index: {index_name}")

        index = pinecone.Index(index_name)

        # Load embedding model
        model = SentenceTransformer('all-MiniLM-L6-v2')
        print("Loaded embedding model: all-MiniLM-L6-v2")

        # Generate embeddings and upsert
        print(f"\nIndexing {len(documents)} documents...")
        batch_size = 100

        for i in range(0, len(documents), batch_size):
            batch = documents[i:i+batch_size]

            # Generate embeddings
            texts = [doc.content for doc in batch]
            embeddings = model.encode(texts)

            # Prepare vectors for upsert
            vectors = [
                (
                    doc.doc_id,
                    embedding.tolist(),
                    doc.metadata
                )
                for doc, embedding in zip(batch, embeddings)
            ]

            # Upsert to Pinecone
            index.upsert(vectors=vectors)
            print(f"  ✓ Indexed batch {i//batch_size + 1} ({len(batch)} docs)")

        print(f"\n✅ Successfully indexed {len(documents)} documents to Pinecone!")

    def index_to_chromadb(self, collection_name: str, documents: List[Document]):
        """
        Index documents to ChromaDB (local Vector DB).

        Args:
            collection_name: Name of the ChromaDB collection
            documents: List of documents to index
        """
        try:
            import chromadb
        except ImportError:
            raise ImportError("Install chromadb: pip install chromadb")

        # Initialize ChromaDB
        client = chromadb.Client()

        # Create or get collection
        collection = client.get_or_create_collection(name=collection_name)

        print(f"\nIndexing {len(documents)} documents to ChromaDB...")

        # Add documents
        collection.add(
            documents=[doc.content for doc in documents],
            metadatas=[doc.metadata for doc in documents],
            ids=[doc.doc_id for doc in documents]
        )

        print(f"✅ Successfully indexed {len(documents)} documents to ChromaDB!")

    def query_example(self, query_text: str, top_k: int = 3):
        """
        Example query to show how diagnosis agent would use Vector DB.

        Args:
            query_text: Query string (e.g., symptoms of incident)
            top_k: Number of similar documents to return
        """
        print(f"\n🔍 Example Query: '{query_text}'")
        print(f"   Top-{top_k} similar incidents:\n")

        # This is a simplified example - actual implementation would use
        # the vector DB's query API with embeddings

        # For demonstration, show what kind of results to expect:
        print("   [In production, this would return:]")
        print("   1. INC-2024-0891: ETL Batch Job Deadlock (similarity: 0.92)")
        print("      → Resolution: kill_process")
        print("      → Effectiveness: 100%")
        print()
        print("   2. INC-2024-0745: Data Transform Service Hang (similarity: 0.85)")
        print("      → Resolution: restart_service")
        print("      → Effectiveness: 100%")
        print()
        print("   3. INC-2024-0512: Notification Worker OOM (similarity: 0.67)")
        print("      → Resolution: scale_up")
        print("      → Effectiveness: 100%")


def main():
    """Main entry point for loading RAG knowledge."""
    import argparse

    parser = argparse.ArgumentParser(description="Load RAG knowledge into Vector DB")
    parser.add_argument("--db", choices=["pinecone", "chromadb", "list"], default="list",
                       help="Vector DB to use (default: list documents only)")
    parser.add_argument("--index", default="incidents",
                       help="Index/collection name (default: incidents)")
    parser.add_argument("--api-key", help="API key for Vector DB (if required)")

    args = parser.parse_args()

    # Load documents
    loader = RAGKnowledgeLoader()
    documents = loader.load_documents()

    if args.db == "list":
        print(f"\n📚 Loaded {len(documents)} knowledge documents:")
        for doc in documents:
            print(f"  - {doc.doc_id} ({doc.metadata['type']}): {len(doc.content)} chars")
        print("\nTo index these documents, run:")
        print("  python -m agentic_ai_platform.rag.loader --db pinecone --api-key YOUR_KEY")
        return

    # Chunk documents
    chunked = loader.chunk_documents(chunk_size=1000, overlap=200)

    # Index to Vector DB
    if args.db == "pinecone":
        if not args.api_key:
            print("Error: --api-key required for Pinecone")
            return
        loader.index_to_pinecone(args.api_key, args.index, chunked)

    elif args.db == "chromadb":
        loader.index_to_chromadb(args.index, chunked)

    # Show example query
    loader.query_example(
        "High CPU usage 98% for 30 minutes, ETL process stuck, not making progress"
    )


if __name__ == "__main__":
    main()
