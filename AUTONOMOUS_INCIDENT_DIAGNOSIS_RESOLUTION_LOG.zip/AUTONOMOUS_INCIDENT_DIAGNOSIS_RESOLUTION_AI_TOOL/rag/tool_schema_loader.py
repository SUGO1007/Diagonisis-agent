"""
Tool Schema Loader - Convert TOOL_REGISTRY to vector DB documents.

Embeds MCP tool schemas (not just docs) so LLMs can:
1. Search for relevant tools by natural language
2. See the exact parameter requirements
3. Generate valid arguments matching the schema
"""

import json
from typing import List, Dict, Any
import importlib.util
from pathlib import Path


def load_tool_registry() -> Dict[str, Any]:
    """Load the TOOL_REGISTRY from incident_mcp_server."""
    mcp_server_path = Path(__file__).parent.parent / "mcp" / "incident_mcp_server.py"
    spec = importlib.util.spec_from_file_location("incident_mcp_server", mcp_server_path)
    mcp_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mcp_module)
    return mcp_module.TOOL_REGISTRY


def tool_registry_to_documents() -> List[Dict[str, Any]]:
    """
    Convert TOOL_REGISTRY to vector DB documents.

    Each tool becomes a document with:
    - Full schema (parameters, types, defaults)
    - Description
    - When to use it
    - Example usage
    - Structured metadata for filtering

    Returns:
        List of documents ready for ChromaDB
    """
    registry = load_tool_registry()
    documents = []

    for tool_name, tool_info in registry.items():
        # Build comprehensive tool schema document
        doc_text = f"""
## Tool: {tool_name}

**Description**: {tool_info.get('description', 'N/A')}

**Parameters**:
"""
        params = tool_info.get('parameters', {})
        for param_name, param_info in params.items():
            param_type = param_info.get('type', 'string')
            required = param_info.get('required', False)
            description = param_info.get('description', '')
            default = param_info.get('default', 'None')

            required_str = "(REQUIRED)" if required else "(optional)"
            doc_text += f"  - {param_name} ({param_type}) {required_str}"
            if description:
                doc_text += f": {description}"
            if default != 'None':
                doc_text += f" [default: {default}]"
            doc_text += "\n"

        # Add structured schema as JSON
        doc_text += f"\n**Schema (JSON)**:\n"
        doc_text += "```json\n"
        doc_text += json.dumps({
            "name": tool_name,
            "parameters": params,
        }, indent=2)
        doc_text += "\n```\n"

        # Add example usage based on tool type
        doc_text += f"\n**Examples**:\n"
        if "query_metrics" in tool_name:
            doc_text += "  query_metrics(host='prod-web-07', metric='cpu_percent')\n"
        elif "process_list" in tool_name:
            doc_text += "  get_process_list(host='prod-web-07')\n"
        elif "kill_process" in tool_name:
            doc_text += "  kill_process(host='prod-web-07', pid=5510, signal='SIGTERM')\n"
        elif "logs" in tool_name:
            doc_text += "  get_application_logs(host='prod-web-07', level='ERROR', last_n=10)\n"
        elif "metadata" in tool_name:
            doc_text += "  get_server_metadata(hostname='prod-web-07')\n"
        elif "service_info" in tool_name:
            doc_text += "  get_service_info(service_name='data-transform')\n"
        elif "dependencies" in tool_name:
            doc_text += "  get_dependencies(service_name='data-transform')\n"
        elif "health" in tool_name:
            doc_text += "  check_service_health(service_name='data-transform')\n"

        documents.append({
            "id": f"tool_{tool_name}",
            "text": doc_text.strip(),
            "metadata": {
                "doc_type": "tool_schema",
                "tool_name": tool_name,
                "source_file": "mcp/incident_mcp_server.py",
                "title": f"Tool: {tool_name}",
                # Convert to comma-separated strings for ChromaDB (no empty lists)
                "required_params": ",".join([
                    p for p, info in params.items()
                    if info.get('required', False)
                ]) or "none",
                "optional_params": ",".join([
                    p for p, info in params.items()
                    if not info.get('required', False)
                ]) or "none",
            },
        })

    return documents


def validate_tool_arguments(tool_name: str, arguments: Dict[str, Any]) -> tuple[bool, str]:
    """
    Validate that provided arguments match the tool schema.

    Args:
        tool_name: Name of the tool to call
        arguments: Arguments provided by LLM

    Returns:
        (is_valid, error_message)
    """
    registry = load_tool_registry()

    # Find the tool
    tool_info = registry.get(tool_name)
    if not tool_info:
        return False, f"Unknown tool: {tool_name}"

    params = tool_info.get('parameters', {})

    # Check all required parameters are present
    required_params = {
        p for p, info in params.items()
        if info.get('required', False)
    }
    provided_params = set(arguments.keys())
    missing = required_params - provided_params

    if missing:
        return False, f"Missing required parameters: {', '.join(missing)}"

    # Check parameter types (basic type checking)
    for param_name, param_value in arguments.items():
        if param_name not in params:
            return False, f"Unknown parameter: {param_name}"

        expected_type = params[param_name].get('type', 'string')
        if expected_type == 'number' and not isinstance(param_value, (int, float)):
            try:
                float(param_value)  # Allow string numbers
            except (ValueError, TypeError):
                return False, f"Parameter {param_name} must be a number, got {type(param_value)}"

    return True, ""


def get_tool_schema(tool_name: str) -> Dict[str, Any]:
    """Get the full schema for a specific tool."""
    registry = load_tool_registry()
    if tool_name not in registry:
        return {}

    tool_info = registry[tool_name]
    params = tool_info.get('parameters', {})

    return {
        "tool_name": tool_name,
        "description": tool_info.get('description', ''),
        "parameters": {
            name: {
                "type": info.get('type', 'string'),
                "required": info.get('required', False),
                "description": info.get('description', ''),
                "default": info.get('default', None),
            }
            for name, info in params.items()
        },
    }


if __name__ == "__main__":
    # Test: convert and print first tool
    docs = tool_registry_to_documents()
    print(f"Generated {len(docs)} tool schema documents\n")
    if docs:
        print("First tool:")
        print(docs[0]['text'][:500])
        print("\nMetadata:")
        print(docs[0]['metadata'])
