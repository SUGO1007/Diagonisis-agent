# RAG Knowledge Base

This directory contains operational knowledge in text format for Vector DB ingestion.

## Purpose

The diagnosis agent uses **RAG (Retrieval-Augmented Generation)** to:
1. Query similar historical incidents from Vector DB
2. Find relevant patterns and resolutions
3. Improve diagnosis accuracy with historical context
4. Generate evidence-based recommendations

## Knowledge Documents

### 📊 infrastructure_inventory.txt
**Content**: Server fleet details, metrics, current status
- 5 production servers (prod-web-07, prod-web-03, prod-db-01, prod-cache-02, prod-batch-01)
- CPU, memory, disk, network metrics
- Current issues and health status
- Uptime and capacity information

**Use Case**: Understand current infrastructure state, identify which servers are affected

### 🏢 service_catalog.txt
**Content**: Service definitions, tiers, dependencies, policies
- 5 production services (billing-api, data-transform, user-service, notification-worker, redis-cache)
- Service tier classification (CRITICAL, STANDARD, BATCH)
- Owner teams and runbook IDs
- Auto-remediation policies
- Known issues per service

**Use Case**: Understand service context, determine remediation policies, identify dependencies

### 📜 incident_history.txt
**Content**: Historical incidents with symptoms, root causes, resolutions
- 6 detailed incident reports (INC-2024-0891, INC-2024-0745, etc.)
- Symptoms, root causes, resolutions
- Time to resolve, effectiveness scores
- Recurrence patterns
- Similar incident tags

**Use Case**: Find similar past incidents, learn from previous resolutions, calculate confidence

### 📖 runbooks.txt
**Content**: Operational procedures for each service
- 5 runbooks (RB-001 through RB-005)
- Trigger conditions for each runbook
- Diagnostic steps
- Remediation actions with decision trees
- Pre-flight and post-flight checks
- Rollback procedures

**Use Case**: Follow established procedures, execute remediation safely, understand constraints

### 🗺️ system_topology.txt
**Content**: System architecture, dependencies, blast radius
- Service dependency graph
- Network topology
- Failure impact analysis
- Communication patterns
- Monitoring integration

**Use Case**: Understand blast radius, identify cascading failures, analyze dependencies

## Vector DB Integration

### Loading Knowledge

```bash
# List available documents
python -m agentic_ai_platform.rag.loader --db list

# Index to Pinecone
python -m agentic_ai_platform.rag.loader --db pinecone --api-key YOUR_API_KEY --index incidents

# Index to ChromaDB (local)
python -m agentic_ai_platform.rag.loader --db chromadb --index incidents
```

### Query Example

```python
from agentic_ai_platform.rag.loader import RAGKnowledgeLoader

loader = RAGKnowledgeLoader()
loader.query_example(
    "High CPU 98% for 30 minutes, ETL process stuck, partition reprocessing",
    top_k=3
)
```

**Expected Results**:
1. INC-2024-0891: ETL Batch Job Deadlock (similarity: 0.92)
2. INC-2024-0745: Data Transform Service Hang (similarity: 0.85)
3. Similar incident patterns...

## How Diagnosis Agent Uses RAG

### Step 1: Embed Query
```python
query = "Alert: HighCPU on prod-batch-01, data-transform service, 98% for 30 minutes"
query_embedding = embedding_model.encode(query)
```

### Step 2: Vector Search
```python
similar_incidents = vector_db.query(
    vector=query_embedding,
    top_k=3,
    filter={"type": "incident_history"}
)
```

### Step 3: Analyze Results
```python
for incident in similar_incidents:
    print(f"Similarity: {incident.score}")
    print(f"Root Cause: {incident.metadata['root_cause']}")
    print(f"Resolution: {incident.metadata['resolution']}")
    print(f"Effectiveness: {incident.metadata['effectiveness']}")
```

### Step 4: Calculate Confidence
```python
confidence = calculate_confidence(
    similarity_scores=[i.score for i in similar_incidents],
    historical_effectiveness=[i.metadata['effectiveness'] for i in similar_incidents],
    pattern_consistency=check_pattern_consistency(similar_incidents)
)
```

## Document Format Guidelines

### Writing Knowledge Documents

**Good Examples**:
```
# ETL Batch Job Deadlock
Symptoms: CPU at 98% for 30+ minutes, process stuck in infinite loop
Root Cause: ETL deadlock in data transformation logic
Resolution: Kill stuck process (kill -9 PID)
Effectiveness: 100%
Similar To: HighCPU + ETL service + stuck process
```

**Why Good**: Clear, semantic, includes keywords, describes relationships

**Bad Examples**:
```
Server down. Fixed it. Works now.
```

**Why Bad**: No semantic content, no keywords, no context, not useful for RAG

### Best Practices

1. **Use semantic language**: Write in natural language with domain terminology
2. **Include keywords**: "HighCPU", "deadlock", "stuck process", "kill -9"
3. **Provide context**: Service name, server, duration, severity
4. **Link related concepts**: "Similar To: X + Y + Z"
5. **Include outcomes**: Resolution steps, effectiveness, time to resolve
6. **Structure consistently**: Use headings, bullet points, clear sections

## Maintenance

### Adding New Knowledge

1. Create new .txt file in this directory
2. Follow existing format (clear sections, semantic content)
3. Re-index to Vector DB:
   ```bash
   python -m agentic_ai_platform.rag.loader --db chromadb --index incidents
   ```
4. Test query to verify it's findable

### Updating Existing Knowledge

1. Edit the .txt file
2. Re-index to Vector DB (full re-index or incremental update)
3. Verify changes with test queries

### Knowledge Quality

**Monitor**:
- Diagnosis confidence scores (should improve over time)
- False positive rate (incorrect diagnoses)
- Missing incidents (queries with no results)

**Improve**:
- Add more incident history as it occurs
- Enrich documents with more keywords
- Update runbooks with learnings
- Add edge cases and exceptions

## Statistics

- **Total Documents**: 5 text files
- **Total Size**: ~25KB
- **Estimated Chunks**: ~40 (with 1000 char chunks, 200 char overlap)
- **Coverage**:
  - 5 servers documented
  - 5 services documented
  - 6 historical incidents
  - 5 operational runbooks
  - Complete system topology

## Integration with Agents

### DiagnosisAgent
```python
# Query Vector DB for similar incidents
similar = vector_db.query(
    alert_description,
    top_k=3,
    filter={"type": "incident_history"}
)

# Analyze patterns
root_cause = analyze_patterns(similar)
confidence = calculate_confidence(similar)
```

### InformationGatheringAgent
```python
# Find runbooks for gathering info
runbooks = vector_db.query(
    f"diagnostic steps for {service_name}",
    top_k=1,
    filter={"type": "runbook"}
)

# Extract questions from runbook
questions = extract_diagnostic_steps(runbooks[0])
```

### RemediationAgent
```python
# Find remediation procedures
procedures = vector_db.query(
    f"remediation for {root_cause}",
    top_k=1,
    filter={"type": "runbook"}
)

# Execute with safety checks
execute_with_safety(procedures[0])
```

## Next Steps

1. **Load to Vector DB**: Run loader script to index documents
2. **Test Queries**: Verify semantic search works as expected
3. **Integrate with Agents**: Update diagnosis_agent.py to use Vector DB
4. **Monitor Quality**: Track diagnosis accuracy and confidence
5. **Iterate**: Add more knowledge as you learn

---

**Last Updated**: 2026-06-15
**Documents**: 5
**Status**: ✅ Ready for Vector DB ingestion
