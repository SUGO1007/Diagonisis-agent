"""
Vector Store - ChromaDB + Sentence-Transformers for RAG.

Provides semantic search over the knowledge base documents:
- Incident history (past incidents and resolutions)
- Runbooks (operational procedures)
- Service catalog (service tiers, owners, dependencies)
- Infrastructure inventory (server specs and status)
- System topology (dependency graphs)
- Tool knowledge (MCP API documentation)

Usage:
    from rag.vector_store import RAGVectorStore

    store = RAGVectorStore()
    store.load_and_index()  # Load all docs, chunk, embed, store in ChromaDB

    results = store.search("high CPU ETL batch deadlock", top_k=5)
"""

import os
import hashlib
from pathlib import Path
from typing import List, Dict, Any, Optional

import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer


# Default embedding model - lightweight and fast
DEFAULT_EMBEDDING_MODEL = "all-MiniLM-L6-v2"
DEFAULT_COLLECTION_NAME = "incident_knowledge"
DEFAULT_PERSIST_DIR = str(Path(__file__).parent / ".chromadb")


class RAGVectorStore:
    """
    ChromaDB-backed vector store for incident response knowledge.

    Loads knowledge documents, chunks them semantically, embeds with
    sentence-transformers, and provides cosine similarity search.
    """

    def __init__(
        self,
        rag_dir: str = None,
        embedding_model: str = DEFAULT_EMBEDDING_MODEL,
        collection_name: str = DEFAULT_COLLECTION_NAME,
        persist_dir: str = DEFAULT_PERSIST_DIR,
    ):
        """
        Initialize the vector store.

        Args:
            rag_dir: Directory containing .txt knowledge files
            embedding_model: Sentence-transformers model name
            collection_name: ChromaDB collection name
            persist_dir: Directory to persist ChromaDB data
        """
        self.rag_dir = Path(rag_dir) if rag_dir else Path(__file__).parent
        self.embedding_model_name = embedding_model
        self.collection_name = collection_name
        self.persist_dir = persist_dir

        # Initialize embedding model
        self._embedder: Optional[SentenceTransformer] = None

        # Initialize ChromaDB client (persistent)
        self._client = chromadb.Client(Settings(
            persist_directory=self.persist_dir,
            anonymized_telemetry=False,
        ))

        self._collection = None
        self._loaded = False

    @property
    def embedder(self) -> SentenceTransformer:
        """Lazy-load embedding model."""
        if self._embedder is None:
            self._embedder = SentenceTransformer(self.embedding_model_name)
        return self._embedder

    @property
    def collection(self):
        """Get or create ChromaDB collection."""
        if self._collection is None:
            self._collection = self._client.get_or_create_collection(
                name=self.collection_name,
                metadata={"hnsw:space": "cosine"},
            )
        return self._collection

    def load_and_index(self, force_reload: bool = False) -> Dict[str, Any]:
        """
        Load all knowledge files, chunk them, and index into ChromaDB.

        Args:
            force_reload: If True, delete existing collection and reload

        Returns:
            Stats about the indexing operation
        """
        if self._loaded and not force_reload:
            count = self.collection.count()
            if count > 0:
                return {"status": "already_loaded", "total_chunks": count}

        if force_reload:
            try:
                self._client.delete_collection(self.collection_name)
            except Exception:
                pass
            self._collection = None

        # Discover knowledge files
        txt_files = sorted(self.rag_dir.glob("*.txt"))
        if not txt_files:
            return {"status": "no_files", "total_chunks": 0}

        all_chunks = []
        all_metadata = []
        all_ids = []

        print(f"[RAG] Loading knowledge base from: {self.rag_dir}")
        print(f"[RAG] Embedding model: {self.embedding_model_name}")

        for txt_file in txt_files:
            with open(txt_file, "r", encoding="utf-8") as f:
                content = f.read()

            doc_type = self._infer_doc_type(txt_file.name)
            chunks = self._chunk_document(content, doc_type, txt_file.name)

            for i, chunk in enumerate(chunks):
                chunk_id = self._generate_chunk_id(txt_file.name, i)
                all_chunks.append(chunk["text"])
                all_metadata.append(chunk["metadata"])
                all_ids.append(chunk_id)

            print(f"   [OK] {txt_file.name}: {len(chunks)} chunks ({len(content)} chars)")

        # Load tool schemas from TOOL_REGISTRY (dynamic, always up-to-date)
        try:
            from .tool_schema_loader import tool_registry_to_documents
            tool_docs = tool_registry_to_documents()
            print(f"\n[RAG] Loading {len(tool_docs)} tool schemas from TOOL_REGISTRY...")

            for tool_doc in tool_docs:
                chunk_id = tool_doc["id"]
                all_chunks.append(tool_doc["text"])
                all_metadata.append(tool_doc["metadata"])
                all_ids.append(chunk_id)

            print(f"   [OK] Tool schemas: {len(tool_docs)} tools indexed")
        except Exception as e:
            print(f"   [WARN] Could not load tool schemas: {e}")

        if not all_chunks:
            return {"status": "no_chunks", "total_chunks": 0}

        # Generate embeddings
        print(f"[RAG] Generating embeddings for {len(all_chunks)} chunks...")
        embeddings = self.embedder.encode(all_chunks, show_progress_bar=False)
        embeddings_list = embeddings.tolist()

        # Add to ChromaDB in batches (ChromaDB has a limit per add)
        batch_size = 100
        for i in range(0, len(all_chunks), batch_size):
            end = min(i + batch_size, len(all_chunks))
            self.collection.add(
                ids=all_ids[i:end],
                documents=all_chunks[i:end],
                embeddings=embeddings_list[i:end],
                metadatas=all_metadata[i:end],
            )

        self._loaded = True
        total = self.collection.count()
        print(f"[RAG] Indexed {total} chunks into ChromaDB (collection: {self.collection_name})")

        return {
            "status": "indexed",
            "total_chunks": total,
            "files_processed": len(txt_files),
            "embedding_model": self.embedding_model_name,
        }

    def search(
        self,
        query: str,
        top_k: int = 5,
        filter_type: str = None,
        min_score: float = 0.0,
    ) -> List[Dict[str, Any]]:
        """
        Semantic search over the knowledge base.

        Args:
            query: Natural language search query
            top_k: Number of results to return
            filter_type: Optional filter by document type
                         (incident_history, runbook, service_catalog,
                          infrastructure, system_topology, tool_knowledge)
            min_score: Minimum similarity score (0-1, higher=more similar)

        Returns:
            List of search results with text, metadata, and similarity score
        """
        if self.collection.count() == 0:
            self.load_and_index()

        # Generate query embedding
        query_embedding = self.embedder.encode([query]).tolist()

        # Build filter
        where_filter = None
        if filter_type:
            where_filter = {"doc_type": filter_type}

        # Query ChromaDB
        results = self.collection.query(
            query_embeddings=query_embedding,
            n_results=top_k,
            where=where_filter,
            include=["documents", "metadatas", "distances"],
        )

        # Process results
        search_results = []
        if results and results["documents"]:
            for i, (doc, meta, dist) in enumerate(zip(
                results["documents"][0],
                results["metadatas"][0],
                results["distances"][0],
            )):
                # ChromaDB cosine distance: 0 = identical, 2 = opposite
                # Convert to similarity score: 1 - (distance/2)
                similarity = 1 - (dist / 2)

                if similarity >= min_score:
                    search_results.append({
                        "text": doc,
                        "metadata": meta,
                        "similarity_score": round(similarity, 4),
                        "rank": i + 1,
                    })

        return search_results

    def search_incidents(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """Search specifically in incident history."""
        return self.search(query, top_k=top_k, filter_type="incident_history")

    def search_runbooks(self, query: str, top_k: int = 3) -> List[Dict[str, Any]]:
        """Search specifically in runbooks."""
        return self.search(query, top_k=top_k, filter_type="runbook")

    def search_tools(self, query: str, top_k: int = 3) -> List[Dict[str, Any]]:
        """Search specifically in tool/API knowledge."""
        return self.search(query, top_k=top_k, filter_type="tool_knowledge")

    def search_services(self, query: str, top_k: int = 3) -> List[Dict[str, Any]]:
        """Search specifically in service catalog."""
        return self.search(query, top_k=top_k, filter_type="service_catalog")

    def search_tool_schemas(self, query: str, top_k: int = 3) -> List[Dict[str, Any]]:
        """
        Search specifically in tool schemas (TOOL_REGISTRY).

        Returns tool definitions with full parameter schemas so LLM can generate valid arguments.
        """
        return self.search(query, top_k=top_k, filter_type="tool_schema")

    def get_tool_schema_and_args(
        self,
        query: str,
        context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Search for relevant tools and prepare for argument generation.

        Args:
            query: What the agent wants to do
            context: Context (host, service, alert, etc.) for filling in arguments

        Returns:
            Dict with tool schema + suggested argument mapping
        """
        # Search for relevant tools
        results = self.search_tool_schemas(query, top_k=1)
        if not results:
            return {"error": "No relevant tools found"}

        best_match = results[0]
        tool_name = best_match["metadata"].get("tool_name", "")

        # Extract schema from the result
        text = best_match["text"]
        # Metadata has comma-separated strings (or "none" for empty)
        required_params_str = best_match["metadata"].get("required_params", "none")
        optional_params_str = best_match["metadata"].get("optional_params", "none")

        # Convert back to lists
        required_params = [p.strip() for p in required_params_str.split(",") if p.strip() and p.strip() != "none"]
        optional_params = [p.strip() for p in optional_params_str.split(",") if p.strip() and p.strip() != "none"]

        # Parse schema from JSON block in the text
        import json
        schema = {"parameters": {}}
        try:
            if "```json" in text:
                json_block = text.split("```json")[1].split("```")[0].strip()
                schema = json.loads(json_block)
        except Exception:
            pass

        # Map context values to parameters
        argument_suggestions = {}
        context_host = context.get("host", "")
        context_service = context.get("service", "")
        context_metric = context.get("metric", "")
        context_level = context.get("level", "ERROR")

        for param in required_params + optional_params:
            param_lower = param.lower()

            # Auto-map common parameter names
            if param_lower in ["host", "hostname"]:
                argument_suggestions[param] = context_host
            elif param_lower in ["service", "service_name"]:
                argument_suggestions[param] = context_service
            elif param_lower in ["metric", "metric_name"]:
                argument_suggestions[param] = context_metric or "cpu_percent"
            elif param_lower in ["level", "log_level"]:
                argument_suggestions[param] = context_level

        return {
            "tool_name": tool_name,
            "similarity_score": best_match["similarity_score"],
            "schema": schema,
            "required_params": required_params,
            "optional_params": optional_params,
            "suggested_arguments": argument_suggestions,
            "schema_text": text,
        }

    def get_stats(self) -> Dict[str, Any]:
        """Get vector store statistics."""
        count = self.collection.count()
        return {
            "total_chunks": count,
            "collection_name": self.collection_name,
            "embedding_model": self.embedding_model_name,
            "persist_dir": self.persist_dir,
            "loaded": self._loaded,
        }

    # ===================================================================
    # CHUNKING LOGIC
    # ===================================================================

    def _chunk_document(self, content: str, doc_type: str, filename: str) -> List[Dict]:
        """
        Chunk a document into semantic segments based on document type.

        Different document types have different natural boundaries:
        - incident_history: Split by "---" between incidents
        - runbooks: Split by "## RB-" headers
        - service_catalog: Split by "## " service headers
        - infrastructure: Split by "## " server headers
        - tool_knowledge: Split by "## Tool:" headers
        - system_topology: Keep as larger chunks with paragraph breaks
        """
        chunks = []

        if doc_type == "incident_history":
            chunks = self._chunk_by_separator(content, "\n---\n", doc_type, filename)
        elif doc_type == "runbook":
            chunks = self._chunk_by_header(content, "## RB-", doc_type, filename)
        elif doc_type == "service_catalog":
            chunks = self._chunk_by_header(content, "## ", doc_type, filename)
        elif doc_type == "infrastructure":
            chunks = self._chunk_by_header(content, "## ", doc_type, filename)
        elif doc_type == "tool_knowledge":
            chunks = self._chunk_by_separator(content, "\n---\n", doc_type, filename)
        elif doc_type == "system_topology":
            chunks = self._chunk_by_paragraphs(content, doc_type, filename, max_chunk_size=1000)
        else:
            chunks = self._chunk_by_paragraphs(content, doc_type, filename, max_chunk_size=800)

        # Filter out very small chunks
        chunks = [c for c in chunks if len(c["text"].strip()) > 50]

        return chunks

    def _chunk_by_separator(self, content: str, separator: str, doc_type: str, filename: str) -> List[Dict]:
        """Split content by a separator (e.g., --- between incidents)."""
        sections = content.split(separator)
        chunks = []
        for section in sections:
            section = section.strip()
            if section:
                title = self._extract_title(section)
                chunks.append({
                    "text": section,
                    "metadata": {
                        "doc_type": doc_type,
                        "source_file": filename,
                        "title": title,
                    },
                })
        return chunks

    def _chunk_by_header(self, content: str, header_prefix: str, doc_type: str, filename: str) -> List[Dict]:
        """Split content by markdown headers."""
        lines = content.split("\n")
        chunks = []
        current_chunk = []
        current_title = ""

        for line in lines:
            if line.startswith(header_prefix) and current_chunk:
                # Save previous chunk
                text = "\n".join(current_chunk).strip()
                if text:
                    chunks.append({
                        "text": text,
                        "metadata": {
                            "doc_type": doc_type,
                            "source_file": filename,
                            "title": current_title,
                        },
                    })
                current_chunk = [line]
                current_title = line.strip("# ").strip()
            else:
                current_chunk.append(line)
                if not current_title and line.startswith("#"):
                    current_title = line.strip("# ").strip()

        # Don't forget last chunk
        if current_chunk:
            text = "\n".join(current_chunk).strip()
            if text:
                chunks.append({
                    "text": text,
                    "metadata": {
                        "doc_type": doc_type,
                        "source_file": filename,
                        "title": current_title,
                    },
                })

        return chunks

    def _chunk_by_paragraphs(self, content: str, doc_type: str, filename: str, max_chunk_size: int = 800) -> List[Dict]:
        """Split content by paragraphs, merging small ones up to max_chunk_size."""
        paragraphs = content.split("\n\n")
        chunks = []
        current_chunk = []
        current_size = 0

        for para in paragraphs:
            para = para.strip()
            if not para:
                continue

            if current_size + len(para) > max_chunk_size and current_chunk:
                text = "\n\n".join(current_chunk)
                chunks.append({
                    "text": text,
                    "metadata": {
                        "doc_type": doc_type,
                        "source_file": filename,
                        "title": self._extract_title(text),
                    },
                })
                current_chunk = [para]
                current_size = len(para)
            else:
                current_chunk.append(para)
                current_size += len(para)

        if current_chunk:
            text = "\n\n".join(current_chunk)
            chunks.append({
                "text": text,
                "metadata": {
                    "doc_type": doc_type,
                    "source_file": filename,
                    "title": self._extract_title(text),
                },
            })

        return chunks

    def _extract_title(self, text: str) -> str:
        """Extract a title from the first header line or first line."""
        for line in text.split("\n"):
            line = line.strip()
            if line.startswith("#"):
                return line.strip("# ").strip()[:100]
            elif line and not line.startswith("-") and not line.startswith("*"):
                return line[:100]
        return ""

    def _infer_doc_type(self, filename: str) -> str:
        """Infer document type from filename."""
        filename_lower = filename.lower()
        if "incident" in filename_lower:
            return "incident_history"
        elif "runbook" in filename_lower:
            return "runbook"
        elif "service" in filename_lower:
            return "service_catalog"
        elif "infrastructure" in filename_lower:
            return "infrastructure"
        elif "topology" in filename_lower:
            return "system_topology"
        elif "tool" in filename_lower:
            return "tool_knowledge"
        else:
            return "general"

    def _generate_chunk_id(self, filename: str, chunk_index: int) -> str:
        """Generate a deterministic chunk ID."""
        raw = f"{filename}_{chunk_index}"
        return hashlib.md5(raw.encode()).hexdigest()[:16]
