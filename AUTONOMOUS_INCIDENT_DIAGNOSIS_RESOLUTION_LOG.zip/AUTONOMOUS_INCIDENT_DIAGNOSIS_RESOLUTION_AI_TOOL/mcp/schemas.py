# ═══════════════════════════════════════════════════════════════
# MCP Schemas - Data models for MCP communication
# ═══════════════════════════════════════════════════════════════
"""
Schema definitions for MCP protocol communication.
"""

from dataclasses import dataclass
from typing import Dict, List, Any, Optional
from enum import Enum


class ToolCategory(Enum):
    """Tool categories."""
    TELEMETRY = "telemetry"
    EXECUTION = "execution"
    MANAGEMENT = "management"
    DATA = "data"


@dataclass
class ToolParameter:
    """Definition of a tool parameter."""
    name: str
    type: str  # string, number, boolean, object, array
    required: bool = False
    description: str = ""
    default: Any = None


@dataclass
class ToolDefinition:
    """Definition of an MCP tool."""
    name: str
    server: str
    category: ToolCategory
    description: str
    parameters: List[ToolParameter]
    returns: Dict[str, str]  # return type and description


@dataclass
class ToolCall:
    """A call to an MCP tool."""
    tool_name: str
    server_name: str
    arguments: Dict[str, Any]
    request_id: str = ""
    timestamp: str = ""


@dataclass
class ToolResult:
    """Result from a tool call."""
    request_id: str
    tool_name: str
    success: bool
    result: Any = None
    error: Optional[str] = None
    execution_time_ms: float = 0.0
    timestamp: str = ""


# Tool registry with all available tools
TOOL_REGISTRY = {
    "telemetry-mcp": {
        "query_metrics": {
            "description": "Query system metrics",
            "parameters": [
                {"name": "host", "type": "string", "required": True},
                {"name": "metric", "type": "string", "required": True},
                {"name": "range", "type": "string", "required": False},
            ]
        },
        "get_application_logs": {
            "description": "Get application logs",
            "parameters": [
                {"name": "host", "type": "string", "required": True},
                {"name": "level", "type": "string", "required": False},
                {"name": "last_n", "type": "number", "required": False},
            ]
        },
    },
    "ssh-exec-mcp": {
        "get_process_list": {
            "description": "Get list of running processes",
            "parameters": [
                {"name": "host", "type": "string", "required": True},
            ]
        },
        "kill_process": {
            "description": "Kill a process",
            "parameters": [
                {"name": "host", "type": "string", "required": True},
                {"name": "pid", "type": "number", "required": True},
                {"name": "signal", "type": "string", "required": False},
            ]
        },
    },
    "cmdb-mcp": {
        "get_server_metadata": {
            "description": "Get server metadata",
            "parameters": [
                {"name": "hostname", "type": "string", "required": True},
            ]
        },
        "get_service_info": {
            "description": "Get service information",
            "parameters": [
                {"name": "service", "type": "string", "required": True},
            ]
        },
    },
}
