# ═══════════════════════════════════════════════════════════════
# MCP Client - Communication with MCP Servers
# ═══════════════════════════════════════════════════════════════
"""
MCP Client for communicating with MCP servers via JSON-RPC protocol.
"""

import json
import logging
from typing import Dict, List, Any, Optional

from ...core import MCPConnectionError, MCPToolError, MCPTimeoutError


class MCPClient:
    """
    Client for communicating with MCP servers.

    Implements JSON-RPC 2.0 protocol for tool-calling.
    """

    def __init__(self, servers: Dict[str, Dict[str, str]] = None):
        """
        Initialize MCP client.

        Args:
            servers: Dictionary mapping server names to connection info
                    {
                        "telemetry-mcp": {"host": "localhost", "port": 8001},
                        "ssh-exec-mcp": {"host": "localhost", "port": 8002},
                        ...
                    }
        """
        self.logger = logging.getLogger(self.__class__.__name__)
        self.servers = servers or {}
        self.connections = {}
        self.tool_registry = {}

    def register_server(self, name: str, host: str, port: int, tools: List[str] = None):
        """Register an MCP server."""
        self.servers[name] = {"host": host, "port": port}
        if tools:
            self.tool_registry[name] = tools
        self.logger.info(f"Registered MCP server: {name}")

    def call_tool(self, server: str, tool: str, args: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Call a tool on an MCP server.

        Args:
            server: Server name (e.g., "telemetry-mcp")
            tool: Tool name (e.g., "query_metrics")
            args: Tool arguments

        Returns:
            Tool result as dictionary

        Raises:
            MCPConnectionError: If server connection fails
            MCPToolError: If tool execution fails
            MCPTimeoutError: If call times out
        """
        if server not in self.servers:
            raise MCPConnectionError(f"Unknown server: {server}")

        if args is None:
            args = {}

        # Build JSON-RPC request
        request = {
            "jsonrpc": "2.0",
            "method": tool,
            "params": args,
            "id": self._generate_request_id(),
        }

        self.logger.debug(f"Calling {server}.{tool} with args: {args}")

        # In production: Make actual RPC call
        # For POC: Simulate result
        return self._simulate_tool_call(server, tool, args)

    def _generate_request_id(self) -> str:
        """Generate unique request ID."""
        import uuid
        return str(uuid.uuid4())[:8]

    def _simulate_tool_call(self, server: str, tool: str, args: Dict) -> Dict[str, Any]:
        """Simulate tool call for POC."""
        return {
            "jsonrpc": "2.0",
            "result": {
                "content": [
                    {
                        "type": "text",
                        "text": f"Result from {server}.{tool}({args})"
                    }
                ]
            },
            "id": self._generate_request_id(),
        }

    def get_server_info(self, server: str) -> Dict[str, Any]:
        """Get information about an MCP server."""
        if server not in self.servers:
            raise MCPConnectionError(f"Unknown server: {server}")

        return {
            "name": server,
            "address": self.servers[server],
            "tools": self.tool_registry.get(server, []),
        }

    def list_tools(self, server: Optional[str] = None) -> Dict[str, List[str]]:
        """
        List available tools.

        Args:
            server: Optional server name to filter by

        Returns:
            Dictionary of server -> tools
        """
        if server:
            return {server: self.tool_registry.get(server, [])}

        return {
            name: self.tool_registry.get(name, [])
            for name in self.servers
        }
