"""
Simulated MCP Server for Incident Response Tools.

This is a stdio-based MCP server (following the MCP protocol pattern from
MCP-Airbnb-Agent) that provides infrastructure operations tools.

The server simulates real infrastructure responses for POC demonstration.
In production, these would connect to actual infrastructure APIs.

Usage:
    python -m mcp.incident_mcp_server

Tools provided:
    - query_metrics: Query system metrics (CPU, memory, disk, load)
    - get_application_logs: Get application log entries
    - get_process_list: List running processes on a host
    - kill_process: Kill a process by PID
    - execute_command: Execute a shell command on a host
    - get_server_metadata: Get CMDB server metadata
    - get_service_info: Get service information from catalog
    - get_recent_changes: Get recent deployments/changes
    - get_dependencies: Get service dependency graph
    - check_service_health: Check if a service is healthy
    - create_incident: Create an incident ticket
    - send_notification: Send notification to on-call
"""

import json
import sys
import random
from datetime import datetime, timedelta
from typing import Any


# ===================================================================
# SIMULATED INFRASTRUCTURE DATA
# ===================================================================

SERVERS = {
    "prod-web-07": {
        "hostname": "prod-web-07",
        "ip": "10.0.1.7",
        "datacenter": "us-east-1",
        "rack": "R42-U12",
        "os": "Ubuntu 22.04 LTS",
        "kernel": "5.15.0-91-generic",
        "cpu_cores": 16,
        "memory_gb": 64,
        "uptime_days": 45,
        "environment": "production",
        "team": "platform-engineering",
    },
    "prod-db-01": {
        "hostname": "prod-db-01",
        "ip": "10.0.2.1",
        "datacenter": "us-east-1",
        "rack": "R42-U08",
        "os": "Ubuntu 22.04 LTS",
        "kernel": "5.15.0-91-generic",
        "cpu_cores": 32,
        "memory_gb": 128,
        "uptime_days": 120,
        "environment": "production",
        "team": "data-engineering",
    },
    "prod-batch-01": {
        "hostname": "prod-batch-01",
        "ip": "10.0.3.1",
        "datacenter": "us-east-1",
        "rack": "R43-U05",
        "os": "Ubuntu 22.04 LTS",
        "kernel": "5.15.0-91-generic",
        "cpu_cores": 8,
        "memory_gb": 32,
        "uptime_days": 30,
        "environment": "production",
        "team": "data-engineering",
    },
}

SERVICES = {
    "billing-api": {
        "name": "billing-api",
        "tier": "critical",
        "owner": "payments-team",
        "instances": 8,
        "port": 8080,
        "dependencies": ["postgres-primary", "redis-cache", "kafka-events"],
        "last_deploy": "2024-01-14T08:30:00Z",
        "auto_remediate": False,
    },
    "data-transform": {
        "name": "data-transform",
        "tier": "batch",
        "owner": "data-engineering",
        "instances": 3,
        "port": 9090,
        "dependencies": ["postgres-analytics", "s3-data-lake"],
        "last_deploy": "2024-01-15T02:00:00Z",
        "auto_remediate": True,
    },
    "user-service": {
        "name": "user-service",
        "tier": "standard",
        "owner": "platform-team",
        "instances": 5,
        "port": 8081,
        "dependencies": ["postgres-primary", "redis-sessions"],
        "last_deploy": "2024-01-13T14:00:00Z",
        "auto_remediate": True,
    },
}

PROCESS_TABLE = {
    "prod-web-07": [
        {"pid": 1, "name": "systemd", "cpu": 0.1, "memory_mb": 12, "user": "root", "runtime": "45d"},
        {"pid": 5510, "name": "python3 etl_batch.py", "cpu": 95.2, "memory_mb": 2048, "user": "app", "runtime": "47m"},
        {"pid": 5511, "name": "python3 worker.py", "cpu": 2.1, "memory_mb": 512, "user": "app", "runtime": "2d"},
        {"pid": 3201, "name": "nginx", "cpu": 1.5, "memory_mb": 128, "user": "www-data", "runtime": "45d"},
        {"pid": 8421, "name": "java -jar billing.jar", "cpu": 3.2, "memory_mb": 1024, "user": "app", "runtime": "5d"},
    ],
    "prod-batch-01": [
        {"pid": 1, "name": "systemd", "cpu": 0.1, "memory_mb": 12, "user": "root", "runtime": "30d"},
        {"pid": 7890, "name": "python3 etl_main.py", "cpu": 94.8, "memory_mb": 4096, "user": "etl", "runtime": "52m"},
        {"pid": 7891, "name": "python3 etl_worker.py", "cpu": 45.0, "memory_mb": 2048, "user": "etl", "runtime": "52m"},
    ],
}

RECENT_CHANGES = [
    {
        "timestamp": "2024-01-15T02:00:00Z",
        "type": "deployment",
        "service": "data-transform",
        "version": "2.4.1 -> 2.5.0",
        "author": "ci-pipeline",
        "description": "Added new ETL batch processing module",
    },
    {
        "timestamp": "2024-01-14T22:00:00Z",
        "type": "config_change",
        "service": "data-transform",
        "description": "Increased batch_size from 1000 to 5000",
        "author": "data-team",
    },
    {
        "timestamp": "2024-01-14T08:30:00Z",
        "type": "deployment",
        "service": "billing-api",
        "version": "5.2.0 -> 5.2.1",
        "author": "ci-pipeline",
        "description": "Hotfix for payment timeout issue",
    },
]

APPLICATION_LOGS = {
    "prod-web-07": [
        {"timestamp": "2024-01-15T10:28:00Z", "level": "ERROR", "service": "data-transform", "message": "Deadlock detected in ETL batch job - transaction timeout after 30s"},
        {"timestamp": "2024-01-15T10:27:45Z", "level": "ERROR", "service": "data-transform", "message": "OOM: Process 5510 exceeded memory limit (2048MB)"},
        {"timestamp": "2024-01-15T10:27:30Z", "level": "WARN", "service": "data-transform", "message": "Batch processing stalled - no progress for 15 minutes"},
        {"timestamp": "2024-01-15T10:25:00Z", "level": "ERROR", "service": "data-transform", "message": "Connection pool exhausted - all 50 connections in use"},
        {"timestamp": "2024-01-15T10:20:00Z", "level": "INFO", "service": "data-transform", "message": "Starting batch job: batch_id=ETL-2024-0115-001"},
    ],
    "prod-batch-01": [
        {"timestamp": "2024-01-15T10:30:00Z", "level": "ERROR", "service": "data-transform", "message": "Fatal: ETL pipeline halted - deadlock in transaction processing"},
        {"timestamp": "2024-01-15T10:29:00Z", "level": "WARN", "service": "data-transform", "message": "CPU throttling detected - process consuming >90% CPU for 40+ minutes"},
        {"timestamp": "2024-01-15T10:28:00Z", "level": "ERROR", "service": "data-transform", "message": "Memory pressure: swap usage at 85%"},
    ],
}


# ===================================================================
# MCP TOOL IMPLEMENTATIONS
# ===================================================================

def query_metrics(host: str, metric: str = "cpu_percent", time_range: str = "1h") -> dict:
    """Query system metrics for a host."""
    metrics_data = {
        "prod-web-07": {
            "cpu_percent": {"current": 98.5, "avg_1h": 92.3, "max_1h": 99.1},
            "memory_percent": {"current": 78.0, "avg_1h": 75.5, "max_1h": 80.2},
            "disk_percent": {"current": 45.0, "avg_1h": 44.8, "max_1h": 45.2},
            "load_avg_1m": {"current": 12.4, "avg_1h": 10.8, "max_1h": 14.2},
            "network_io_mbps": {"current": 125.0, "avg_1h": 98.0, "max_1h": 150.0},
        },
        "prod-batch-01": {
            "cpu_percent": {"current": 95.0, "avg_1h": 88.7, "max_1h": 96.2},
            "memory_percent": {"current": 89.0, "avg_1h": 82.0, "max_1h": 91.0},
            "disk_percent": {"current": 72.0, "avg_1h": 70.5, "max_1h": 73.0},
            "load_avg_1m": {"current": 8.0, "avg_1h": 7.2, "max_1h": 8.5},
        },
    }

    server_metrics = metrics_data.get(host, {})
    metric_values = server_metrics.get(metric, {"current": 0, "avg_1h": 0, "max_1h": 0})

    return {
        "host": host,
        "metric": metric,
        "time_range": time_range,
        "values": metric_values,
        "unit": "%" if "percent" in metric else ("" if "load" in metric else "mbps"),
        "timestamp": datetime.now().isoformat(),
    }


def get_application_logs(host: str, level: str = "ERROR", last_n: int = 10) -> dict:
    """Get application logs from a host."""
    logs = APPLICATION_LOGS.get(host, [])
    if level != "ALL":
        logs = [l for l in logs if l["level"] == level or l["level"] in ["ERROR", "WARN"]]
    return {
        "host": host,
        "filter_level": level,
        "entries": logs[:last_n],
        "total_matching": len(logs),
    }


def get_process_list(host: str) -> dict:
    """Get list of running processes on a host."""
    processes = PROCESS_TABLE.get(host, [])
    return {
        "host": host,
        "process_count": len(processes),
        "processes": processes,
        "top_cpu": sorted(processes, key=lambda p: p["cpu"], reverse=True)[:3],
    }


def kill_process(host: str, pid: int, signal: str = "SIGTERM") -> dict:
    """Kill a process by PID on a host."""
    processes = PROCESS_TABLE.get(host, [])
    target = next((p for p in processes if p["pid"] == pid), None)

    if target is None:
        return {"success": False, "error": f"Process {pid} not found on {host}"}

    return {
        "success": True,
        "host": host,
        "pid": pid,
        "process_name": target["name"],
        "signal": signal,
        "message": f"Process {pid} ({target['name']}) terminated with {signal}",
        "cpu_freed": target["cpu"],
        "memory_freed_mb": target["memory_mb"],
    }


def execute_command(host: str, command: str) -> dict:
    """Execute a shell command on a host (simulated)."""
    # Simulate common diagnostic commands
    simulated_outputs = {
        "uptime": f" 10:30:00 up 45 days, 3:22, 2 users, load average: 12.40, 11.80, 10.50",
        "free -m": "              total   used   free  shared  buff/cache  available\nMem:          65536  51200   4096    512       10240      13824\nSwap:          8192   6963   1229",
        "df -h": "Filesystem  Size  Used  Avail  Use%  Mounted on\n/dev/sda1   500G  225G   275G   45%   /",
        "netstat -tlnp": "tcp  0  0  0.0.0.0:8080  0.0.0.0:*  LISTEN  5510/python3\ntcp  0  0  0.0.0.0:9090  0.0.0.0:*  LISTEN  3201/nginx",
    }

    output = simulated_outputs.get(command, f"Command executed: {command}\nExit code: 0")

    return {
        "host": host,
        "command": command,
        "exit_code": 0,
        "stdout": output,
        "stderr": "",
        "execution_time_ms": random.randint(50, 200),
    }


def get_server_metadata(hostname: str) -> dict:
    """Get server metadata from CMDB."""
    server = SERVERS.get(hostname, {})
    if not server:
        return {"error": f"Server {hostname} not found in CMDB"}
    return {
        "hostname": hostname,
        "metadata": server,
        "last_updated": "2024-01-15T00:00:00Z",
    }


def get_service_info(service_name: str) -> dict:
    """Get service information from service catalog."""
    service = SERVICES.get(service_name, {})
    if not service:
        return {"error": f"Service {service_name} not found in catalog"}
    return {
        "service": service_name,
        "info": service,
    }


def get_recent_changes(host: str = "", service: str = "", time_range: str = "24h") -> dict:
    """Get recent changes (deployments, config changes) for a host or service."""
    changes = RECENT_CHANGES
    if host:
        changes = [c for c in changes if host in str(c)]
    if service:
        changes = [c for c in changes if c.get("service") == service]
    return {
        "filter": {"host": host, "service": service, "time_range": time_range},
        "changes": changes,
        "total": len(changes),
    }


def get_dependencies(service_name: str) -> dict:
    """Get service dependency graph."""
    service = SERVICES.get(service_name, {})
    deps = service.get("dependencies", [])
    return {
        "service": service_name,
        "dependencies": deps,
        "dependency_count": len(deps),
        "tier": service.get("tier", "unknown"),
    }


def check_service_health(service_name: str) -> dict:
    """Check if a service is healthy."""
    service = SERVICES.get(service_name)
    if not service:
        return {"service": service_name, "healthy": False, "error": "Service not found"}

    # Simulate health based on service name
    is_healthy = service_name != "data-transform"
    return {
        "service": service_name,
        "healthy": is_healthy,
        "instances_total": service["instances"],
        "instances_healthy": service["instances"] if is_healthy else service["instances"] - 1,
        "last_check": datetime.now().isoformat(),
        "response_time_ms": random.randint(5, 50) if is_healthy else random.randint(500, 5000),
    }


def create_incident(title: str, severity: str, service: str, description: str = "") -> dict:
    """Create an incident ticket."""
    incident_id = f"INC-{random.randint(10000, 99999)}"
    return {
        "incident_id": incident_id,
        "title": title,
        "severity": severity,
        "service": service,
        "description": description,
        "status": "open",
        "created_at": datetime.now().isoformat(),
        "assigned_to": "on-call-engineer",
    }


def send_notification(channel: str, message: str, severity: str = "warning") -> dict:
    """Send notification to on-call team."""
    return {
        "success": True,
        "channel": channel,
        "message": message,
        "severity": severity,
        "delivered_at": datetime.now().isoformat(),
    }


# ===================================================================
# MCP PROTOCOL HANDLER (stdio-based)
# ===================================================================

TOOL_REGISTRY = {
    "query_metrics": {
        "function": query_metrics,
        "description": "Query system metrics (CPU, memory, disk, load) for a specific host",
        "parameters": {
            "host": {"type": "string", "required": True, "description": "Target hostname"},
            "metric": {"type": "string", "required": False, "description": "Metric name (cpu_percent, memory_percent, disk_percent, load_avg_1m)"},
            "time_range": {"type": "string", "required": False, "description": "Time range (1h, 6h, 24h)"},
        },
    },
    "get_application_logs": {
        "function": get_application_logs,
        "description": "Get application log entries from a host filtered by log level",
        "parameters": {
            "host": {"type": "string", "required": True, "description": "Target hostname"},
            "level": {"type": "string", "required": False, "description": "Log level filter (ERROR, WARN, INFO, ALL)"},
            "last_n": {"type": "integer", "required": False, "description": "Number of recent entries to return"},
        },
    },
    "get_process_list": {
        "function": get_process_list,
        "description": "Get list of running processes on a host with CPU and memory usage",
        "parameters": {
            "host": {"type": "string", "required": True, "description": "Target hostname"},
        },
    },
    "kill_process": {
        "function": kill_process,
        "description": "Kill a process by PID on a specific host",
        "parameters": {
            "host": {"type": "string", "required": True, "description": "Target hostname"},
            "pid": {"type": "integer", "required": True, "description": "Process ID to kill"},
            "signal": {"type": "string", "required": False, "description": "Signal to send (SIGTERM, SIGKILL)"},
        },
    },
    "execute_command": {
        "function": execute_command,
        "description": "Execute a shell command on a remote host",
        "parameters": {
            "host": {"type": "string", "required": True, "description": "Target hostname"},
            "command": {"type": "string", "required": True, "description": "Command to execute"},
        },
    },
    "get_server_metadata": {
        "function": get_server_metadata,
        "description": "Get server metadata from CMDB (datacenter, OS, team, specs)",
        "parameters": {
            "hostname": {"type": "string", "required": True, "description": "Server hostname"},
        },
    },
    "get_service_info": {
        "function": get_service_info,
        "description": "Get service information from catalog (tier, owner, dependencies)",
        "parameters": {
            "service_name": {"type": "string", "required": True, "description": "Service name"},
        },
    },
    "get_recent_changes": {
        "function": get_recent_changes,
        "description": "Get recent deployments and config changes for a service or host",
        "parameters": {
            "host": {"type": "string", "required": False, "description": "Filter by hostname"},
            "service": {"type": "string", "required": False, "description": "Filter by service name"},
            "time_range": {"type": "string", "required": False, "description": "Time range to search"},
        },
    },
    "get_dependencies": {
        "function": get_dependencies,
        "description": "Get service dependency graph",
        "parameters": {
            "service_name": {"type": "string", "required": True, "description": "Service name"},
        },
    },
    "check_service_health": {
        "function": check_service_health,
        "description": "Check health status of a service (instance count, response time)",
        "parameters": {
            "service_name": {"type": "string", "required": True, "description": "Service name to check"},
        },
    },
    "create_incident": {
        "function": create_incident,
        "description": "Create a new incident ticket for tracking",
        "parameters": {
            "title": {"type": "string", "required": True, "description": "Incident title"},
            "severity": {"type": "string", "required": True, "description": "Severity level (critical, high, medium, low)"},
            "service": {"type": "string", "required": True, "description": "Affected service"},
            "description": {"type": "string", "required": False, "description": "Detailed description"},
        },
    },
    "send_notification": {
        "function": send_notification,
        "description": "Send notification to on-call team via Slack/Teams",
        "parameters": {
            "channel": {"type": "string", "required": True, "description": "Notification channel (slack, teams, pagerduty)"},
            "message": {"type": "string", "required": True, "description": "Notification message"},
            "severity": {"type": "string", "required": False, "description": "Message severity"},
        },
    },
}


def handle_mcp_request(request: dict) -> dict:
    """Handle an MCP JSON-RPC request."""
    method = request.get("method", "")
    params = request.get("params", {})
    request_id = request.get("id", 0)

    if method == "initialize":
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {"name": "incident-response-mcp", "version": "1.0.0"},
            },
        }

    elif method == "tools/list":
        tools = []
        for name, info in TOOL_REGISTRY.items():
            properties = {}
            required = []
            for pname, pinfo in info["parameters"].items():
                properties[pname] = {
                    "type": pinfo["type"],
                    "description": pinfo.get("description", ""),
                }
                if pinfo.get("required"):
                    required.append(pname)

            tools.append({
                "name": name,
                "description": info["description"],
                "inputSchema": {
                    "type": "object",
                    "properties": properties,
                    "required": required,
                },
            })
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {"tools": tools},
        }

    elif method == "tools/call":
        tool_name = params.get("name", "")
        tool_args = params.get("arguments", {})

        if tool_name not in TOOL_REGISTRY:
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "error": {"code": -32601, "message": f"Unknown tool: {tool_name}"},
            }

        try:
            func = TOOL_REGISTRY[tool_name]["function"]
            result = func(**tool_args)
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {
                    "content": [{"type": "text", "text": json.dumps(result, default=str)}],
                    "isError": False,
                },
            }
        except Exception as e:
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {
                    "content": [{"type": "text", "text": f"Error: {str(e)}"}],
                    "isError": True,
                },
            }

    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "error": {"code": -32601, "message": f"Method not found: {method}"},
    }


def main():
    """Run MCP server in stdio mode (reads JSON-RPC from stdin, writes to stdout)."""
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            request = json.loads(line)
            response = handle_mcp_request(request)
            sys.stdout.write(json.dumps(response) + "\n")
            sys.stdout.flush()
        except json.JSONDecodeError:
            error_response = {
                "jsonrpc": "2.0",
                "id": None,
                "error": {"code": -32700, "message": "Parse error"},
            }
            sys.stdout.write(json.dumps(error_response) + "\n")
            sys.stdout.flush()


if __name__ == "__main__":
    main()
