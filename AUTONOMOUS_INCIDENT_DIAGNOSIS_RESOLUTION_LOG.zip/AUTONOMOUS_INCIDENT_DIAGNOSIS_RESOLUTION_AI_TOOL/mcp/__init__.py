# ═══════════════════════════════════════════════════════════════
# MCP Module - Model Context Protocol Implementation
# ═══════════════════════════════════════════════════════════════
"""
MCP (Model Context Protocol) implementations for tool communication.

Components:
- client.py: MCPClient for calling remote tools
- schemas.py: Data models and tool registry
- adapters/: Protocol adapters for different backends

Server implementations available in production deployment:
- TelemetryServer: Metrics, logs, monitoring data
- SSHExecServer: Process management, command execution
- CMDBServer: Infrastructure metadata, configuration
- AlertingServer: Alert creation, management
- RunbookServer: Operational procedures
"""

from .client import MCPClient
from .schemas import (
    ToolCategory,
    ToolParameter,
    ToolDefinition,
    ToolCall,
    ToolResult,
    TOOL_REGISTRY,
)

__all__ = [
    # Client
    "MCPClient",
    # Schemas
    "ToolCategory",
    "ToolParameter",
    "ToolDefinition",
    "ToolCall",
    "ToolResult",
    "TOOL_REGISTRY",
]
