# ═══════════════════════════════════════════════════════════════
# Multi-Agent Orchestration Engine
# ═══════════════════════════════════════════════════════════════
"""
Orchestrates the workflow of all agents in the system.
"""

import logging
from typing import Dict, Any, Optional

from ..agents import (
    MonitorAgent,
    DiagnosisAgent,
    RemediationAgent,
    LearnerAgent,
)
from ..mcp import MCPClient


class AgentOrchestrator:
    """
    Coordinates all agents in the multi-agent system.

    Workflow:
    1. MonitorAgent: Receive and enrich alert
    2. DiagnosisAgent: Analyze and diagnose
    3. RemediationAgent: Execute fix with safety checks
    4. LearnerAgent: Capture feedback and improve
    """

    def __init__(self, mcp_client: MCPClient, knowledge_base: Dict[str, Any]):
        """
        Initialize the orchestrator.

        Args:
            mcp_client: MCP client for tool communication
            knowledge_base: Knowledge base dictionary
        """
        self.logger = logging.getLogger(self.__class__.__name__)
        self.mcp_client = mcp_client
        self.knowledge_base = knowledge_base

        # Initialize agents
        self.monitor = MonitorAgent(mcp_client, knowledge_base)
        self.diagnosis = DiagnosisAgent(knowledge_base)
        self.remediation = RemediationAgent(mcp_client, knowledge_base)
        self.learner = LearnerAgent(knowledge_base)

        self.execution_history = []

    def process_alert(self, raw_alert: Dict[str, Any],
                     enable_learning: bool = True) -> Dict[str, Any]:
        """
        Process an alert through the full multi-agent pipeline.

        Args:
            raw_alert: Raw alert from monitoring system
            enable_learning: Whether to capture feedback for learning

        Returns:
            Result of the full processing pipeline
        """
        self.logger.info(f"Processing alert: {raw_alert.get('alert', 'Unknown')}")

        # Phase 1: Monitor - Enrich alert
        self.logger.info("Phase 1: MONITOR - Alert enrichment")
        monitor_result = self.monitor.process(raw_alert)
        enriched_alert = monitor_result["enriched_alert"]
        self.logger.info(f"Alert enriched: {enriched_alert.alert_id}, Priority: {enriched_alert.priority}")

        # Phase 2: Diagnosis - Analyze and diagnose
        self.logger.info("Phase 2: DIAGNOSIS - Root cause analysis")
        diagnosis_result = self.diagnosis.process({
            "enriched_alert": enriched_alert
        })
        diagnosis = diagnosis_result["diagnosis"]
        self.logger.info(f"Diagnosis: {diagnosis.root_cause}, Confidence: {diagnosis.confidence:.0%}")

        # Phase 3: Remediation - Execute fix
        self.logger.info("Phase 3: REMEDIATION - Execute fix")
        remediation_decision = self._make_remediation_decision(diagnosis)

        remediation_result = self.remediation.process({
            "incident": {
                "alert": enriched_alert.raw_alert.get("alert"),
                "server": enriched_alert.raw_alert.get("server"),
                "tier": enriched_alert.service_context.get("tier"),
                "pid": 1234,  # Would come from actual incident data
            },
            "decision": remediation_decision,
        })

        remediation_outcome = remediation_result["remediation_result"]
        self.logger.info(f"Remediation: {'SUCCESS' if remediation_outcome.success else 'FAILED'}")

        # Phase 4: Learning - Capture feedback
        if enable_learning and remediation_outcome.success:
            self.logger.info("Phase 4: LEARNING - Capture feedback")

            # Simulate human approval
            human_decision = {
                "action": diagnosis.recommended_actions[0] if diagnosis.recommended_actions else "escalate",
                "reason": "Automated fix validated",
                "root_cause": diagnosis.root_cause,
            }

            learning_result = self.learner.process({
                "incident": {
                    "incident_id": enriched_alert.alert_id,
                    "alert": enriched_alert.raw_alert.get("alert"),
                    "tier": enriched_alert.service_context.get("tier"),
                },
                "ai_decision": {
                    "action": remediation_decision["action"],
                    "confidence": diagnosis.confidence,
                },
                "human_decision": human_decision,
                "expert_notes": "Pattern validated in production",
            })

            self.logger.info(f"Learned patterns: {learning_result['patterns_learned']}")

        # Compile final result
        result = {
            "alert_id": enriched_alert.alert_id,
            "priority": enriched_alert.priority,
            "diagnosis": diagnosis,
            "remediation": remediation_outcome,
            "success": remediation_outcome.success,
            "execution_time_seconds": remediation_outcome.execution_time_seconds,
        }

        self.execution_history.append(result)
        return result

    def _make_remediation_decision(self, diagnosis) -> Dict[str, Any]:
        """
        Decide on remediation action based on diagnosis.

        Args:
            diagnosis: Diagnosis result

        Returns:
            Remediation decision
        """
        if not diagnosis.recommended_actions:
            return {
                "action": "escalate",
                "requires_approval": True,
            }

        action = diagnosis.recommended_actions[0]
        requires_approval = diagnosis.confidence < 0.85

        return {
            "action": action,
            "requires_approval": requires_approval,
            "confidence": diagnosis.confidence,
        }

    def get_statistics(self) -> Dict[str, Any]:
        """Get orchestrator statistics."""
        successful = sum(1 for r in self.execution_history if r.get("success"))

        return {
            "total_alerts_processed": len(self.execution_history),
            "successful_remediations": successful,
            "success_rate": f"{100 * successful / max(len(self.execution_history), 1):.1f}%",
            "monitor_stats": self.monitor.get_stats(),
            "diagnosis_stats": self.diagnosis.get_stats(),
            "remediation_stats": self.remediation.get_stats(),
            "learner_stats": self.learner.get_stats(),
        }
