"""
Data Ingestion Pipeline

Simulates a streaming data ingestion pipeline with the following stages:

1. COLLECT — Pull metrics from multiple monitoring sources
2. NORMALIZE — Convert to unified TelemetryEvent schema
3. ENRICH — Add CMDB context (owner, tier, dependencies)
4. DETECT — Flag anomalies based on threshold policies
5. ROUTE — Send alerts to appropriate agents

In production, this would integrate with:
- Prometheus (metrics)
- Datadog (APM + metrics)
- CloudWatch (AWS metrics)
- Kubernetes API (pod status)
- ELK Stack (logs)
- PagerDuty/Opsgenie (alerting)
"""

import uuid
from datetime import datetime
from typing import List, Dict, Tuple

from .models import TelemetryEvent
from .mock_data import SERVERS, SERVICES


class DataIngestionPipeline:
    """
    Multi-stage data ingestion pipeline for telemetry events.

    Pipeline Stages:
    ----------------
    1. COLLECT: Pull raw metrics from all monitored servers
    2. NORMALIZE: Convert to TelemetryEvent schema
    3. ENRICH: Add CMDB context from service catalog
    4. DETECT: Flag anomalies based on threshold policies
    5. ROUTE: Send to MonitorAgent for processing

    Threshold Policies:
    ------------------
    - CPU: warning at 80%, critical at 95%
    - Memory: warning at 85%, critical at 95%
    - Disk: warning at 80%, critical at 90%
    - Load Avg: warning at 8, critical at 12

    Usage:
    ------
    ```python
    from data_ingestion import DataIngestionPipeline, SERVERS, SERVICES

    pipeline = DataIngestionPipeline(SERVERS, SERVICES)
    results = pipeline.run_pipeline()

    # Get critical anomalies
    critical_alerts = [a for a in pipeline.anomalies if a.severity == "critical"]
    ```
    """

    def __init__(self, servers: dict, services: dict):
        """
        Initialize the ingestion pipeline.

        Args:
            servers: Dict of hostname -> ServerMetrics
            services: Dict of service_name -> ServiceInfo
        """
        self.servers = servers
        self.services = services
        self.event_buffer = []
        self.anomalies = []

        # Threshold policies (would come from config in production)
        self.thresholds = {
            "cpu_percent": {"warning": 80, "critical": 95},
            "memory_percent": {"warning": 85, "critical": 95},
            "disk_percent": {"warning": 80, "critical": 90},
            "load_avg_1m": {"warning": 8, "critical": 12},
        }

    def collect_metrics(self) -> List[TelemetryEvent]:
        """
        Stage 1: Collect raw metrics from all monitored servers.

        In production, this would:
        - Query Prometheus for last 5 minutes of data
        - Poll Datadog API for APM metrics
        - Fetch CloudWatch metrics
        - Query Kubernetes API for pod status

        Returns:
            List of TelemetryEvent objects
        """
        raw_events = []

        for hostname, metrics in self.servers.items():
            # Collect each metric type
            for metric_name in ["cpu_percent", "memory_percent", "disk_percent", "load_avg_1m"]:
                value = getattr(metrics, metric_name)
                thresholds = self.thresholds.get(metric_name, {})

                # Determine severity based on threshold
                if value >= thresholds.get("critical", 999):
                    severity = "critical"
                elif value >= thresholds.get("warning", 999):
                    severity = "warning"
                else:
                    severity = "info"

                # Create TelemetryEvent
                event = TelemetryEvent(
                    event_id=str(uuid.uuid4())[:8],
                    timestamp=datetime.now().isoformat(),
                    source="prometheus",
                    host=hostname,
                    metric_name=metric_name,
                    metric_value=value,
                    threshold=thresholds.get("critical", 100),
                    severity=severity,
                    labels={"region": "us-east", "env": "production"}
                )
                raw_events.append(event)

        return raw_events

    def enrich_events(self, events: List[TelemetryEvent]) -> List[TelemetryEvent]:
        """
        Stage 2: Enrich events with CMDB context.

        Adds service catalog information to each event:
        - Service name and tier
        - Owner team
        - Dependencies
        - SLA target
        - Runbook ID

        Args:
            events: List of TelemetryEvent objects

        Returns:
            Enriched list of TelemetryEvent objects
        """
        for event in events:
            # Find services running on this host
            host_services = [s for s in self.services.values() if s.host == event.host]

            if host_services:
                # Use first service as primary (could be more sophisticated)
                primary_service = host_services[0]

                # Add enrichment data
                event.enrichment = {
                    "service_name": primary_service.service_name,
                    "service_tier": primary_service.tier.value,
                    "owner_team": primary_service.owner_team,
                    "dependencies": primary_service.dependencies,
                    "sla_target": primary_service.sla_target,
                    "runbook_id": primary_service.runbook_id,
                }

        return events

    def detect_anomalies(self, events: List[TelemetryEvent]) -> List[TelemetryEvent]:
        """
        Stage 3: Flag events that breach thresholds.

        Anomaly detection rules:
        - Severity = "critical" or "warning"
        - Value exceeds threshold for metric type
        - Consider historical patterns (not implemented in POC)
        - Check for cascading failures (not implemented in POC)

        Args:
            events: List of TelemetryEvent objects

        Returns:
            List of anomalous events requiring attention
        """
        anomalies = []

        for event in events:
            if event.is_anomaly():
                anomalies.append(event)

        return anomalies

    def run_pipeline(self) -> Dict[str, int]:
        """
        Execute the full ingestion pipeline.

        Pipeline flow:
        1. COLLECT: Pull metrics from all sources
        2. ENRICH: Add CMDB context
        3. DETECT: Flag anomalies
        4. BUFFER: Store for agent processing

        Returns:
            dict: Pipeline statistics
                - total_events: Total events collected
                - enriched: Events with CMDB context
                - anomalies: Total anomalies detected
                - critical: Critical severity count
                - warning: Warning severity count
        """
        print("[DATA INGESTION] Running Pipeline...")
        print("-" * 60)

        # Stage 1: Collect raw metrics
        raw_events = self.collect_metrics()
        print(f"  [COLLECT]  {len(raw_events)} raw metric events ingested")

        # Stage 2: Enrich with CMDB context
        enriched_events = self.enrich_events(raw_events)
        enriched_count = sum(1 for e in enriched_events if e.enrichment)
        print(f"  [ENRICH]   {enriched_count}/{len(enriched_events)} events enriched with CMDB data")

        # Stage 3: Detect anomalies
        anomalies = self.detect_anomalies(enriched_events)
        print(f"  [DETECT]   {len(anomalies)} anomalies detected")

        # Buffer events for agent processing
        self.event_buffer = enriched_events
        self.anomalies = anomalies

        print("-" * 60)
        print("[ANOMALIES] Requiring Investigation:")
        for a in anomalies:
            tier_info = a.get_service_tier()
            print(f"   [{a.severity.upper():8}] {a.host}: {a.metric_name}={a.metric_value:.1f}% "
                  f"(threshold={a.threshold}%) | tier={tier_info}")

        # Return statistics
        return {
            "total_events": len(raw_events),
            "enriched": enriched_count,
            "anomalies": len(anomalies),
            "critical": sum(1 for a in anomalies if a.severity == "critical"),
            "warning": sum(1 for a in anomalies if a.severity == "warning"),
        }

    def get_critical_anomalies(self) -> List[TelemetryEvent]:
        """Get all critical severity anomalies."""
        return [a for a in self.anomalies if a.severity == "critical"]

    def get_anomalies_by_host(self, hostname: str) -> List[TelemetryEvent]:
        """Get all anomalies for a specific host."""
        return [a for a in self.anomalies if a.host == hostname]

    def get_anomalies_by_service(self, service_name: str) -> List[TelemetryEvent]:
        """Get all anomalies for a specific service."""
        return [
            a for a in self.anomalies
            if a.enrichment.get("service_name") == service_name
        ]

    def reset(self):
        """Clear event buffer and anomalies."""
        self.event_buffer = []
        self.anomalies = []


def create_alert_from_anomaly(anomaly: TelemetryEvent) -> dict:
    """
    Convert a TelemetryEvent anomaly into an alert dict for MonitorAgent.

    Args:
        anomaly: TelemetryEvent with severity "critical" or "warning"

    Returns:
        dict: Alert in format expected by MonitorAgent
    """
    return anomaly.to_alert_dict()


def get_top_anomalies(pipeline: DataIngestionPipeline, limit: int = 5) -> List[TelemetryEvent]:
    """
    Get the most critical anomalies, prioritized by severity and metric value.

    Args:
        pipeline: DataIngestionPipeline instance
        limit: Maximum number of anomalies to return

    Returns:
        List of top anomalies sorted by priority
    """
    # Sort by severity (critical first) then by how far over threshold
    def priority_score(event: TelemetryEvent) -> Tuple[int, float]:
        severity_score = 2 if event.severity == "critical" else 1
        threshold_excess = event.metric_value - event.threshold
        return (severity_score, threshold_excess)

    sorted_anomalies = sorted(
        pipeline.anomalies,
        key=priority_score,
        reverse=True
    )

    return sorted_anomalies[:limit]
