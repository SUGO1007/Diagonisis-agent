# Data Ingestion Module

This module handles telemetry event ingestion, normalization, enrichment, and anomaly detection.

## Overview

The data ingestion pipeline simulates a production monitoring system with multiple stages:

```
┌─────────────────────────────────────────────────────────────┐
│                   DATA INGESTION PIPELINE                   │
└─────────────────────────────────────────────────────────────┘

    RAW SOURCES                      PIPELINE STAGES
┌──────────────────┐
│   Prometheus     │──┐
│   (metrics)      │  │
└──────────────────┘  │
                      │    ┌──────────┐
┌──────────────────┐  │    │ COLLECT  │
│   Datadog        │──┼───▶│ Metrics  │
│   (APM + logs)   │  │    └────┬─────┘
└──────────────────┘  │         │
                      │         ▼
┌──────────────────┐  │    ┌──────────┐
│   CloudWatch     │──┤    │ NORMALIZE│
│   (AWS metrics)  │  │    │  Schema  │
└──────────────────┘  │    └────┬─────┘
                      │         │
┌──────────────────┐  │         ▼
│   Kubernetes API │──┤    ┌──────────┐
│   (pod status)   │  │    │  ENRICH  │
└──────────────────┘  │    │   CMDB   │
                      │    └────┬─────┘
┌──────────────────┐  │         │
│   ELK Stack      │──┘         ▼
│   (logs)         │        ┌──────────┐
└──────────────────┘        │  DETECT  │
                            │ Anomalies│
                            └────┬─────┘
                                 │
                                 ▼
                         ┌───────────────┐
                         │ MonitorAgent  │
                         │ (Alert Inbox) │
                         └───────────────┘
```

## Components

### 1. Data Models (`models.py`)

Core data structures:

#### ServiceTier Enum
```python
class ServiceTier(Enum):
    CRITICAL = "critical"  # Never auto-remediate (billing-api, redis-cache)
    STANDARD = "standard"  # Auto-restart allowed (user-service)
    BATCH = "batch"        # Auto-kill allowed (data-transform)
```

#### TelemetryEvent
Unified schema for all monitoring sources:
```python
@dataclass
class TelemetryEvent:
    event_id: str
    timestamp: str
    source: str              # prometheus, datadog, cloudwatch, k8s
    host: str
    metric_name: str
    metric_value: float
    threshold: float
    severity: str            # critical, warning, info
    labels: dict
    enrichment: dict         # Added by enrichment stage
```

#### Other Models
- `ServerMetrics`: CPU, memory, disk, network metrics
- `ServiceInfo`: Service catalog entry (tier, owner, dependencies)
- `KubernetesPod`: Pod status, restarts, resource limits
- `ApplicationLog`: Log entries from ELK/Splunk

### 2. Mock Data (`mock_data.py`)

POC test data representing production infrastructure:

#### SERVERS (5 servers)
```python
SERVERS = {
    "prod-web-07": ServerMetrics(cpu_percent=98.5, ...),    # HIGH CPU
    "prod-web-03": ServerMetrics(cpu_percent=35.2, ...),    # Healthy
    "prod-db-01": ServerMetrics(memory_percent=88.5, ...),  # High memory
    "prod-cache-02": ServerMetrics(memory_percent=92.0, ...), # Redis cache
    "prod-batch-01": ServerMetrics(cpu_percent=95.0, ...),  # ETL deadlock
}
```

#### SERVICES (5 services)
```python
SERVICES = {
    "billing-api": ServiceInfo(tier=CRITICAL, ...),
    "data-transform": ServiceInfo(tier=BATCH, ...),
    "user-service": ServiceInfo(tier=STANDARD, ...),
    "notification-worker": ServiceInfo(tier=STANDARD, ...),
    "redis-cache": ServiceInfo(tier=CRITICAL, ...),
}
```

#### Other Data
- `K8S_PODS`: 5 pods including OOMKilled and CrashLoopBackOff
- `APP_LOGS`: 5 error/warning log entries
- `PROCESS_TABLE`: Process listings for servers

### 3. Pipeline (`pipeline.py`)

Multi-stage ingestion pipeline:

#### DataIngestionPipeline Class

```python
pipeline = DataIngestionPipeline(SERVERS, SERVICES)
results = pipeline.run_pipeline()

# Output:
# 📡 Running Data Ingestion Pipeline...
# ─────────────────────────────────────
#   [COLLECT]  20 raw metric events ingested
#   [ENRICH]   20/20 events enriched with CMDB data
#   [DETECT]   8 anomalies detected
# ─────────────────────────────────────
# 🚨 ANOMALIES REQUIRING INVESTIGATION:
#    [CRITICAL] prod-web-07: cpu_percent=98.5% (threshold=95%) | tier=critical
#    [CRITICAL] prod-batch-01: cpu_percent=95.0% (threshold=95%) | tier=batch
#    ...
```

#### Pipeline Stages

**Stage 1: COLLECT**
- Pull metrics from all monitored servers
- Create TelemetryEvent for each metric
- Classify severity: info, warning, critical

**Stage 2: ENRICH**
- Match hostname to service catalog
- Add CMDB context:
  - Service name and tier
  - Owner team
  - Dependencies
  - SLA target
  - Runbook ID

**Stage 3: DETECT**
- Flag anomalies (severity = warning or critical)
- Apply threshold policies:
  - CPU: warning at 80%, critical at 95%
  - Memory: warning at 85%, critical at 95%
  - Disk: warning at 80%, critical at 90%
  - Load Avg: warning at 8, critical at 12

**Stage 4: ROUTE**
- Send to MonitorAgent for processing

#### Helper Functions

```python
# Convert anomaly to alert format
alert = create_alert_from_anomaly(anomaly)

# Get top priority anomalies
top_alerts = get_top_anomalies(pipeline, limit=5)

# Filter by host or service
host_anomalies = pipeline.get_anomalies_by_host("prod-batch-01")
service_anomalies = pipeline.get_anomalies_by_service("data-transform")
```

## Usage Examples

### Basic Pipeline Execution

```python
from data_ingestion import (
    DataIngestionPipeline,
    SERVERS,
    SERVICES,
)

# Initialize and run pipeline
pipeline = DataIngestionPipeline(SERVERS, SERVICES)
results = pipeline.run_pipeline()

print(f"Total events: {results['total_events']}")
print(f"Anomalies: {results['anomalies']}")
print(f"Critical: {results['critical']}")
```

### Get Critical Alerts for Agents

```python
from data_ingestion import DataIngestionPipeline, create_alert_from_anomaly

pipeline = DataIngestionPipeline(SERVERS, SERVICES)
pipeline.run_pipeline()

# Get critical anomalies
critical = pipeline.get_critical_anomalies()

# Convert to alert format for MonitorAgent
for anomaly in critical:
    alert = create_alert_from_anomaly(anomaly)
    monitor_agent.receive_alert(alert)
```

### Filter by Service Tier

```python
# Get all BATCH service anomalies (auto-remediation allowed)
batch_anomalies = [
    a for a in pipeline.anomalies
    if a.get_service_tier() == "batch"
]

# Get all CRITICAL service anomalies (require approval)
critical_services = [
    a for a in pipeline.anomalies
    if a.get_service_tier() == "critical"
]
```

### Access Mock Data Directly

```python
from data_ingestion import (
    SERVERS,
    SERVICES,
    get_server_by_hostname,
    get_service_by_name,
    get_services_on_host,
)

# Get server metrics
server = get_server_by_hostname("prod-batch-01")
print(f"CPU: {server.cpu_percent}%")

# Get service info
service = get_service_by_name("data-transform")
print(f"Tier: {service.tier.value}")
print(f"Owner: {service.owner_team}")

# Get all services on a host
services = get_services_on_host("prod-web-07")
print(f"Services: {[s.service_name for s in services]}")
```

## Integration with Agents

### MonitorAgent (Agent 1)

Receives alerts from the ingestion pipeline:

```python
from data_ingestion import DataIngestionPipeline, create_alert_from_anomaly

pipeline = DataIngestionPipeline(SERVERS, SERVICES)
pipeline.run_pipeline()

# Send top anomaly to MonitorAgent
top_anomaly = pipeline.get_critical_anomalies()[0]
alert = create_alert_from_anomaly(top_anomaly)

enriched_alert = monitor_agent.receive_alert(alert)
```

### DiagnosisAgent (Agent 2)

Uses enrichment data for context:

```python
alert = create_alert_from_anomaly(anomaly)

# Enrichment data available for diagnosis
service_tier = alert["enrichment"]["service_tier"]
owner_team = alert["enrichment"]["owner_team"]
dependencies = alert["enrichment"]["dependencies"]

# Query Vector DB with context
diagnosis = diagnosis_agent.diagnose(alert)
```

## Production Integration

In production, replace mock data with real integrations:

### Prometheus
```python
from prometheus_api_client import PrometheusConnect

prom = PrometheusConnect(url="http://prometheus:9090")
query = 'rate(cpu_usage_seconds_total[5m])'
result = prom.custom_query(query=query)
```

### Datadog
```python
from datadog import api, initialize

initialize(api_key="...", app_key="...")
metrics = api.Metric.query(
    start=now - 300,
    end=now,
    query="avg:system.cpu.user{*}"
)
```

### Kubernetes
```python
from kubernetes import client, config

config.load_kube_config()
v1 = client.CoreV1Api()
pods = v1.list_pod_for_all_namespaces()
```

## Threshold Configuration

Customize thresholds in `pipeline.py`:

```python
pipeline = DataIngestionPipeline(SERVERS, SERVICES)
pipeline.thresholds = {
    "cpu_percent": {"warning": 70, "critical": 90},
    "memory_percent": {"warning": 80, "critical": 90},
    "disk_percent": {"warning": 75, "critical": 85},
    "load_avg_1m": {"warning": 10, "critical": 15},
}
```

## Statistics

- **5 Servers**: prod-web-07, prod-web-03, prod-db-01, prod-cache-02, prod-batch-01
- **5 Services**: billing-api, data-transform, user-service, notification-worker, redis-cache
- **5 K8s Pods**: Including OOMKilled and CrashLoopBackOff states
- **5 Application Logs**: ERROR and WARN level entries
- **~20 Telemetry Events** per pipeline run
- **~8 Anomalies** detected per run (with current mock data)

## Next Steps

1. **Test the pipeline**:
   ```bash
   python -m data_ingestion.pipeline
   ```

2. **Integrate with main.py**: Replace SECTION 2 and SECTION 3 with imports

3. **Add more data sources**: Kubernetes events, application logs, distributed traces

4. **Implement real monitoring**: Connect to Prometheus, Datadog, CloudWatch

---

**Status**: ✅ **Data Ingestion Module Ready!**
- Complete pipeline with COLLECT → ENRICH → DETECT stages
- Mock data for 5 servers and 5 services
- TelemetryEvent normalization for all sources
- Ready for agent integration