"""
Data Models for Telemetry and Infrastructure

This module defines the core data structures used throughout the ingestion pipeline:
- ServerMetrics: Server-level metrics (CPU, memory, disk, network)
- ServiceInfo: Service catalog information (tier, owner, dependencies)
- KubernetesPod: Kubernetes pod status and resources
- ApplicationLog: Application log entries
- TelemetryEvent: Unified telemetry event schema (normalized from all sources)
- ServiceTier: Enum for service tier classification
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import List, Dict, Any


class ServiceTier(Enum):
    """
    Service tier classification for auto-remediation policies.

    - CRITICAL: Never auto-remediate without human approval (e.g., billing-api, redis-cache)
    - STANDARD: Auto-restart allowed, alert ops (e.g., user-service, notification-worker)
    - BATCH: Auto-kill allowed if running > 15min above threshold (e.g., data-transform)
    """
    CRITICAL = "critical"
    STANDARD = "standard"
    BATCH = "batch"


@dataclass
class ServerMetrics:
    """
    Server-level infrastructure metrics from monitoring systems.

    Collected from: Prometheus, Datadog, CloudWatch, node_exporter
    """
    hostname: str
    cpu_percent: float
    memory_percent: float
    disk_percent: float
    network_rx_mbps: float
    network_tx_mbps: float
    load_avg_1m: float
    uptime_hours: float
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class ServiceInfo:
    """
    Service catalog entry from CMDB.

    Contains service metadata, dependencies, and operational policies.
    """
    service_name: str
    tier: ServiceTier
    owner_team: str
    host: str
    port: int
    dependencies: List[str]
    runbook_id: str
    sla_target: float  # e.g., 99.9 for 99.9% availability


@dataclass
class KubernetesPod:
    """
    Kubernetes pod status and resource allocation.

    Collected from: kubectl, Kubernetes API, k8s events
    """
    name: str
    namespace: str
    status: str  # Running, CrashLoopBackOff, OOMKilled, Pending
    restarts: int
    cpu_request: str
    memory_request: str
    node: str
    age_hours: float


@dataclass
class ApplicationLog:
    """
    Application log entry from centralized logging system.

    Collected from: ELK Stack (Elasticsearch), Splunk, CloudWatch Logs
    """
    timestamp: str
    service: str
    level: str  # ERROR, WARN, INFO, DEBUG
    message: str
    trace_id: str
    host: str


@dataclass
class TelemetryEvent:
    """
    Normalized telemetry event — unified schema for all monitoring sources.

    This is the canonical data structure used throughout the ingestion pipeline.
    Events from different sources (Prometheus, Datadog, CloudWatch, K8s) are
    normalized into this format for consistent processing.

    Lifecycle:
    1. COLLECT: Raw metrics → TelemetryEvent
    2. NORMALIZE: Convert source-specific formats → TelemetryEvent
    3. ENRICH: Add CMDB context → enrichment dict
    4. DETECT: Flag anomalies → severity field
    5. ROUTE: Send to appropriate agent
    """
    event_id: str
    timestamp: str
    source: str          # prometheus, datadog, cloudwatch, k8s
    host: str
    metric_name: str
    metric_value: float
    threshold: float
    severity: str        # critical, warning, info
    labels: Dict[str, Any]
    enrichment: Dict[str, Any] = field(default_factory=dict)  # Added by enrichment stage

    def to_alert_dict(self) -> dict:
        """
        Convert TelemetryEvent to alert format for MonitorAgent.

        Returns:
            dict: Alert in format expected by MonitorAgent
        """
        return {
            "alert": f"High{self.metric_name.replace('_', '').title()}",
            "server": self.host,
            f"{self.metric_name}": self.metric_value,
            "duration": "30m",  # Could be calculated from event history
            "threshold": self.threshold,
            "severity": self.severity,
            "event_id": self.event_id,
            "timestamp": self.timestamp,
            "source": self.source,
            "enrichment": self.enrichment,
        }

    def is_anomaly(self) -> bool:
        """Check if this event represents an anomaly."""
        return self.severity in ("critical", "warning")

    def get_service_tier(self) -> str:
        """Get service tier from enrichment data."""
        return self.enrichment.get("service_tier", "unknown")
