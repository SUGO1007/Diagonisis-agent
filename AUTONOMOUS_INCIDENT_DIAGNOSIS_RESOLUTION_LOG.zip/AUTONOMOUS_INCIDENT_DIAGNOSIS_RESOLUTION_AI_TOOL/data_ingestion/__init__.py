"""
Data Ingestion Package

This package provides data ingestion and telemetry processing capabilities:

- models: Data models (TelemetryEvent, ServerMetrics, ServiceInfo, etc.)
- mock_data: Mock infrastructure data for POC testing
- pipeline: Data ingestion pipeline with COLLECT → ENRICH → DETECT stages

Usage:
------
```python
from data_ingestion import (
    DataIngestionPipeline,
    TelemetryEvent,
    ServiceTier,
    SERVERS,
    SERVICES,
)

# Run ingestion pipeline
pipeline = DataIngestionPipeline(SERVERS, SERVICES)
results = pipeline.run_pipeline()

# Get critical alerts
critical_alerts = pipeline.get_critical_anomalies()

# Convert to alert format
from data_ingestion.pipeline import create_alert_from_anomaly
alert = create_alert_from_anomaly(critical_alerts[0])
```
"""

from .models import (
    ServiceTier,
    ServerMetrics,
    ServiceInfo,
    KubernetesPod,
    ApplicationLog,
    TelemetryEvent,
)

from .mock_data import (
    SERVERS,
    SERVICES,
    K8S_PODS,
    APP_LOGS,
    PROCESS_TABLE,
    get_server_by_hostname,
    get_service_by_name,
    get_services_on_host,
    get_process_info,
)

from .pipeline import (
    DataIngestionPipeline,
    create_alert_from_anomaly,
    get_top_anomalies,
)

__all__ = [
    # Models
    "ServiceTier",
    "ServerMetrics",
    "ServiceInfo",
    "KubernetesPod",
    "ApplicationLog",
    "TelemetryEvent",

    # Mock Data
    "SERVERS",
    "SERVICES",
    "K8S_PODS",
    "APP_LOGS",
    "PROCESS_TABLE",
    "get_server_by_hostname",
    "get_service_by_name",
    "get_services_on_host",
    "get_process_info",

    # Pipeline
    "DataIngestionPipeline",
    "create_alert_from_anomaly",
    "get_top_anomalies",
]
