"""
Mock Infrastructure Data for POC Testing

This module provides mock data for testing the agentic AI platform:
- SERVERS: Server fleet with current metrics
- SERVICES: Service catalog with tiers and dependencies
- K8S_PODS: Kubernetes pod status
- APP_LOGS: Application log entries
- PROCESS_TABLE: Process listings for servers

In production, this data would come from:
- CMDB (Configuration Management Database)
- Monitoring systems (Prometheus, Datadog, CloudWatch)
- Kubernetes API
- Log aggregation (ELK, Splunk)
- Process monitoring (psutil, telegraf)
"""

from .models import (
    ServerMetrics,
    ServiceInfo,
    ServiceTier,
    KubernetesPod,
    ApplicationLog,
)


# ═══════════════════════════════════════════════════════════════════════════
# SERVER FLEET INVENTORY
# ═══════════════════════════════════════════════════════════════════════════

SERVERS = {
    "prod-web-07": ServerMetrics(
        hostname="prod-web-07.us-east.internal",
        cpu_percent=98.5,
        memory_percent=45.2,
        disk_percent=62.0,
        network_rx_mbps=120.5,
        network_tx_mbps=85.3,
        load_avg_1m=12.4,
        uptime_hours=720.0
    ),
    "prod-web-03": ServerMetrics(
        hostname="prod-web-03.us-east.internal",
        cpu_percent=35.2,
        memory_percent=52.1,
        disk_percent=55.0,
        network_rx_mbps=95.0,
        network_tx_mbps=62.1,
        load_avg_1m=2.1,
        uptime_hours=1440.0
    ),
    "prod-db-01": ServerMetrics(
        hostname="prod-db-01.us-east.internal",
        cpu_percent=72.0,
        memory_percent=88.5,
        disk_percent=78.0,
        network_rx_mbps=200.0,
        network_tx_mbps=180.0,
        load_avg_1m=4.5,
        uptime_hours=2160.0
    ),
    "prod-cache-02": ServerMetrics(
        hostname="prod-cache-02.us-east.internal",
        cpu_percent=15.0,
        memory_percent=92.0,
        disk_percent=20.0,
        network_rx_mbps=500.0,
        network_tx_mbps=480.0,
        load_avg_1m=1.2,
        uptime_hours=4320.0
    ),
    "prod-batch-01": ServerMetrics(
        hostname="prod-batch-01.us-east.internal",
        cpu_percent=95.0,
        memory_percent=60.0,
        disk_percent=45.0,
        network_rx_mbps=10.0,
        network_tx_mbps=5.0,
        load_avg_1m=8.0,
        uptime_hours=168.0
    ),
}


# ═══════════════════════════════════════════════════════════════════════════
# SERVICE CATALOG
# ═══════════════════════════════════════════════════════════════════════════

SERVICES = {
    "billing-api": ServiceInfo(
        service_name="billing-api",
        tier=ServiceTier.CRITICAL,
        owner_team="payments-team",
        host="prod-web-07",
        port=8080,
        dependencies=["postgres-billing", "redis-cache", "stripe-gateway"],
        runbook_id="RB-001",
        sla_target=99.99
    ),
    "data-transform": ServiceInfo(
        service_name="data-transform",
        tier=ServiceTier.BATCH,
        owner_team="data-engineering",
        host="prod-batch-01",
        port=9090,
        dependencies=["kafka-cluster", "s3-datalake"],
        runbook_id="RB-005",
        sla_target=95.0
    ),
    "user-service": ServiceInfo(
        service_name="user-service",
        tier=ServiceTier.STANDARD,
        owner_team="platform-team",
        host="prod-web-03",
        port=8081,
        dependencies=["postgres-users", "redis-sessions"],
        runbook_id="RB-002",
        sla_target=99.9
    ),
    "notification-worker": ServiceInfo(
        service_name="notification-worker",
        tier=ServiceTier.STANDARD,
        owner_team="comms-team",
        host="prod-web-03",
        port=8082,
        dependencies=["rabbitmq", "sendgrid-api"],
        runbook_id="RB-003",
        sla_target=99.5
    ),
    "redis-cache": ServiceInfo(
        service_name="redis-cache",
        tier=ServiceTier.CRITICAL,
        owner_team="infra-team",
        host="prod-cache-02",
        port=6379,
        dependencies=[],
        runbook_id="RB-004",
        sla_target=99.99
    ),
}


# ═══════════════════════════════════════════════════════════════════════════
# KUBERNETES POD STATUS
# ═══════════════════════════════════════════════════════════════════════════

K8S_PODS = [
    KubernetesPod(
        name="billing-api-7d4f8b-xk2p9",
        namespace="production",
        status="Running",
        restarts=0,
        cpu_request="500m",
        memory_request="512Mi",
        node="node-1",
        age_hours=48.0
    ),
    KubernetesPod(
        name="billing-api-7d4f8b-m3k1q",
        namespace="production",
        status="Running",
        restarts=0,
        cpu_request="500m",
        memory_request="512Mi",
        node="node-2",
        age_hours=48.0
    ),
    KubernetesPod(
        name="user-service-5c3a1-p9x2r",
        namespace="production",
        status="CrashLoopBackOff",
        restarts=15,
        cpu_request="250m",
        memory_request="256Mi",
        node="node-1",
        age_hours=2.0
    ),
    KubernetesPod(
        name="data-pipeline-batch-7291",
        namespace="batch-jobs",
        status="Running",
        restarts=0,
        cpu_request="2000m",
        memory_request="4Gi",
        node="node-3",
        age_hours=0.5
    ),
    KubernetesPod(
        name="notification-worker-8b2c-k4m1",
        namespace="production",
        status="OOMKilled",
        restarts=3,
        cpu_request="128m",
        memory_request="128Mi",
        node="node-2",
        age_hours=1.0
    ),
]


# ═══════════════════════════════════════════════════════════════════════════
# APPLICATION LOGS
# ═══════════════════════════════════════════════════════════════════════════

APP_LOGS = [
    ApplicationLog(
        timestamp="2025-01-15T14:32:01Z",
        service="data-transform",
        level="ERROR",
        message="OutOfMemoryError: Java heap space during batch-7291 processing",
        trace_id="trace-abc123",
        host="prod-batch-01"
    ),
    ApplicationLog(
        timestamp="2025-01-15T14:32:15Z",
        service="data-transform",
        level="ERROR",
        message="Process stuck in infinite loop - partition 7 reprocessing same offset",
        trace_id="trace-abc124",
        host="prod-batch-01"
    ),
    ApplicationLog(
        timestamp="2025-01-15T14:33:00Z",
        service="billing-api",
        level="WARN",
        message="Response latency > 2s for /api/v1/invoices endpoint",
        trace_id="trace-def456",
        host="prod-web-07"
    ),
    ApplicationLog(
        timestamp="2025-01-15T14:35:00Z",
        service="user-service",
        level="ERROR",
        message="Connection pool exhausted - max connections (50) reached",
        trace_id="trace-ghi789",
        host="prod-web-03"
    ),
    ApplicationLog(
        timestamp="2025-01-15T14:36:00Z",
        service="notification-worker",
        level="ERROR",
        message="OOM killed by kernel - RSS exceeded 128Mi limit",
        trace_id="trace-jkl012",
        host="prod-web-03"
    ),
]


# ═══════════════════════════════════════════════════════════════════════════
# PROCESS TABLE (ps aux output)
# ═══════════════════════════════════════════════════════════════════════════

PROCESS_TABLE = {
    "prod-web-07": [
        {
            "pid": 8421,
            "user": "appuser",
            "cpu": 97.2,
            "mem": 12.1,
            "command": "/opt/etl/data-transform --job=batch-7291"
        },
        {
            "pid": 1102,
            "user": "nginx",
            "cpu": 0.5,
            "mem": 0.5,
            "command": "nginx: worker process"
        },
        {
            "pid": 2201,
            "user": "appuser",
            "cpu": 0.3,
            "mem": 2.1,
            "command": "/usr/bin/billing-api --port=8080"
        },
        {
            "pid": 1,
            "user": "root",
            "cpu": 0.0,
            "mem": 0.2,
            "command": "/sbin/init"
        },
    ],
    "prod-batch-01": [
        {
            "pid": 5510,
            "user": "etluser",
            "cpu": 95.0,
            "mem": 58.0,
            "command": "/opt/etl/data-transform --job=batch-7291 --partition=7"
        },
        {
            "pid": 1,
            "user": "root",
            "cpu": 0.0,
            "mem": 0.1,
            "command": "/sbin/init"
        },
    ]
}


# ═══════════════════════════════════════════════════════════════════════════
# HELPER FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════

def get_server_by_hostname(hostname: str) -> ServerMetrics:
    """
    Get server metrics by hostname.

    Args:
        hostname: Short hostname (e.g., 'prod-web-07')

    Returns:
        ServerMetrics object or None if not found
    """
    return SERVERS.get(hostname)


def get_service_by_name(service_name: str) -> ServiceInfo:
    """
    Get service info by service name.

    Args:
        service_name: Service identifier (e.g., 'billing-api')

    Returns:
        ServiceInfo object or None if not found
    """
    return SERVICES.get(service_name)


def get_services_on_host(hostname: str) -> list:
    """
    Get all services running on a specific host.

    Args:
        hostname: Short hostname (e.g., 'prod-web-07')

    Returns:
        List of ServiceInfo objects
    """
    return [s for s in SERVICES.values() if s.host == hostname]


def get_process_info(hostname: str, pid: int) -> dict:
    """
    Get process information by hostname and PID.

    Args:
        hostname: Short hostname
        pid: Process ID

    Returns:
        Process dict or None if not found
    """
    processes = PROCESS_TABLE.get(hostname, [])
    for proc in processes:
        if proc["pid"] == pid:
            return proc
    return None
