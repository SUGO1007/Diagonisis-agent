# Installation & Setup Guide

Complete step-by-step guide to install and configure the Agentic AI Platform.

## Table of Contents

1. [System Requirements](#system-requirements)
2. [Installation Steps](#installation-steps)
3. [Configuration](#configuration)
4. [Verification](#verification)
5. [Troubleshooting](#troubleshooting)

## System Requirements

### Minimum Requirements
- **Python**: 3.10+
- **RAM**: 4GB (8GB recommended)
- **Disk**: 500MB free space
- **Network**: Internet connection for API calls

### Recommended Setup
- **Python**: 3.11 or 3.12
- **RAM**: 8GB+
- **OS**: Linux (Ubuntu 20.04+) or macOS 12+
- **OS**: Windows 10/11 with WSL2 (recommended)

### Dependencies
- pip or Poetry (package managers)
- Git (for version control)
- curl or wget (for testing APIs)

## Installation Steps

### Step 1: Clone or Extract Repository

If you have the repository as a ZIP:

```bash
# Extract to your desired location
unzip agentic-ai-platform.zip
cd agentic-ai-platform
```

Or if you have Git:

```bash
git clone https://github.com/your-org/agentic-ai-platform.git
cd agentic-ai-platform
```

### Step 2: Create Virtual Environment

**Using venv (built-in):**

```bash
# Create virtual environment
python -m venv venv

# Activate (Linux/macOS)
source venv/bin/activate

# Activate (Windows)
venv\Scripts\activate
```

**Using Conda:**

```bash
conda create -n agentic-ai python=3.11
conda activate agentic-ai
```

### Step 3: Install the Package

**Development Installation (recommended for development):**

```bash
pip install -e ".[dev]"
```

This installs:
- Core dependencies (langchain, pydantic, etc.)
- Development tools (pytest, black, mypy)

**Production Installation:**

```bash
pip install .
```

This installs only core dependencies.

**With optional features:**

```bash
# With vector database support
pip install -e ".[vector-db]"

# With additional LLM providers
pip install -e ".[llm-extras]"

# With everything
pip install -e ".[dev,vector-db,llm-extras]"
```

### Step 4: Verify Installation

```bash
# Check Python version
python --version  # Should be 3.10+

# Check package installation
pip list | grep agentic

# Try importing
python -c "from agentic_ai_platform.core import get_config; print('✓ Installation successful')"
```

## Configuration

### Step 1: Create .env File

```bash
cp .env .env.local
```

### Step 2: Get API Keys

#### Mistral AI (Required)

1. Go to [Mistral AI Console](https://console.mistral.ai/)
2. Sign up or log in
3. Create a new API key
4. Copy the key

#### Optional: Other LLM Providers

**OpenAI:**
1. Go to [OpenAI API Keys](https://platform.openai.com/api-keys)
2. Create a new API key

**Anthropic (Claude):**
1. Go to [Anthropic Console](https://console.anthropic.com/)
2. Create a new API key

### Step 3: Edit .env File

```bash
# Edit with your preferred editor
nano .env.local       # Linux/macOS
notepad .env.local    # Windows (PowerShell)
```

#### Minimum Configuration

```ini
# LLM Configuration (Required)
MISTRAL_API_KEY=your-mistral-api-key-here
LLM_MODEL=mistral-large-latest
LLM_TEMPERATURE=0.1

# Application
ENVIRONMENT=development
DEBUG=false

# Logging
LOG_LEVEL=INFO
```

#### Full Configuration Example

```ini
# ═══════════════════════════════════════════════════════════════
# Application Settings
# ═══════════════════════════════════════════════════════════════
APP_NAME=agentic-ai-platform
APP_VERSION=1.0.0
ENVIRONMENT=development  # development, staging, production
DEBUG=false

# ═══════════════════════════════════════════════════════════════
# LLM Configuration
# ═══════════════════════════════════════════════════════════════
LLM_PROVIDER=mistral  # mistral, openai, anthropic
LLM_MODEL=mistral-large-latest
MISTRAL_API_KEY=your-key-here
LLM_TEMPERATURE=0.1   # 0=deterministic, 1=creative
LLM_MAX_TOKENS=2000
LLM_TIMEOUT=30

# Alternative LLM Providers
# OpenAI
# OPENAI_API_KEY=sk-...
# LLM_PROVIDER=openai
# LLM_MODEL=gpt-4

# Anthropic
# ANTHROPIC_API_KEY=sk-ant-...
# LLM_PROVIDER=anthropic
# LLM_MODEL=claude-opus-4

# ═══════════════════════════════════════════════════════════════
# MCP Server Configuration
# ═══════════════════════════════════════════════════════════════
MCP_TELEMETRY_HOST=localhost
MCP_TELEMETRY_PORT=8001
MCP_SSH_HOST=localhost
MCP_SSH_PORT=8002
MCP_CMDB_HOST=localhost
MCP_CMDB_PORT=8003
MCP_ALERTING_HOST=localhost
MCP_ALERTING_PORT=8004
MCP_RUNBOOK_HOST=localhost
MCP_RUNBOOK_PORT=8005

# ═══════════════════════════════════════════════════════════════
# Vector Database Configuration
# ═══════════════════════════════════════════════════════════════
VECTOR_DB_PROVIDER=mock  # mock, pinecone, weaviate, chromadb
# VECTOR_DB_ENDPOINT=https://your-endpoint.pinecone.io
# VECTOR_DB_API_KEY=your-key-here
VECTOR_DB_INDEX=incidents
EMBEDDING_MODEL=all-MiniLM-L6-v2
SIMILARITY_THRESHOLD=0.7

# ═══════════════════════════════════════════════════════════════
# Agent Configuration
# ═══════════════════════════════════════════════════════════════
DIAGNOSIS_THRESHOLD=0.80          # Min confidence for diagnosis
GATHERING_THRESHOLD=0.85          # Min confidence for remediation
MAX_GATHERING_ITERATIONS=10       # Max ReAct loop iterations
APPROVAL_REQUIRED_TIERS=critical,high

# ═══════════════════════════════════════════════════════════════
# Logging Configuration
# ═══════════════════════════════════════════════════════════════
LOG_LEVEL=INFO  # DEBUG, INFO, WARNING, ERROR, CRITICAL
LOG_FILE=logs/agentic-ai.log
ENABLE_FILE_LOGGING=false
LOG_MAX_BYTES=10485760  # 10MB
LOG_BACKUP_COUNT=5
```

### Step 4: Verify Configuration

```bash
python -c "
from agentic_ai_platform.core import get_config
config = get_config()
print(f'✓ Configuration loaded')
print(f'  Environment: {config.environment}')
print(f'  LLM: {config.llm.model}')
print(f'  Debug: {config.debug}')
"
```

## Verification

### Test 1: Python Imports

```bash
python << 'EOF'
print("Testing imports...")

# Core
from agentic_ai_platform.core import (
    get_config, LoggerFactory, generate_id
)
print("✓ Core imports")

# Agents
from agentic_ai_platform.agents import (
    MonitorAgent, DiagnosisAgent, RemediationAgent, LearnerAgent
)
print("✓ Agent imports")

# Orchestration
from agentic_ai_platform.orchestration import AgentOrchestrator
print("✓ Orchestration imports")

# MCP
from agentic_ai_platform.mcp import MCPClient
print("✓ MCP imports")

print("\n✅ All imports successful!")
EOF
```

### Test 2: Configuration Loading

```bash
python << 'EOF'
from agentic_ai_platform.core import get_config

config = get_config()
print(f"Environment: {config.environment}")
print(f"LLM Provider: {config.llm.provider}")
print(f"LLM Model: {config.llm.model}")
print(f"Diagnosis Threshold: {config.agent.diagnosis_confidence_threshold:.0%}")
print("✅ Configuration loaded successfully!")
EOF
```

### Test 3: Run Simple Example

```bash
python << 'EOF'
from agentic_ai_platform.orchestration import AgentOrchestrator
from agentic_ai_platform.mcp import MCPClient

print("Initializing system...")
mcp = MCPClient()
kb = {"incident_history": []}
orchestrator = AgentOrchestrator(mcp, kb)
print("✓ System initialized")

print("Processing test alert...")
alert = {
    "alert": "high_cpu",
    "server": "prod-01",
    "cpu_percent": 95,
    "severity": "critical"
}

result = orchestrator.process_alert(alert)
print(f"✓ Alert processed")
print(f"  Status: {'SUCCESS' if result['success'] else 'FAILED'}")
print(f"  Diagnosis: {result['diagnosis'].root_cause}")
print("✅ Example completed successfully!")
EOF
```

## Troubleshooting

### Issue: "ModuleNotFoundError: No module named 'agentic_ai_platform'"

**Solution:**
```bash
# Make sure you're in the right directory
cd agentic-ai-platform

# Reinstall in editable mode
pip install -e "."

# Verify installation
pip list | grep agentic-ai
```

### Issue: "MISTRAL_API_KEY not found"

**Solution:**
```bash
# Check if .env.local exists
ls -la .env.local  # Linux/macOS
dir .env.local     # Windows

# Check if it has the key
grep MISTRAL_API_KEY .env.local

# If missing, add it
echo "MISTRAL_API_KEY=your-key-here" >> .env.local
```

### Issue: "Import error from config"

**Solution:**
```bash
# Check Python version (must be 3.10+)
python --version

# Reinstall with correct dependencies
pip install --upgrade pip
pip install -e ".[dev]"
```

### Issue: "MCP server connection refused"

**Solution (for POC):**
This is normal in POC mode. The system uses mock implementations.

For production MCP servers, ensure they're running:
```bash
# Check if servers are listening
curl localhost:8001
curl localhost:8002
# ... etc

# Or check with netstat
netstat -tuln | grep 800
```

### Issue: "LLM API key invalid"

**Solution:**
```bash
# Test API key directly
python << 'EOF'
import os
from agentic_ai_platform.core import get_config

config = get_config()
if not config.llm.api_key:
    print("❌ API key not set")
else:
    print("✓ API key is set")
    # Try initialization (don't expose key)
    print(f"  Provider: {config.llm.provider}")
    print(f"  Model: {config.llm.model}")
EOF
```

### Issue: "Port already in use"

**Solution:**
If MCP server ports are in use:
```bash
# Linux/macOS - find process using port
lsof -i :8001

# Windows
netstat -ano | findstr :8001

# Kill process (get PID from above)
kill -9 <PID>  # Linux/macOS
taskkill /PID <PID> /F  # Windows
```

### Issue: "Memory error"

**Solution:**
```bash
# Check available RAM
free -h  # Linux
wc -l   # macOS

# If low on memory:
# 1. Close other applications
# 2. Use smaller batch sizes
# 3. Reduce LLM max_tokens in .env
LLM_MAX_TOKENS=1000
```

## Performance Tuning

### For Development
```ini
LLM_TEMPERATURE=0.3     # Some randomness
LLM_MAX_TOKENS=1000     # Faster responses
LOG_LEVEL=DEBUG         # More visibility
```

### For Production
```ini
LLM_TEMPERATURE=0.1     # Deterministic
LLM_MAX_TOKENS=2000     # Better quality
LOG_LEVEL=INFO          # Less overhead
VECTOR_DB_PROVIDER=pinecone  # Real Vector DB
```

### For Testing
```ini
VECTOR_DB_PROVIDER=mock # Fast, no API calls
LLM_TEMPERATURE=0.0     # Consistent results
LOG_LEVEL=WARNING       # Less output
```

## Next Steps

1. **Read Documentation**
   - [QUICKSTART.md](./QUICKSTART.md) - 5 minutes
   - [ARCHITECTURE.md](./ARCHITECTURE.md) - Deep dive
   - [README.md](../README.md) - Full overview

2. **Run Examples**
   ```bash
   python examples/simple_alert.py
   python examples/with_learning.py
   ```

3. **Run Tests**
   ```bash
   pytest tests/ -v
   pytest tests/agents/ -v
   ```

4. **Explore Code**
   - Start with `agents/monitor_agent/`
   - Then `agents/diagnosis_agent/`
   - Then `orchestration/orchestration.py`

5. **Customize**
   - Add your own agents in `agents/`
   - Connect real MCP servers
   - Integrate with your monitoring system

## Support

- **Issues**: Check [Troubleshooting](#troubleshooting) section
- **Docs**: See `docs/` directory
- **Examples**: Check `examples/` directory (when created)
- **Tests**: See `tests/` directory

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2024 | Initial production-ready release |

---

**Installation Date**: ___________
**Verified By**: ___________
**Environment**: development / staging / production
