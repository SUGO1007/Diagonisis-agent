# Architecture Overview

## System Design

The Agentic AI Platform is a production-ready multi-agent system designed for autonomous incident diagnosis and remediation.

### Core Philosophy

1. **Separation of Concerns** - Each agent has a single, well-defined responsibility
2. **Modularity** - Agents, tools, and protocols are fully decoupled
3. **Safety First** - Pre-checks, post-checks, and automatic rollback
4. **Continuous Learning** - Human feedback drives system improvement
5. **Scalability** - Designed for production workloads with observability

## 5-Agent Pipeline

### 1. MonitorAgent
**Responsibility**: Alert ingestion and enrichment

**Inputs**: Raw alerts from monitoring systems
**Outputs**: EnrichedAlert with context

**Process**:
- Receive raw alert from Prometheus/Datadog/etc
- Query CMDB for server metadata
- Enrich with service context and dependencies
- Calculate priority based on blast radius
- Add historical incident context

**Why Separate?**
- Single point of alert ingestion
- Reduces cognitive load on diagnosis
- Enables rich context for better decisions

---

### 2. DiagnosisAgent
**Responsibility**: Root cause analysis

**Inputs**: EnrichedAlert
**Outputs**: Diagnosis with confidence score

**Process**:
- Query Vector DB for similar incidents (RAG)
- Analyze symptom patterns
- Determine root cause
- Calculate confidence score
- If confidence < threshold, generate questions for info gathering
- Provide recommended actions from similar incidents

**Why Separate?**
- Specializes in pattern matching
- Leverages historical knowledge
- Enables confidence-driven decisions
- Identifies info gaps proactively

---

### 3. InformationGatheringAgent
**Responsibility**: Iterative information collection (ReAct loop)

**Inputs**: Diagnosis with low confidence
**Outputs**: Complete context with improved confidence

**Process**:
1. **REASON**: Select next question to answer
2. **ACT**: Call appropriate MCP tool
3. **OBSERVE**: Process result
4. **UPDATE**: Recalculate confidence
5. Loop until: confidence >= threshold OR max_iterations

**Why Separate?**
- ReAct pattern for interactive learning
- Minimizes data collection (only what's needed)
- Confidence-driven termination
- Handles uncertainty explicitly

---

### 4. RemediationAgent
**Responsibility**: Safe execution with validation

**Inputs**: Diagnosis + Information + Decision
**Outputs**: RemediationResult

**Process**:
1. Capture current state (for rollback)
2. Run pre-flight checks
3. Execute remediation action
4. Capture state after
5. Run post-flight checks
6. Auto-rollback if any check fails

**Why Separate?**
- Centralizes safety checks
- Explicit rollback procedures
- Policy-driven approval workflows
- Tracks success/failure patterns

---

### 5. LearnerAgent
**Responsibility**: Continuous improvement

**Inputs**: Incident + AI Decision + Human Feedback
**Outputs**: Learned patterns, updated knowledge base

**Process**:
1. Capture human feedback (approve/reject/modify)
2. Extract learnable patterns
3. Update confidence scores of existing patterns
4. Generate runbooks from high-confidence patterns
5. Update knowledge base

**Why Separate?**
- Human-in-the-loop learning
- Makes the system smarter over time
- Generates operational runbooks
- Tracks learning metrics

## Data Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                          RAW ALERT                              │
│            (from Prometheus, Datadog, etc.)                     │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                    ┌──────▼──────┐
                    │   MONITOR   │  Enriches with:
                    │    AGENT    │  - CMDB metadata
                    └──────┬──────┘  - Service context
                           │         - Historical incidents
             ┌─────────────▼─────────────┐
             │  ENRICHED ALERT           │
             │  (alert_id, priority,     │
             │   severity, context)      │
             └────────────┬──────────────┘
                          │
                   ┌──────▼───────┐
                   │  DIAGNOSIS   │  Uses Vector DB RAG:
                   │    AGENT     │  - Semantic search
                   └──────┬───────┘  - Pattern matching
                          │          - Confidence scoring
             ┌────────────▼────────────┐
             │  DIAGNOSIS              │
             │  (root_cause,           │
             │   confidence, questions) │
             └────────────┬────────────┘
                          │
                   ┌──────▼──────────────┐
                   │  INFORMATION       │  ReAct Loop:
                   │  GATHERING         │  - Question selection
                   │  AGENT             │  - Tool execution
                   │  (Optional)        │  - Confidence update
                   └──────┬─────────────┘
                          │
             ┌────────────▼────────────┐
             │  COMPLETE CONTEXT       │
             │  (diagnosis +           │
             │   gathered info)        │
             └────────────┬────────────┘
                          │
                   ┌──────▼──────────┐
                   │  REMEDIATION   │  Safe execution:
                   │    AGENT       │  - Pre-checks
                   └──────┬──────────┘  - Execute
                          │            - Post-checks
             ┌────────────▼────────────┐ - Rollback
             │  REMEDIATION RESULT     │
             │  (success, rollback,    │
             │   execution_time)       │
             └────────────┬────────────┘
                          │
                   ┌──────▼──────────┐
                   │   LEARNER      │  Learning:
                   │    AGENT       │  - Capture feedback
                   └──────┬──────────┘  - Extract patterns
                          │            - Update KB
             ┌────────────▼────────────┐
             │  INCIDENT RESOLVED      │
             │  Knowledge base         │
             │  updated for future     │
             └────────────────────────┘
```

## Confidence-Driven Decision Making

### Why Confidence Matters

The system doesn't make binary yes/no decisions. Instead, it tracks confidence levels:

- **Low confidence** → Gather more information
- **High confidence** → Execute remediation
- **Very high confidence** → Can auto-execute

### Confidence Thresholds

| Stage | Threshold | Action |
|-------|-----------|--------|
| Diagnosis | 80% | Triggers information gathering if below |
| Gathering | 85% | Ready for remediation if reached |
| Learning | 80% | Can learn/reuse patterns if above |

### Confidence Factors

**Increases when**:
- Multiple similar incidents agree on root cause
- Recent incident with exact same symptoms
- Long incident history (5+ similar cases)
- Human feedback validates prediction

**Decreases when**:
- No historical precedent
- Conflicting symptoms
- Rare incident type
- Uncertain LLM predictions

## MCP Integration

### What is MCP?

Model Context Protocol (MCP) - A standardized JSON-RPC protocol for LLM ↔ Tool communication.

Benefits:
- **Decoupled**: Tools don't need to know about agents
- **Standardized**: Works with any LLM
- **Extensible**: Easy to add new servers
- **Observable**: All tool calls are logged

### Included MCP Servers

1. **TelemetryServer** (port 8001)
   - `query_metrics` - Get system metrics
   - `get_application_logs` - Fetch logs
   - `get_cpu_usage` - CPU stats
   - `get_memory_usage` - Memory stats

2. **SSHExecServer** (port 8002)
   - `get_process_list` - List running processes
   - `kill_process` - Terminate process
   - `execute_command` - Run arbitrary command
   - `get_system_info` - System information

3. **CMDBServer** (port 8003)
   - `get_server_metadata` - CMDB data
   - `get_service_info` - Service details
   - `get_recent_changes` - Deployments
   - `get_dependencies` - Service dependencies

4. **AlertingServer** (port 8004)
   - `send_alert` - Send alert
   - `acknowledge_alert` - Acknowledge
   - `create_incident` - Create incident
   - `update_incident` - Update status

5. **RunbookServer** (port 8005)
   - `get_runbook` - Fetch runbook
   - `execute_runbook` - Execute steps
   - `list_runbooks` - Available runbooks
   - `validate_runbook` - Validate syntax

## Vector DB RAG

### What is RAG?

Retrieval Augmented Generation - Enhancing LLM decisions with historical knowledge.

### How it Works

```
DIAGNOSIS AGENT
│
├─ Incoming Alert
│  └─ Convert to vector embedding
│
├─ Query Vector DB
│  └─ Find N most similar incidents
│     (using cosine similarity)
│
├─ Analyze Patterns
│  └─ If multiple matches agree on root cause
│     └─ Confidence increases
│
└─ Return Diagnosis
   └─ With recommended actions from history
```

### Supported Vector DBs

- **Mock** - Simple in-memory (for POC)
- **Pinecone** - Serverless cloud (recommended)
- **Weaviate** - Open source, self-hosted
- **ChromaDB** - Lightweight, local

## Safety & Approval

### Pre-Flight Checks
Validate before execution:
- Service is in right state
- Required resources available
- No conflicting operations
- Backup exists (if needed)

### Post-Flight Checks
Validate after execution:
- Metrics improved
- No new errors
- Service responding
- No cascading failures

### Automatic Rollback
If any check fails:
1. Immediately stop execution
2. Restore previous state
3. Alert operators
4. Log incident

### Approval Workflows
| Tier | Action | Approval? |
|------|--------|-----------|
| critical | kill_process | YES (always) |
| critical | restart | YES (always) |
| high | kill_process | YES |
| high | restart | YES |
| standard | kill_process | NO (batch info) |
| batch | any | NO |

## Logging & Observability

All agents log their activities:

```python
from agentic_ai_platform.core import LoggerFactory

logger = LoggerFactory.get_logger("my_component")
logger.info("Processing alert")
logger.warning("Confidence below threshold")
logger.error("Pre-flight check failed")
```

Log levels:
- **DEBUG** - Detailed execution flow
- **INFO** - Key events
- **WARNING** - Anomalies
- **ERROR** - Failures

## Performance Characteristics

### Latency
- MonitorAgent: ~50ms
- DiagnosisAgent: ~500ms (with Vector DB)
- InformationGatheringAgent: ~2-10s (per iteration)
- RemediationAgent: ~1-5s (depends on action)
- LearnerAgent: ~100ms

### Throughput
- Single instance: ~100 alerts/second
- With MCP parallelization: ~1000 alerts/second
- Horizontal scaling: Linear with instance count

### Scalability
- Stateless agents (horizontally scalable)
- Vector DB required for knowledge sharing
- Knowledge base: ~100K incidents per GB RAM

## Next Steps

- See [QUICKSTART.md](./QUICKSTART.md) for 5-minute setup
- Read [architecture.md](./ARCHITECTURE.md) for deep dive
- Check [migration.md](./MIGRATION.md) to upgrade existing code
- Explore [examples/](../examples/) for use cases
