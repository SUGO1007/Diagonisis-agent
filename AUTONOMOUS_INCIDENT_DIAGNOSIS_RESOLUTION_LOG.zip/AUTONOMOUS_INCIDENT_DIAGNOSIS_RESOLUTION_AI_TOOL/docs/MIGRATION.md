# Migration Guide: From Notebook to Production Architecture

## Overview

This guide explains how code from the original `agentic_ai_mcp_poc.ipynb` and `multi_agent_architecture.py` was reorganized into the new production architecture.

## File Mapping

### Core Infrastructure

| Original | New Location | Purpose |
|----------|--------------|---------|
| N/A | `core/config.py` | Configuration management |
| N/A | `core/logging.py` | Logging setup |
| N/A | `core/exceptions.py` | Custom exceptions |
| N/A | `core/utils.py` | Utility functions |
| N/A | `core/constants.py` | Constants & defaults |

### Agents

| Original | New Location | Purpose |
|----------|--------------|---------|
| `multi_agent_architecture.py` - `MonitorAgent` | `agents/monitor_agent/` | Alert enrichment |
| `multi_agent_architecture.py` - `DiagnosisAgent` | `agents/diagnosis_agent/` | Root cause analysis |
| Inline in notebook | `agents/gathering_agent/` | Information gathering (ReAct) |
| `multi_agent_architecture.py` - `RemediationAgent` | `agents/remediation_agent/` | Safe execution |
| `multi_agent_architecture.py` - `LearnerAgent` | `agents/learner_agent/` | Learning & improvement |

### MCP (Model Context Protocol)

| Original | New Location | Purpose |
|----------|--------------|---------|
| Inline in notebook | `mcp/client.py` | MCP client for tool calling |
| Inline in notebook | `mcp/server.py` | MCP server implementations |
| N/A | `mcp/schemas.py` | Data models for MCP |

### Orchestration

| Original | New Location | Purpose |
|----------|--------------|---------|
| `multi_agent_architecture.py` - `MultiAgentOrchestrator` | `orchestration/orchestration.py` | Coordinates all agents |

## Key Changes

### 1. Configuration Management

**Before** (Notebook):
```python
MISTRAL_API_KEY = "your-key"  # Hardcoded
mcp_client = MCPClient(...)   # Manual setup
```

**After** (Production):
```python
from agentic_ai_platform.core import get_config

config = get_config()  # Loaded from .env
mcp_client = MCPClient()  # Configured via config
```

### 2. Agent Instantiation

**Before** (Notebook):
```python
monitor = MonitorAgent(mcp_client, kb)
diagnosis = DiagnosisAgent(kb)
remediation = RemediationAgent(mcp_client, kb)
learner = LearnerAgent(kb)
```

**After** (Production):
```python
from agentic_ai_platform.orchestration import AgentOrchestrator

orchestrator = AgentOrchestrator(mcp_client, kb)
# Agents created internally
```

### 3. Agent Processing

**Before** (Notebook):
```python
enriched_alert = monitor.receive_alert(raw_alert)
diagnosis = diagnosis_agent.diagnose(enriched_alert)
remediation_result = remediation.execute_with_safety(action)
```

**After** (Production):
```python
monitor_result = monitor.process(raw_alert)
enriched_alert = monitor_result["enriched_alert"]

diagnosis_result = diagnosis.process({"enriched_alert": enriched_alert})
diagnosis = diagnosis_result["diagnosis"]

remediation_result = remediation.process({"incident": incident, "decision": decision})
```

## Dataclass Locations

| Dataclass | Original | New Location |
|-----------|----------|--------------|
| `EnrichedAlert` | `multi_agent_architecture.py` | `agents/monitor_agent/` |
| `Diagnosis` | `multi_agent_architecture.py` | `agents/diagnosis_agent/` |
| `RemediationAction` | `multi_agent_architecture.py` | `agents/remediation_agent/` |
| `RemediationResult` | `multi_agent_architecture.py` | `agents/remediation_agent/` |
| `HumanFeedback` | `multi_agent_architecture.py` | `agents/learner_agent/` |
| `LearnedPattern` | `multi_agent_architecture.py` | `agents/learner_agent/` |

## Imports

### Before (Notebook & multi_agent_architecture.py):
```python
from multi_agent_architecture import (
    MonitorAgent,
    DiagnosisAgent,
    RemediationAgent,
    LearnerAgent,
)
```

### After (Production):
```python
from agentic_ai_platform.agents import (
    MonitorAgent,
    DiagnosisAgent,
    RemediationAgent,
    LearnerAgent,
)
from agentic_ai_platform.orchestration import AgentOrchestrator
from agentic_ai_platform.mcp import MCPClient, TelemetryServer, SSHExecServer
from agentic_ai_platform.core import get_config, LoggerFactory
```

## Migration Steps

### Step 1: Update imports in your code

```python
# Old
from multi_agent_architecture import MonitorAgent

# New
from agentic_ai_platform.agents import MonitorAgent
```

### Step 2: Use configuration management

```python
# Old
MISTRAL_API_KEY = os.getenv("MISTRAL_API_KEY")

# New
from agentic_ai_platform.core import get_config
config = get_config()  # Automatically loads from .env
```

### Step 3: Replace manual orchestration with AgentOrchestrator

```python
# Old
monitor = MonitorAgent(mcp, kb)
diagnosis = DiagnosisAgent(kb)
remediation = RemediationAgent(mcp, kb)
learner = LearnerAgent(kb)

# Manual flow
enriched = monitor.receive_alert(alert)
diag = diagnosis.diagnose(enriched)
rem = remediation.execute_with_safety(action)
learner.capture_feedback(...)

# New
from agentic_ai_platform.orchestration import AgentOrchestrator

orchestrator = AgentOrchestrator(mcp, kb)
result = orchestrator.process_alert(alert)
# All agents coordinated automatically
```

### Step 4: Use new process() interface

All agents now use a unified `process(data: Dict) -> Dict` interface:

```python
# Old
enriched_alert = agent.receive_alert(raw_alert)

# New
result = agent.process({"raw_alert": raw_alert})
enriched_alert = result["enriched_alert"]
```

## Breaking Changes

### 1. Agent initialization now requires IDs

```python
# Old
agent = MonitorAgent(mcp, kb)  # ID auto-generated

# New
agent = MonitorAgent(mcp, kb)  # ID auto-generated in __init__
# Or explicitly:
agent.agent_id = "CUSTOM-ID"
```

### 2. Configuration via environment variables

```python
# Old - hardcoded
LLM_TEMP = 0.1

# New - from .env
LLM_TEMPERATURE=0.1  # in .env file
```

### 3. Dataclass immutability

Some dataclasses are now immutable (@dataclass with frozen=True):

```python
# Old
result = RemediationResult(...)
result.success = True  # ❌ Will fail

# New - create new instance if changes needed
result = RemediationResult(..., success=True)
```

## Backward Compatibility

The old `multi_agent_architecture.py` code is still compatible. You can use the old classes alongside new ones:

```python
# Both work
from multi_agent_architecture import MonitorAgent as OldMonitor
from agentic_ai_platform.agents import MonitorAgent as NewMonitor

old_agent = OldMonitor(mcp, kb)
new_agent = NewMonitor(mcp, kb)
```

## Testing Migration

Run tests to verify your migration:

```bash
# Test individual agents
pytest tests/agents/test_monitor_agent.py -v

# Test full workflow
pytest tests/workflows/test_end_to_end.py -v

# Test with your code
pytest tests/test_my_migration.py -v
```

## Common Issues

### Issue: "ModuleNotFoundError: No module named 'agentic_ai_platform'"

**Solution**: Ensure you've installed the package:
```bash
pip install -e .
```

### Issue: "AttributeError: 'MonitorAgent' object has no attribute 'agent_id'"

**Solution**: The new BaseAgent initializes agent_id. Ensure you call `super().__init__()`:
```python
class MyAgent(BaseAgent):
    def __init__(self):
        super().__init__(agent_id="MY", agent_type="custom")
```

### Issue: "KeyError: 'enriched_alert' in result"

**Solution**: All agents now use the new `process()` interface. Wrap data in a dictionary:
```python
# Old
result = monitor.receive_alert(alert)

# New
result = monitor.process(alert)  # Returns dict with "enriched_alert" key
```

## Questions?

- See [docs/](./docs/) for more information
- Check [tests/](./tests/) for working examples
- Open an [Issue](https://github.com/your-org/agentic-ai-platform/issues)
