# Quick Start Guide

## 5 Minutes to Your First Alert Processing

### Step 1: Install

```bash
cd agentic-ai-platform
pip install -e "."
```

### Step 2: Configure

```bash
cp .env .env.local
# Edit .env.local and add your MISTRAL_API_KEY
```

### Step 3: Run a Simple Example

Create `test_alert.py`:

```python
from agentic_ai_platform.orchestration import AgentOrchestrator
from agentic_ai_platform.mcp import MCPClient

# Initialize
mcp = MCPClient()
kb = {"incident_history": []}
orchestrator = AgentOrchestrator(mcp, kb)

# Process alert
alert = {
    "alert": "high_cpu",
    "server": "prod-db-01",
    "cpu_percent": 92,
    "severity": "critical"
}

result = orchestrator.process_alert(alert)
print(f"Status: {result['success']}")
print(f"Diagnosis: {result['diagnosis'].root_cause}")
```

```bash
python test_alert.py
```

## Common Tasks

### Configure LLM Provider

```python
from agentic_ai_platform.core import AppConfig, set_config

config = AppConfig(
    llm={
        "provider": "openai",
        "model": "gpt-4",
        "api_key": "sk-...",
    }
)
set_config(config)
```

### Add Custom Agent

```python
from agentic_ai_platform.agents.base import BaseAgent

class CustomAgent(BaseAgent):
    def __init__(self):
        super().__init__(agent_id="CUST", agent_type="custom")

    def process(self, data):
        # Your logic here
        return {"result": "success"}
```

### Enable Vector DB

```python
from agentic_ai_platform.core import AppConfig, set_config

config = AppConfig(
    vector_db={
        "provider": "pinecone",
        "endpoint": "your-endpoint",
        "api_key": "your-key",
    }
)
set_config(config)
```

### Use with Production LLM

```python
from agentic_ai_platform.core import get_config

config = get_config()
# config.llm.temperature = 0.0 (for deterministic)
# config.llm.temperature = 0.7 (for creative)
# config.llm.max_tokens = 4000
```

## Troubleshooting

### Import Error: No module named 'agentic_ai_platform'

```bash
# Make sure you're in the right directory
cd agentic-ai-platform
# Reinstall in editable mode
pip install -e "."
```

### LLM API Key not found

```bash
# Make sure .env.local exists and has MISTRAL_API_KEY set
cat .env.local | grep MISTRAL_API_KEY
```

### MCP Server connection failed

Make sure MCP servers are running on configured ports (default: 8001-8005)

## Next Steps

- Read [README.md](./README.md) for full documentation
- Explore [examples/](./examples/) for more use cases
- Check [tests/](./tests/) for working code samples
- Join our [Discussions](https://github.com/your-org/agentic-ai-platform/discussions)
