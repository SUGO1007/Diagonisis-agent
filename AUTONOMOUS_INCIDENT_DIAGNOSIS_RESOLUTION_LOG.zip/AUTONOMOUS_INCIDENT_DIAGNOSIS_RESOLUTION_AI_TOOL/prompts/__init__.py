"""
Agent Prompts Module

This module provides system prompts for each specialized agent in the
Agentic AI Platform.

Prompts are defined as Python constants for easy modification and version control.

Usage:
    from agentic_ai_platform.prompts import load_prompt

    monitor_prompt = load_prompt("monitor_agent")
    # Use with LLM system message
"""

from .monitor_agent import MONITOR_AGENT_PROMPT
from .diagnosis_agent import DIAGNOSIS_AGENT_PROMPT
from .gathering_agent import GATHERING_AGENT_PROMPT
from .remediation_agent import REMEDIATION_AGENT_PROMPT
from .learner_agent import LEARNER_AGENT_PROMPT


def load_prompt(agent_name: str) -> str:
    """
    Load a system prompt for the specified agent.

    Args:
        agent_name: One of:
            - "monitor_agent"
            - "diagnosis_agent"
            - "gathering_agent"
            - "remediation_agent"
            - "learner_agent"

    Returns:
        System prompt as string

    Raises:
        ValueError: If agent_name is not recognized

    Example:
        >>> monitor_prompt = load_prompt("monitor_agent")
        >>> print(monitor_prompt[:100])
        You are the **MonitorAgent**...
    """

    prompts = {
        "monitor_agent": MONITOR_AGENT_PROMPT,
        "diagnosis_agent": DIAGNOSIS_AGENT_PROMPT,
        "gathering_agent": GATHERING_AGENT_PROMPT,
        "remediation_agent": REMEDIATION_AGENT_PROMPT,
        "learner_agent": LEARNER_AGENT_PROMPT,
    }

    if agent_name not in prompts:
        raise ValueError(
            f"Unknown agent: {agent_name}. "
            f"Valid agents: {list(prompts.keys())}"
        )

    return prompts[agent_name]


__all__ = [
    "load_prompt",
    "MONITOR_AGENT_PROMPT",
    "DIAGNOSIS_AGENT_PROMPT",
    "GATHERING_AGENT_PROMPT",
    "REMEDIATION_AGENT_PROMPT",
    "LEARNER_AGENT_PROMPT",
