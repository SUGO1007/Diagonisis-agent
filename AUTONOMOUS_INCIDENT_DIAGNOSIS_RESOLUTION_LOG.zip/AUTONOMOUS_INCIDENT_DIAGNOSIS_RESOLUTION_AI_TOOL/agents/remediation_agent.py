# ═══════════════════════════════════════════════════════════════
# Remediation Agent - Safe Execution with Rollback
# ═══════════════════════════════════════════════════════════════
"""
Remediation Agent: Executes fixes with safety checks and automatic rollback.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from datetime import datetime
import time

from .base_agent import BaseAgent
from agentic_ai_platform.core import generate_id, get_timestamp


@dataclass
class RemediationAction:
    """A single remediation action with rollback plan."""
    action_id: str
    action_type: str  # kill_process, restart_service, scale_up, rollback_deployment
    target: str  # server, service, pod
    parameters: dict
    pre_checks: List[str]
    post_checks: List[str]
    rollback_steps: List[str]
    timeout_seconds: int = 300
    requires_approval: bool = False
    timestamp: str = field(default_factory=get_timestamp)


@dataclass
class RemediationResult:
    """Result of a remediation action."""
    action_id: str
    success: bool
    execution_time_seconds: float
    pre_check_passed: bool
    post_check_passed: bool
    error_message: Optional[str]
    rollback_executed: bool
    state_before: dict
    state_after: dict


class RemediationAgent(BaseAgent):
    """
    Specialized agent for safe remediation execution.

    Responsibilities:
    1. Validate pre-conditions before executing
    2. Execute remediation actions via MCP tools
    3. Verify post-conditions after execution
    4. Automatic rollback on failure
    5. Track success/failure patterns
    """

    def __init__(self, mcp_client, knowledge_base: dict):
        super().__init__(agent_id=generate_id("REM"), agent_type="remediation")
        self.mcp = mcp_client
        self.kb = knowledge_base
        self.execution_history: List[RemediationResult] = []
        self.success_rate: Dict[str, dict] = {}

    def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Process a remediation request."""
        if "incident" not in data or "decision" not in data:
            self.update_state("failed", failed=1)
            raise ValueError("Missing incident or decision in input data")

        incident = data["incident"]
        decision = data["decision"]

        action = self.plan_remediation(incident, decision)
        result = self.execute_with_safety(action)

        output = {
            "remediation_result": result,
            "success": result.success,
        }

        if self.validate_output(output):
            self.update_state("completed", processed=1)
        else:
            self.update_state("failed", failed=1)

        return output

    def plan_remediation(self, incident: dict, decision: dict) -> RemediationAction:
        """
        Plan a remediation action with all safety checks.

        Returns RemediationAction with:
        - Pre-flight checks to validate
        - Main action to execute
        - Post-flight checks to verify
        - Rollback steps if action fails
        """
        action_type = decision.get("action", "unknown")

        if action_type == "kill_process":
            return RemediationAction(
                action_id=generate_id("REM"),
                action_type="kill_process",
                target=incident.get("server", "unknown"),
                parameters={
                    "pid": incident.get("pid"),
                    "signal": "SIGTERM",
                    "grace_period_seconds": 30,
                },
                pre_checks=[
                    "Verify process still exists",
                    "Check service tier allows auto-kill",
                    "Confirm no critical dependencies",
                    "Validate backup exists",
                ],
                post_checks=[
                    "CPU usage < 80%",
                    "No new error logs",
                    "Service still responsive",
                    "No cascading failures",
                ],
                rollback_steps=[
                    "Restart process from last known good state",
                    "Restore from backup",
                    "Alert on-call engineer",
                ],
                timeout_seconds=300,
                requires_approval=decision.get("requires_approval", False),
            )

        elif action_type == "restart_service":
            return RemediationAction(
                action_id=generate_id("REM"),
                action_type="restart_service",
                target=incident.get("service", "unknown"),
                parameters={
                    "strategy": "rolling",
                    "max_unavailable": "25%",
                },
                pre_checks=[
                    "Verify service health",
                    "Check load balancer status",
                    "Confirm sufficient capacity",
                ],
                post_checks=[
                    "All pods healthy",
                    "Traffic routing correctly",
                    "Error rate < 1%",
                ],
                rollback_steps=[
                    "Rollback to previous version",
                    "Scale up healthy instances",
                ],
                timeout_seconds=600,
            )

        else:
            # Generic action
            return RemediationAction(
                action_id=generate_id("REM"),
                action_type=action_type,
                target=incident.get("server", "unknown"),
                parameters=decision.get("parameters", {}),
                pre_checks=["Basic validation"],
                post_checks=["Verify remediation worked"],
                rollback_steps=["Restore previous state"],
                timeout_seconds=300,
                requires_approval=decision.get("requires_approval", False),
            )

    def execute_with_safety(self, action: RemediationAction) -> RemediationResult:
        """
        Execute remediation with full safety checks.

        Steps:
        1. Capture current state (for rollback)
        2. Run pre-flight checks
        3. Execute action (with timeout)
        4. Run post-flight checks
        5. If any check fails → automatic rollback
        """
        start_time = time.time()

        self.log_info(f"Executing remediation action: {action.action_id} ({action.action_type})")

        # Step 1: Capture state before
        state_before = self._capture_state(action.target)
        self.log_debug(f"State captured: CPU {state_before.get('cpu', 'N/A')}%")

        # Step 2: Pre-flight checks
        self.log_info(f"Running {len(action.pre_checks)} pre-flight checks...")
        pre_check_passed = self._run_checks(action.pre_checks, action.target)

        if not pre_check_passed:
            execution_time = time.time() - start_time
            result = RemediationResult(
                action_id=action.action_id,
                success=False,
                execution_time_seconds=execution_time,
                pre_check_passed=False,
                post_check_passed=False,
                error_message="Pre-flight checks failed",
                rollback_executed=False,
                state_before=state_before,
                state_after={},
            )
            self.log_error("Pre-flight checks failed")
            return result

        # Step 3: Execute main action
        self.log_info(f"Executing: {action.action_type} on {action.target}")
        try:
            if action.action_type == "kill_process":
                # Simulate process kill
                time.sleep(0.5)
                self.log_info(f"Process killed (PID: {action.parameters.get('pid')})")

            elif action.action_type == "restart_service":
                # Simulate rolling restart
                self.log_info(f"Strategy: {action.parameters.get('strategy')}")
                time.sleep(1)
                self.log_info(f"Service restarted successfully")

            else:
                # Generic action
                time.sleep(0.5)
                self.log_info(f"Action {action.action_type} executed")

        except Exception as e:
            self.log_error(f"Execution failed: {e}")
            self.log_info("Initiating automatic rollback...")
            self._execute_rollback(action.rollback_steps, state_before)

            execution_time = time.time() - start_time
            return RemediationResult(
                action_id=action.action_id,
                success=False,
                execution_time_seconds=execution_time,
                pre_check_passed=True,
                post_check_passed=False,
                error_message=str(e),
                rollback_executed=True,
                state_before=state_before,
                state_after=state_before,
            )

        # Step 4: Capture state after
        time.sleep(0.5)  # Wait for metrics to stabilize
        state_after = self._capture_state(action.target)

        # Step 5: Post-flight checks
        self.log_info(f"Running {len(action.post_checks)} post-flight checks...")
        post_check_passed = self._run_checks(action.post_checks, action.target)

        execution_time = time.time() - start_time

        if not post_check_passed:
            self.log_warning("Post-flight checks failed — executing rollback...")
            self._execute_rollback(action.rollback_steps, state_before)

            result = RemediationResult(
                action_id=action.action_id,
                success=False,
                execution_time_seconds=execution_time,
                pre_check_passed=True,
                post_check_passed=False,
                error_message="Post-flight validation failed",
                rollback_executed=True,
                state_before=state_before,
                state_after=state_after,
            )
        else:
            result = RemediationResult(
                action_id=action.action_id,
                success=True,
                execution_time_seconds=execution_time,
                pre_check_passed=True,
                post_check_passed=True,
                error_message=None,
                rollback_executed=False,
                state_before=state_before,
                state_after=state_after,
            )
            self.log_info(f"Remediation successful! Time: {execution_time:.1f}s")

        self.execution_history.append(result)
        self._update_success_rate(action.action_type, result.success)

        return result

    def _capture_state(self, target: str) -> dict:
        """Capture current state for rollback."""
        # In production: Query actual metrics
        return {
            "cpu": 98.5,
            "memory": 72.0,
            "processes": 145,
            "connections": 832,
            "timestamp": get_timestamp(),
        }

    def _run_checks(self, checks: List[str], target: str) -> bool:
        """Run validation checks."""
        for check in checks:
            self.log_debug(f"Check: {check}")
            time.sleep(0.2)  # Simulate check
        return True

    def _execute_rollback(self, rollback_steps: List[str], state_before: dict):
        """Execute rollback steps."""
        self.log_warning("ROLLBACK INITIATED")
        for step in rollback_steps:
            self.log_info(f"  • {step}")
            time.sleep(0.2)
        self.log_info("Rollback complete")

    def _update_success_rate(self, action_type: str, success: bool):
        """Track success rate by action type."""
        if action_type not in self.success_rate:
            self.success_rate[action_type] = {"success": 0, "total": 0}

        self.success_rate[action_type]["total"] += 1
        if success:
            self.success_rate[action_type]["success"] += 1

    def get_stats(self) -> dict:
        """Get remediation statistics."""
        return {
            "total_executions": len(self.execution_history),
            "success_count": sum(1 for r in self.execution_history if r.success),
            "rollback_count": sum(1 for r in self.execution_history if r.rollback_executed),
            "success_rate_by_type": {
                action: f"{stats['success']}/{stats['total']} ({100*stats['success']/max(stats['total'], 1):.1f}%)"
                for action, stats in self.success_rate.items()
            },
        }
