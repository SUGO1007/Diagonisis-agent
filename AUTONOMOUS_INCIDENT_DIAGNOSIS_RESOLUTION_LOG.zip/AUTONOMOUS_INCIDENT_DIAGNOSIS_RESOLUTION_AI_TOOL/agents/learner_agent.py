# ═══════════════════════════════════════════════════════════════
# Learner Agent - Continuous Improvement from Human Feedback
# ═══════════════════════════════════════════════════════════════
"""
Learner Agent: Captures human feedback and improves system over time.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from datetime import datetime

from .base_agent import BaseAgent
from agentic_ai_platform.core import generate_id, get_timestamp


@dataclass
class HumanFeedback:
    """Human feedback on an incident resolution."""
    incident_id: str
    feedback_type: str  # approve, reject, modify
    was_correct: bool
    better_action: Optional[str]
    reason: str
    expert_notes: str
    timestamp: str = field(default_factory=get_timestamp)


@dataclass
class LearnedPattern:
    """A pattern learned from incidents."""
    pattern_id: str
    trigger_conditions: dict
    root_cause: str
    recommended_action: str
    confidence_score: float
    times_seen: int
    times_successful: int
    source: str  # human_feedback, automated_learning
    created_at: str = field(default_factory=get_timestamp)
    updated_at: str = field(default_factory=get_timestamp)


class LearnerAgent(BaseAgent):
    """
    Specialized agent for continuous learning and improvement.

    Responsibilities:
    1. Capture human feedback on AI decisions
    2. Learn new patterns from approved fixes
    3. Update knowledge base with learned patterns
    4. Generate new runbooks from real incidents
    5. Improve incident detection rules
    6. Track learning metrics (precision, recall)
    """

    def __init__(self, knowledge_base: dict):
        super().__init__(agent_id=generate_id("LRN"), agent_type="learner")
        self.kb = knowledge_base
        self.feedback_history: List[HumanFeedback] = []
        self.learned_patterns: List[LearnedPattern] = []
        self.learning_metrics = {
            "total_feedback": 0,
            "approved": 0,
            "rejected": 0,
            "modified": 0,
            "new_patterns_learned": 0,
            "runbooks_generated": 0,
        }

    def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Process feedback data."""
        if "incident" not in data or "ai_decision" not in data or "human_decision" not in data:
            self.update_state("failed", failed=1)
            raise ValueError("Missing required feedback data")

        incident = data["incident"]
        ai_decision = data["ai_decision"]
        human_decision = data["human_decision"]
        expert_notes = data.get("expert_notes", "")

        feedback = self.capture_feedback(incident, ai_decision, human_decision, expert_notes)

        result = {
            "feedback": feedback,
            "patterns_learned": len(self.learned_patterns),
            "success": True,
        }

        if self.validate_output(result):
            self.update_state("completed", processed=1)
        else:
            self.update_state("failed", failed=1)

        return result

    def capture_feedback(self, incident: dict, ai_decision: dict,
                        human_decision: dict, expert_notes: str = "") -> HumanFeedback:
        """
        Capture human feedback on AI's decision.

        This is the core of human-in-the-loop learning.
        """
        self.update_state("processing")

        was_correct = ai_decision.get("action") == human_decision.get("action")

        if was_correct:
            feedback_type = "approve"
            self.log_info(f"AI decision APPROVED: {ai_decision.get('action')}")
        elif human_decision.get("action") != ai_decision.get("action"):
            feedback_type = "modify"
            self.log_info(f"AI decision MODIFIED: {ai_decision.get('action')} → {human_decision.get('action')}")
        else:
            feedback_type = "reject"
            self.log_warning(f"AI decision REJECTED")

        feedback = HumanFeedback(
            incident_id=incident.get("incident_id", "N/A"),
            feedback_type=feedback_type,
            was_correct=was_correct,
            better_action=human_decision.get("action") if not was_correct else None,
            reason=human_decision.get("reason", ""),
            expert_notes=expert_notes,
        )

        self.feedback_history.append(feedback)
        self.learning_metrics["total_feedback"] += 1
        self.learning_metrics[feedback_type] += 1

        # Learn from this feedback
        self._learn_from_feedback(incident, feedback, human_decision)

        return feedback

    def _learn_from_feedback(self, incident: dict, feedback: HumanFeedback,
                            human_decision: dict):
        """
        Extract learnable patterns from feedback.

        If human modified AI's decision, this is valuable training data!
        """
        if feedback.feedback_type in ["approve", "modify"]:
            pattern = self._extract_pattern(incident, feedback, human_decision)

            # Check if we've seen this pattern before
            existing = self._find_similar_pattern(pattern)

            if existing:
                # Update existing pattern
                existing.times_seen += 1
                if feedback.was_correct:
                    existing.times_successful += 1
                existing.confidence_score = existing.times_successful / existing.times_seen
                existing.updated_at = get_timestamp()
                self.log_info(f"Updated pattern: {existing.pattern_id} ({existing.confidence_score:.2%})")
            else:
                # Learn new pattern
                self.learned_patterns.append(pattern)
                self.learning_metrics["new_patterns_learned"] += 1
                self.log_info(f"New pattern learned: {pattern.pattern_id}")

    def _extract_pattern(self, incident: dict, feedback: HumanFeedback,
                        human_decision: dict) -> LearnedPattern:
        """Extract a learnable pattern from an incident."""
        # Identify key conditions that triggered this incident
        trigger_conditions = {
            "alert_type": incident.get("alert", "unknown"),
            "metric_threshold": incident.get("threshold", 0),
            "service_tier": incident.get("tier", "unknown"),
            "duration": incident.get("duration", "unknown"),
        }

        # Root cause (if human provided)
        root_cause = human_decision.get("root_cause", "Unknown")

        # Recommended action (what human chose)
        recommended_action = human_decision.get("action", "escalate")

        pattern = LearnedPattern(
            pattern_id=generate_id("LP"),
            trigger_conditions=trigger_conditions,
            root_cause=root_cause,
            recommended_action=recommended_action,
            confidence_score=1.0 if feedback.was_correct else 0.8,
            times_seen=1,
            times_successful=1 if feedback.was_correct else 0,
            source="human_feedback",
        )

        return pattern

    def _find_similar_pattern(self, pattern: LearnedPattern) -> Optional[LearnedPattern]:
        """Find similar existing pattern."""
        for existing in self.learned_patterns:
            # Simple similarity: same alert type and service tier
            if (existing.trigger_conditions.get("alert_type") ==
                pattern.trigger_conditions.get("alert_type") and
                existing.trigger_conditions.get("service_tier") ==
                pattern.trigger_conditions.get("service_tier")):
                return existing
        return None

    def generate_runbook_from_pattern(self, pattern: LearnedPattern) -> dict:
        """
        Generate a new runbook from a learned pattern.

        This creates reusable operational knowledge!
        """
        runbook = {
            "id": generate_id("RB"),
            "title": f"Auto-Generated: {pattern.root_cause}",
            "source": "ai_learned",
            "confidence": pattern.confidence_score,
            "times_validated": pattern.times_successful,
            "trigger_conditions": pattern.trigger_conditions,
            "diagnostic_steps": [
                f"Check {pattern.trigger_conditions.get('alert_type')} metrics",
                f"Identify affected service: {pattern.trigger_conditions.get('service_tier')} tier",
                "Verify service health and dependencies",
                "Check recent deployments and changes",
            ],
            "remediation_actions": [
                f"Execute: {pattern.recommended_action}",
                "Monitor for resolution",
                "Verify service health restored",
            ],
            "validation_checks": [
                "Metrics return to normal thresholds",
                "No new alerts generated",
                "Service responding to health checks",
            ],
            "rollback_procedure": [
                "If remediation fails, restore previous state",
                "Escalate to human engineer",
            ],
            "escalation_criteria": [
                f"If confidence < {pattern.confidence_score:.0%}",
                "If service tier is critical",
                "If multiple services affected",
            ],
        }

        self.learning_metrics["runbooks_generated"] += 1
        self.log_info(f"Runbook generated: {runbook['id']}, Confidence: {runbook['confidence']:.2%}")

        return runbook

    def update_knowledge_base(self):
        """
        Update the knowledge base with learned patterns.

        This makes the AI smarter over time!
        """
        self.log_info("Updating knowledge base with learned patterns...")

        # Add high-confidence patterns to incident history
        high_confidence_patterns = [p for p in self.learned_patterns if p.confidence_score >= 0.8]

        for pattern in high_confidence_patterns:
            # Add to incident history
            if "incident_history" not in self.kb:
                self.kb["incident_history"] = []

            incident_entry = {
                "incident_id": pattern.pattern_id,
                "root_cause": pattern.root_cause,
                "resolution": pattern.recommended_action,
                "confidence": pattern.confidence_score,
                "similar_to": list(pattern.trigger_conditions.values()),
                "learned_from": "human_feedback",
            }

            self.kb["incident_history"].append(incident_entry)

        self.log_info(f"Added {len(high_confidence_patterns)} patterns to knowledge base")

    def _get_approval_rate(self) -> float:
        """Calculate approval rate."""
        if self.learning_metrics["total_feedback"] == 0:
            return 0.0
        return self.learning_metrics["approved"] / self.learning_metrics["total_feedback"]

    def get_stats(self) -> dict:
        """Get learning statistics."""
        return {
            "total_feedback_collected": self.learning_metrics["total_feedback"],
            "approval_rate": f"{self._get_approval_rate():.1%}",
            "patterns_learned": len(self.learned_patterns),
            "high_confidence_patterns": len([p for p in self.learned_patterns if p.confidence_score >= 0.8]),
            "runbooks_generated": self.learning_metrics["runbooks_generated"],
            "feedback_breakdown": {
                "approved": self.learning_metrics["approved"],
                "modified": self.learning_metrics["modified"],
                "rejected": self.learning_metrics["rejected"],
            },
        }
