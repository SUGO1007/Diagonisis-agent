# ═══════════════════════════════════════════════════════════════
# Information Gathering Agent - ReAct Loop Implementation
# ═══════════════════════════════════════════════════════════════
"""
Information Gathering Agent: Iteratively gathers information using ReAct.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from datetime import datetime

from .base_agent import BaseAgent
from agentic_ai_platform.core import generate_id, get_timestamp, MAX_ITERATIONS, CONFIDENCE_THRESHOLDS


@dataclass
class GatheringIteration:
    """A single iteration in the ReAct gathering loop."""
    iteration: int
    question: str
    tool_called: str
    tool_args: dict
    result: str
    confidence_improvement: float
    timestamp: str = field(default_factory=get_timestamp)


class InformationGatheringAgent(BaseAgent):
    """
    ReAct loop agent that gathers information until confidence threshold is met.

    Responsibilities:
    1. Receive questions from DiagnosisAgent
    2. For each question, determine which MCP tool to call
    3. Execute tool and collect result
    4. Update diagnosis confidence with new information
    5. Loop until confidence >= threshold OR max iterations reached
    6. Return complete context for RemediationAgent
    """

    def __init__(self, mcp_client, max_iterations: int = None,
                 confidence_threshold: float = None):
        super().__init__(agent_id=generate_id("GATH"), agent_type="gathering")
        self.mcp = mcp_client
        self.max_iterations = max_iterations or MAX_ITERATIONS.get("gathering", 10)
        self.confidence_threshold = confidence_threshold or CONFIDENCE_THRESHOLDS.get("gathering", 0.85)
        self.total_iterations = 0

    def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Process gathering request."""
        if "diagnosis" not in data or "enriched_alert" not in data:
            self.update_state("failed", failed=1)
            raise ValueError("Missing diagnosis or enriched_alert in input data")

        diagnosis = data["diagnosis"]
        enriched_alert = data["enriched_alert"]

        gathering_result = self.gather_information(diagnosis, enriched_alert)

        result = {
            "gathering_result": gathering_result,
            "final_confidence": gathering_result["final_confidence"],
            "success": gathering_result["ready_for_remediation"],
        }

        if self.validate_output(result):
            self.update_state("completed", processed=1)
        else:
            self.update_state("failed", failed=1)

        return result

    def gather_information(self, diagnosis, enriched_alert) -> dict:
        """
        ReAct loop: Iteratively gather information until confident.

        Loop Structure:
        WHILE confidence < threshold AND iterations < max:
            1. REASON: Pick next question to answer
            2. ACT: Call appropriate MCP tool
            3. OBSERVE: Process result
            4. UPDATE: Recalculate confidence

        Returns:
            Complete context with all gathered information
        """
        self.update_state("processing")

        self.log_info(
            f"ReAct Loop: Initial confidence {diagnosis.confidence:.0%}, "
            f"Target {self.confidence_threshold:.0%}"
        )

        iterations = []
        current_confidence = diagnosis.confidence
        gathered_info = {}

        iteration_num = 0
        while (current_confidence < self.confidence_threshold and
               iteration_num < self.max_iterations and
               iteration_num < len(diagnosis.questions_to_answer)):

            iteration_num += 1
            self.total_iterations += 1

            question = diagnosis.questions_to_answer[iteration_num - 1]

            self.log_debug(f"Iteration #{iteration_num}: {question}")

            # REASON: Determine which tool to use
            tool_name, tool_args = self._select_tool(question, enriched_alert)
            self.log_debug(f"Action: Call {tool_name}")

            # ACT: Execute the tool
            result = self._execute_tool(tool_name, tool_args)
            self.log_debug(f"Result: {result[:100]}...")

            # OBSERVE: Process the result
            gathered_info[question] = result

            # UPDATE: Recalculate confidence
            confidence_improvement = self._calculate_confidence_improvement(result, question)
            current_confidence = min(current_confidence + confidence_improvement, 0.98)

            self.log_debug(f"Confidence: {current_confidence:.0%} (+{confidence_improvement:.0%})")

            iterations.append(GatheringIteration(
                iteration=iteration_num,
                question=question,
                tool_called=tool_name,
                tool_args=tool_args,
                result=result,
                confidence_improvement=confidence_improvement,
            ))

            if current_confidence >= self.confidence_threshold:
                self.log_info(f"Confidence threshold reached: {current_confidence:.0%}")
                break

        if current_confidence < self.confidence_threshold:
            self.log_warning(f"Max iterations reached. Final confidence: {current_confidence:.0%}")

        return {
            'iterations': iterations,
            'final_confidence': current_confidence,
            'gathered_info': gathered_info,
            'ready_for_remediation': current_confidence >= self.confidence_threshold,
        }

    def _select_tool(self, question: str, alert) -> tuple:
        """Determine which MCP tool to call based on the question."""
        question_lower = question.lower()

        if 'process' in question_lower and 'cpu' in question_lower:
            return ('get_process_list', {'host': alert.raw_alert.get('server', '')})

        elif 'latency' in question_lower or 'performance' in question_lower:
            return ('query_metrics', {
                'host': alert.raw_alert.get('server', ''),
                'metric': 'latency_p99',
                'range': '1h'
            })

        elif 'log' in question_lower or 'error' in question_lower:
            return ('get_application_logs', {
                'host': alert.raw_alert.get('server', ''),
                'level': 'ERROR',
                'last_n': 50
            })

        elif 'deployment' in question_lower or 'recent' in question_lower:
            return ('get_recent_changes', {
                'host': alert.raw_alert.get('server', ''),
                'timerange': '24h'
            })

        else:
            # Default: get telemetry
            return ('query_metrics', {
                'host': alert.raw_alert.get('server', ''),
                'metric': 'cpu_percent',
                'range': '2h'
            })

    def _execute_tool(self, tool_name: str, tool_args: dict) -> str:
        """Execute MCP tool and return result."""
        try:
            # Map tool names to MCP servers
            server_map = {
                'get_process_list': 'ssh-exec-mcp',
                'query_metrics': 'telemetry-mcp',
                'get_application_logs': 'telemetry-mcp',
                'get_recent_changes': 'cmdb-mcp',
            }

            server = server_map.get(tool_name, 'telemetry-mcp')
            result = self.mcp.call_tool(server, tool_name, tool_args)

            if 'content' in result:
                return result['content'][0].get('text', str(result))
            return str(result)

        except Exception as e:
            self.log_error(f"Tool execution failed: {tool_name}: {e}")
            return f"Error executing {tool_name}: {e}"

    def _calculate_confidence_improvement(self, result: str, question: str) -> float:
        """Calculate how much the new information improves confidence."""
        # Simplified heuristic - in production: use LLM to evaluate relevance

        if 'error' in result.lower() or 'fail' in result.lower():
            return 0.05  # Error info helps a bit

        if len(result) > 200:
            return 0.12  # Detailed result helps more

        if len(result) > 100:
            return 0.08

        return 0.05  # Minimal info

    def get_stats(self) -> dict:
        """Get gathering agent statistics."""
        return {
            "total_iterations": self.total_iterations,
            "max_iterations": self.max_iterations,
            "confidence_threshold": f"{self.confidence_threshold:.0%}",
        }
