# ═══════════════════════════════════════════════════════════════
# Base Agent Class for Multi-Agent AI System
# ═══════════════════════════════════════════════════════════════
"""
Abstract base class for all agents in the agentic AI platform.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, Optional
from datetime import datetime


@dataclass
class AgentState:
    """State information for an agent."""
    agent_id: str
    agent_type: str
    status: str  # idle, processing, completed, failed
    processed_items: int = 0
    failed_items: int = 0
    last_updated: str = ""

    def __post_init__(self):
        if not self.last_updated:
            self.last_updated = datetime.now().isoformat()


class BaseAgent(ABC):
    """
    Abstract base class for all agents.

    All agents should inherit from this class and implement the
    required abstract methods.

    Attributes:
        agent_id: Unique identifier for the agent
        agent_type: Type of agent (e.g., "monitor", "diagnosis", "remediation")
    """

    def __init__(self, agent_id: str, agent_type: str):
        """
        Initialize the base agent.

        Args:
            agent_id: Unique identifier for this agent
            agent_type: Type/role of this agent
        """
        self.agent_id = agent_id
        self.agent_type = agent_type
        self.state = AgentState(agent_id=agent_id, agent_type=agent_type, status="idle")
        self._setup_logging()

    def _setup_logging(self):
        """Setup logging for this agent."""
        from ..core.logging import LoggerFactory
        self.logger = LoggerFactory.get_logger(
            f"{self.agent_type}.{self.agent_id}"
        )

    @abstractmethod
    def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process data and return result.

        This method must be implemented by all subclasses.

        Args:
            data: Input data to process

        Returns:
            Processed output data
        """
        pass

    def validate_input(self, data: Dict[str, Any]) -> bool:
        """
        Validate input data before processing.

        Override this method to add custom validation logic.

        Args:
            data: Input data to validate

        Returns:
            True if valid, False otherwise
        """
        if not isinstance(data, dict):
            return False
        return True

    def validate_output(self, result: Dict[str, Any]) -> bool:
        """
        Validate output data after processing.

        Override this method to add custom validation logic.

        Args:
            result: Output data to validate

        Returns:
            True if valid, False otherwise
        """
        if not isinstance(result, dict):
            return False
        return True

    def update_state(self, status: str, processed: int = 0, failed: int = 0):
        """
        Update agent state.

        Args:
            status: Current status
            processed: Number of items processed
            failed: Number of items failed
        """
        self.state.status = status
        self.state.processed_items += processed
        self.state.failed_items += failed
        self.state.last_updated = datetime.now().isoformat()

    def get_state(self) -> AgentState:
        """Get current agent state."""
        return self.state

    def reset(self):
        """Reset agent state."""
        self.state = AgentState(
            agent_id=self.agent_id,
            agent_type=self.agent_type,
            status="idle"
        )

    def log_info(self, message: str):
        """Log info message."""
        self.logger.info(message)

    def log_warning(self, message: str):
        """Log warning message."""
        self.logger.warning(message)

    def log_error(self, message: str):
        """Log error message."""
        self.logger.error(message)

    def log_debug(self, message: str):
        """Log debug message."""
        self.logger.debug(message)

    def __repr__(self) -> str:
        return f"{self.agent_type}(id={self.agent_id}, status={self.state.status})"
