# ═══════════════════════════════════════════════════════════════
# Diagnosis Agent - Root Cause Analysis with Vector DB RAG
# ═══════════════════════════════════════════════════════════════
"""
Diagnosis Agent: Analyzes enriched alerts using Vector DB RAG.
Determines root cause with confidence scoring.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from datetime import datetime

from .base_agent import BaseAgent
from agentic_ai_platform.core import generate_id, get_timestamp, CONFIDENCE_THRESHOLDS


@dataclass
class Diagnosis:
    """Root cause diagnosis with confidence score."""
    diagnosis_id: str
    root_cause: str
    confidence: float
    evidence: List[str]
    similar_incidents: List[dict]
    recommended_actions: List[str]
    requires_more_info: bool
    questions_to_answer: List[str]
    timestamp: str = field(default_factory=get_timestamp)


class DiagnosisAgent(BaseAgent):
    """
    Diagnoses root cause using Vector DB RAG from INFRA OPS Knowledge Base.

    Responsibilities:
    1. Query Vector DB for similar historical incidents (RAG)
    2. Analyze symptoms and patterns
    3. Determine root cause with confidence score
    4. If confidence < threshold → request more information
    5. Provide recommended actions based on past resolutions
    """

    def __init__(self, knowledge_base: dict, confidence_threshold: float = None):
        super().__init__(agent_id=generate_id("DIAG"), agent_type="diagnosis")
        self.kb = knowledge_base
        self.confidence_threshold = confidence_threshold or CONFIDENCE_THRESHOLDS.get("diagnosis", 0.80)
        self.diagnoses_made = 0
        self.vector_db = None  # Simulated for POC

    def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Process an enriched alert."""
        if "enriched_alert" not in data:
            self.update_state("failed", failed=1)
            raise ValueError("Missing enriched_alert in input data")

        enriched_alert = data["enriched_alert"]
        diagnosis = self.diagnose(enriched_alert)

        result = {
            "diagnosis": diagnosis,
            "success": True,
        }

        if self.validate_output(result):
            self.update_state("completed", processed=1)
        else:
            self.update_state("failed", failed=1)

        return result

    def diagnose(self, enriched_alert) -> Diagnosis:
        """
        Perform root cause analysis using Vector DB RAG.

        Steps:
        1. Embed alert symptoms as vector
        2. Query Vector DB for similar past incidents (semantic search)
        3. Analyze patterns and determine root cause
        4. Calculate confidence score
        5. If low confidence, determine what additional info is needed
        """
        self.diagnoses_made += 1
        self.update_state("processing")

        self.log_info(f"Diagnosis #{self.diagnoses_made}: Alert {enriched_alert.alert_id}, Priority: {enriched_alert.priority}")

        # Step 1: Query Vector DB for similar incidents (RAG)
        similar_incidents = self._vector_db_search(enriched_alert)
        self.log_debug(f"Found {len(similar_incidents)} similar incidents")

        # Step 2: Analyze patterns
        root_cause, confidence, evidence = self._analyze_patterns(
            enriched_alert, similar_incidents
        )

        self.log_info(f"Root Cause: {root_cause}, Confidence: {confidence:.0%}")

        # Step 3: Determine if more info needed
        requires_more_info = confidence < self.confidence_threshold
        questions = []

        if requires_more_info:
            self.log_warning(f"Confidence below threshold ({self.confidence_threshold:.0%})")
            questions = self._generate_information_needs(enriched_alert, similar_incidents)
            self.log_debug(f"Generated {len(questions)} questions")
        else:
            self.log_info(f"High confidence diagnosis - Ready for remediation")

        # Step 4: Get recommended actions from similar incidents
        recommended_actions = self._get_recommended_actions(similar_incidents)

        diagnosis = Diagnosis(
            diagnosis_id=generate_id("DIAG"),
            root_cause=root_cause,
            confidence=confidence,
            evidence=evidence,
            similar_incidents=similar_incidents,
            recommended_actions=recommended_actions,
            requires_more_info=requires_more_info,
            questions_to_answer=questions,
        )

        return diagnosis

    def _vector_db_search(self, alert) -> List[dict]:
        """
        Semantic search in Vector DB for similar incidents.

        In production:
        1. Embed alert symptoms using embedding model
        2. Query vector DB (Pinecone, Weaviate, ChromaDB)
        3. Return top-k most similar incidents with cosine similarity scores

        For POC: Simulate with keyword matching from knowledge base
        """
        # Simulate vector similarity search
        symptoms = [
            alert.raw_alert.get('alert', ''),
            str(alert.raw_alert.get('cpu_percent', '')),
            alert.service_context.get('tier', ''),
        ]

        similar = []
        for incident in self.kb.get('incident_history', []):
            # Simple keyword matching (in production: cosine similarity of embeddings)
            match_score = 0
            for symptom in symptoms:
                if any(symptom.lower() in str(v).lower() for v in incident.get('similar_to', [])):
                    match_score += 0.3

            if match_score > 0:
                similar.append({
                    **incident,
                    'similarity_score': min(match_score, 0.95)
                })

        # Sort by similarity
        similar.sort(key=lambda x: x.get('similarity_score', 0), reverse=True)
        return similar[:3]  # Top 3

    def _analyze_patterns(self, alert, similar: List[dict]) -> tuple:
        """Analyze patterns to determine root cause and confidence."""

        if not similar:
            # No historical data - low confidence
            return (
                "Unknown - No similar incidents found",
                0.50,
                ["No historical pattern matches"]
            )

        # Analyze the most similar incident
        top_match = similar[0]
        root_cause = top_match.get('root_cause', 'Unknown')
        confidence = top_match.get('similarity_score', 0.50)

        # Increase confidence if multiple similar incidents agree
        if len(similar) >= 2 and similar[1].get('root_cause') == root_cause:
            confidence += 0.15

        if len(similar) >= 3 and similar[2].get('root_cause') == root_cause:
            confidence += 0.10

        confidence = min(confidence, 0.98)  # Cap at 98%

        evidence = [
            f"Matches incident {top_match.get('incident_id', 'N/A')} (similarity: {top_match.get('similarity_score', 0):.0%})",
            f"Service tier: {alert.service_context.get('tier', 'unknown')}",
            f"Metric: {alert.raw_alert.get('cpu_percent', 'N/A')}%",
        ]

        if len(similar) >= 2:
            evidence.append(f"Consistent with {len(similar)} historical resolutions")

        return root_cause, confidence, evidence

    def _generate_information_needs(self, alert, similar: List[dict]) -> List[str]:
        """
        Generate questions that need to be answered to improve confidence.

        This drives the ReAct loop in InformationGatheringAgent.
        """
        questions = []

        # Based on low confidence, determine what info we need
        if alert.raw_alert.get('cpu_percent', 0) > 90:
            questions.append("What process is consuming the most CPU?")
            questions.append("Is this a gradual increase or sudden spike?")
            questions.append("How long has the process been running?")

        if alert.service_context.get('tier') == 'critical':
            questions.append("What is the current request latency?")
            questions.append("Are there any recent deployments?")

        if len(similar) == 0:
            questions.append("Are there any error patterns in application logs?")
            questions.append("What is the network I/O status?")

        return questions

    def _get_recommended_actions(self, similar: List[dict]) -> List[str]:
        """Extract recommended actions from similar incidents."""
        actions = []
        for incident in similar:
            resolution = incident.get('resolution', '')
            if resolution and resolution not in actions:
                actions.append(resolution)

        return actions if actions else ["Escalate to human engineer"]

    def get_stats(self) -> dict:
        """Get diagnosis agent statistics."""
        return {
            "diagnoses_made": self.diagnoses_made,
            "confidence_threshold": f"{self.confidence_threshold:.0%}",
        }
