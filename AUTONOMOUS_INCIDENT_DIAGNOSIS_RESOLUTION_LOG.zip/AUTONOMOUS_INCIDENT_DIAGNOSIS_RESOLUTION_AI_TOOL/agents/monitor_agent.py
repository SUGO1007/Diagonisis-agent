# ═══════════════════════════════════════════════════════════════
# Monitor Agent - Alert Ingestion & Enrichment
# ═══════════════════════════════════════════════════════════════
"""
Monitor Agent: First agent in the pipeline.
Receives alerts and enriches them with context.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from datetime import datetime
import hashlib

from .base_agent import BaseAgent
from agentic_ai_platform.core import generate_id, get_timestamp


@dataclass
class EnrichedAlert:
    """Alert enriched with context from multiple sources."""
    alert_id: str
    raw_alert: dict
    server_context: dict
    service_context: dict
    historical_context: dict
    severity: str
    priority: str
    timestamp: str = field(default_factory=get_timestamp)


class MonitorAgent(BaseAgent):
    """
    First agent in the pipeline - receives alerts and enriches them.

    Responsibilities:
    1. Receive alerts from monitoring systems (Prometheus, Datadog, etc.)
    2. Enrich with server metadata (CMDB)
    3. Enrich with service context (dependencies, tier, owner)
    4. Add historical context (similar past incidents)
    5. Calculate priority based on blast radius
    6. Route to DiagnosisAgent
    """

    def __init__(self, mcp_client, knowledge_base: dict):
        super().__init__(agent_id=generate_id("MON"), agent_type="monitor")
        self.mcp = mcp_client
        self.kb = knowledge_base
        self.alerts_received = 0
        self.alerts_enriched = 0

    def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Process a raw alert."""
        if not self.validate_input(data):
            self.update_state("failed", failed=1)
            raise ValueError("Invalid alert data")

        enriched_alert = self.receive_alert(data)

        result = {
            "enriched_alert": enriched_alert,
            "success": True,
        }

        if self.validate_output(result):
            self.update_state("completed", processed=1)
        else:
            self.update_state("failed", failed=1)

        return result

    def receive_alert(self, raw_alert: dict) -> EnrichedAlert:
        """
        Receive and enrich alert with contextual information.

        This is the single entry point for all alerts.
        """
        self.alerts_received += 1
        self.update_state("processing")

        self.log_info(f"Alert Received #{self.alerts_received}: {raw_alert.get('alert', 'Unknown')}")

        # Step 1: Get server metadata from CMDB
        server_context = self._get_server_context(raw_alert.get('server', ''))

        # Step 2: Get service context
        service_context = self._get_service_context(raw_alert.get('server', ''))

        # Step 3: Get historical context (similar incidents)
        historical_context = self._get_historical_context(raw_alert)

        # Step 4: Calculate priority
        priority = self._calculate_priority(service_context, historical_context)

        enriched = EnrichedAlert(
            alert_id=generate_id("ALT"),
            raw_alert=raw_alert,
            server_context=server_context,
            service_context=service_context,
            historical_context=historical_context,
            severity=raw_alert.get('severity', 'warning'),
            priority=priority,
        )

        self.alerts_enriched += 1

        self.log_info(
            f"Alert enriched: {enriched.alert_id}, "
            f"Priority: {priority}, "
            f"Similar incidents: {len(historical_context.get('similar', []))}"
        )

        return enriched

    def _get_server_context(self, server: str) -> dict:
        """Get server metadata from CMDB."""
        # In production: Query actual CMDB
        return {
            "hostname": server,
            "datacenter": "us-east-1",
            "environment": "production",
            "os": "Ubuntu 22.04",
            "cpu_cores": 16,
            "memory_gb": 64,
        }

    def _get_service_context(self, server: str) -> dict:
        """Get service context and dependencies."""
        # In production: Query service registry
        return {
            "services": ["data-transform", "etl-pipeline"],
            "tier": "batch",
            "owner": "data-platform-team",
            "dependencies": ["postgres-db", "redis-cache"],
            "blast_radius": 2,  # Number of dependent services
        }

    def _get_historical_context(self, alert: dict) -> dict:
        """Query similar historical incidents."""
        # In production: Vector DB similarity search
        return {
            "similar": [
                {"incident_id": "INC-2024-0891", "resolution": "killed stuck process", "time_to_resolve": "5min"},
                {"incident_id": "INC-2024-0745", "resolution": "restarted service", "time_to_resolve": "3min"},
            ],
            "frequency": "Seen 3 times in last 30 days",
            "typical_resolution": "kill_process",
        }

    def _calculate_priority(self, service_context: dict, historical_context: dict) -> str:
        """Calculate incident priority."""
        tier = service_context.get('tier', 'unknown')
        blast_radius = service_context.get('blast_radius', 0)

        if tier == 'critical' or blast_radius > 5:
            return "P1"
        elif blast_radius > 2:
            return "P2"
        else:
            return "P3"

    def get_stats(self) -> dict:
        """Get monitor agent statistics."""
        return {
            "alerts_received": self.alerts_received,
            "alerts_enriched": self.alerts_enriched,
            "enrichment_rate": f"{100 * self.alerts_enriched / max(self.alerts_received, 1):.1f}%",
        }
