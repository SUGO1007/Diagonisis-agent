"""
LangGraph Node Functions for Incident Response Agents.

Each node represents an agent in the workflow. All agents use the Qwen model
via OpenAI-compatible API and interact with the simulated MCP server for
infrastructure operations.

Pattern: Similar to MCP-Airbnb-Agent but using LangGraph for orchestration.
"""

import json
import os
import sys
import importlib.util
import time
from typing import Dict, Any
from pathlib import Path

from openai import OpenAI

from .state import IncidentState

# Import RAG Vector Store (ChromaDB + sentence-transformers)
from rag.vector_store import RAGVectorStore

# Import MCP tool functions directly (simulated MCP server calls)
# We load the module by file path to avoid the mcp package __init__.py
# which has broken relative imports from the old scaffold code.
# In production, use MCPServerStdio (pydantic-ai) or mcp SDK over stdio.
_mcp_server_path = Path(__file__).parent.parent / "mcp" / "incident_mcp_server.py"
_spec = importlib.util.spec_from_file_location("incident_mcp_server", _mcp_server_path)
_mcp_module = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_mcp_module)

query_metrics = _mcp_module.query_metrics
get_application_logs = _mcp_module.get_application_logs
get_process_list = _mcp_module.get_process_list
kill_process = _mcp_module.kill_process
execute_command = _mcp_module.execute_command
get_server_metadata = _mcp_module.get_server_metadata
get_service_info = _mcp_module.get_service_info
get_recent_changes = _mcp_module.get_recent_changes
get_dependencies = _mcp_module.get_dependencies
check_service_health = _mcp_module.check_service_health
create_incident = _mcp_module.create_incident
send_notification = _mcp_module.send_notification
TOOL_REGISTRY = _mcp_module.TOOL_REGISTRY


# ===================================================================
# VECTOR DB (RAG) - ChromaDB + Sentence-Transformers
# ===================================================================

# Singleton vector store instance (loaded once, reused across nodes)
_vector_store: RAGVectorStore = None


def get_vector_store() -> RAGVectorStore:
    """Get or initialize the RAG vector store singleton."""
    global _vector_store
    if _vector_store is None:
        rag_dir = Path(__file__).parent.parent / "rag"
        _vector_store = RAGVectorStore(rag_dir=str(rag_dir))
        _vector_store.load_and_index()
    return _vector_store


# ===================================================================
# LLM CLIENT SETUP
# ===================================================================

def get_llm_client() -> OpenAI:
    """Get OpenAI-compatible client pointing to Qwen via vLLM."""
    base_url = os.environ.get("LLM_BASE_URL", "http://localhost:8000/v1")
    api_key = os.environ.get("LLM_API_KEY", "abc-123")
    return OpenAI(base_url=base_url, api_key=api_key)


def get_model_name() -> str:
    """Get model name for the Qwen model served by vLLM."""
    return os.environ.get("LLM_MODEL", "Qwen3-30B-A3B")


def call_llm(system_prompt: str, user_prompt: str, tools: list = None) -> dict:
    """
    Call the Qwen LLM via OpenAI-compatible API.

    Args:
        system_prompt: System instructions for the agent
        user_prompt: The user/task message
        tools: Optional list of tool definitions for function calling

    Returns:
        Dict with 'content' (text response) and optionally 'tool_calls'
    """
    client = get_llm_client()
    model = get_model_name()

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]

    kwargs = {
        "model": model,
        "messages": messages,
        "temperature": 0.1,
        "max_tokens": 2000,
    }

    if tools:
        kwargs["tools"] = tools
        kwargs["tool_choice"] = "auto"

    start_time = time.time()
    
    try:
        print(f"   [LLM] Calling {model}...", end="", flush=True)
        response = client.chat.completions.create(**kwargs)
        elapsed = time.time() - start_time
        
        message = response.choices[0].message

        result = {"content": message.content or "", "llm_success": True, "duration": elapsed}

        if message.tool_calls:
            result["tool_calls"] = [
                {
                    "name": tc.function.name,
                    "arguments": json.loads(tc.function.arguments),
                }
                for tc in message.tool_calls
            ]
        
        print(f" ✓ SUCCESS ({elapsed:.2f}s)")
        return result

    except Exception as e:
        elapsed = time.time() - start_time
        print(f" ✗ FAILED ({elapsed:.2f}s) - {str(e)[:80]}")
        return {"content": f"LLM Error: {str(e)}", "error": True, "llm_success": False, "duration": elapsed}


def execute_mcp_tool(tool_name: str, arguments: dict) -> dict:
    """
    Execute a simulated MCP tool call.

    This simulates the MCP stdio protocol by directly calling the tool functions.
    In production, this would use MCPServerStdio (pydantic-ai) or mcp SDK.
    """
    if tool_name not in TOOL_REGISTRY:
        return {"error": f"Unknown tool: {tool_name}"}

    func = TOOL_REGISTRY[tool_name]["function"]
    try:
        return func(**arguments)
    except Exception as e:
        return {"error": str(e)}


def get_tools_for_openai(tool_names: list = None) -> list:
    """Convert MCP tool registry to OpenAI function-calling format."""
    tools = []
    for name, info in TOOL_REGISTRY.items():
        if tool_names and name not in tool_names:
            continue

        properties = {}
        required = []
        for pname, pinfo in info["parameters"].items():
            prop_type = pinfo["type"]
            if prop_type == "integer":
                prop_type = "integer"
            else:
                prop_type = "string"
            properties[pname] = {
                "type": prop_type,
                "description": pinfo.get("description", ""),
            }
            if pinfo.get("required"):
                required.append(pname)

        tools.append({
            "type": "function",
            "function": {
                "name": name,
                "description": info["description"],
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    "required": required,
                },
            },
        })
    return tools


# ===================================================================
# NODE: MONITOR (Agent 1)
# ===================================================================

def monitor_node(state: IncidentState) -> dict:
    """
    Agent 1: Monitor - Alert Ingestion & Enrichment.

    Uses LLM to:
    - Analyze raw alert
    - Call MCP tools to enrich with server/service context
    - Set priority based on blast radius
    """
    raw_alert = state["raw_alert"]

    print(f"\n{'='*70}")
    print(f"[AGENT-1] MONITOR AGENT - Alert Ingestion & Enrichment")
    print(f"{'='*70}")
    print(f"\n[ALERT] Raw Alert: {raw_alert.get('alert', 'Unknown')} on {raw_alert.get('server', 'Unknown')}")

    # Step 1: Get server metadata via MCP
    server = raw_alert.get("server", "")
    server_metadata = execute_mcp_tool("get_server_metadata", {"hostname": server})
    print(f"[MCP] get_server_metadata({server}) -> datacenter: {server_metadata.get('metadata', {}).get('datacenter', 'N/A')}")

    # Step 2: Get service info via MCP
    service_info = {}
    service_name = raw_alert.get("service", "")
    if service_name:
        service_info = execute_mcp_tool("get_service_info", {"service_name": service_name})
        print(f"[MCP] get_service_info({service_name}) -> tier: {service_info.get('info', {}).get('tier', 'N/A')}")

    # Step 3: Get recent changes via MCP
    recent_changes = execute_mcp_tool("get_recent_changes", {"host": server})
    print(f"[MCP] get_recent_changes({server}) -> {recent_changes.get('total', 0)} changes found")

    # Step 4: Use LLM to analyze and set priority
    system_prompt = """You are a Monitor Agent in an incident response system.
Your job is to analyze raw alerts and enrich them with context to determine priority.

Given the raw alert and infrastructure context, determine:
1. Priority level (P1-Critical, P2-High, P3-Medium, P4-Low)
2. Blast radius (which services/users are affected)
3. Initial severity assessment

Respond in JSON format:
{
    "priority": "P1|P2|P3|P4",
    "blast_radius": "description of impact",
    "severity": "critical|high|medium|low",
    "summary": "brief enriched summary",
    "service_tier": "critical|standard|batch",
    "requires_immediate_attention": true/false
}"""

    user_prompt = f"""Analyze this alert and provide enrichment:

Raw Alert: {json.dumps(raw_alert, default=str)}
Server Metadata: {json.dumps(server_metadata, default=str)}
Service Info: {json.dumps(service_info, default=str)}
Recent Changes: {json.dumps(recent_changes, default=str)}
"""

    llm_response = call_llm(system_prompt, user_prompt)
    print(f"\n[LLM] Monitor Agent reasoning:")

    # Parse LLM response
    try:
        # Try to extract JSON from response
        content = llm_response.get("content", "{}")
        if "```json" in content:
            content = content.split("```json")[1].split("```")[0].strip()
        elif "```" in content:
            content = content.split("```")[1].split("```")[0].strip()
        enrichment = json.loads(content)
        print(f"   [RESPONSE] ✓ Using REAL LLM response (parsed successfully)")
    except (json.JSONDecodeError, IndexError) as e:
        # Fallback if LLM doesn't return valid JSON
        print(f"\n   {'='*66}")
        print(f"   ⚠️  WARNING: USING FALLBACK RESPONSE (Monitor Agent)")
        print(f"   {'='*66}")
        print(f"   Reason: JSON parsing failed - {type(e).__name__}")
        print(f"   LLM Response Preview: {llm_response.get('content', '')[:100]}...")
        print(f"   {'='*66}\n")
        enrichment = {
            "priority": "P2",
            "blast_radius": f"Server {server} and dependent services",
            "severity": raw_alert.get("severity", "warning"),
            "summary": f"High CPU alert on {server}",
            "service_tier": service_info.get("info", {}).get("tier", "standard"),
            "requires_immediate_attention": raw_alert.get("severity") == "critical",
        }

    enriched_alert = {
        **raw_alert,
        "server_metadata": server_metadata.get("metadata", {}),
        "service_info": service_info.get("info", {}),
        "recent_changes": recent_changes.get("changes", []),
        "priority": enrichment.get("priority", "P3"),
        "blast_radius": enrichment.get("blast_radius", ""),
        "enriched_severity": enrichment.get("severity", "medium"),
        "service_tier": enrichment.get("service_tier", "standard"),
        "requires_immediate_attention": enrichment.get("requires_immediate_attention", False),
        "enriched_summary": enrichment.get("summary", ""),
    }

    print(f"   Priority: {enriched_alert['priority']}")
    print(f"   Service Tier: {enriched_alert['service_tier']}")
    print(f"   Blast Radius: {enriched_alert['blast_radius']}")

    return {
        "enriched_alert": enriched_alert,
        "messages": state.get("messages", []) + [
            {"role": "monitor_agent", "content": json.dumps(enrichment, default=str)}
        ],
    }


# ===================================================================
# NODE: DIAGNOSE (Agent 2)
# ===================================================================

def diagnose_node(state: IncidentState) -> dict:
    """
    Agent 2: Diagnosis - Root Cause Analysis with Vector DB RAG.

    Uses LLM to:
    - Analyze enriched alert with full context
    - Simulate Vector DB RAG by providing knowledge base context
    - Determine root cause with confidence score
    """
    enriched_alert = state["enriched_alert"]

    print(f"\n{'='*70}")
    print(f"[AGENT-2] DIAGNOSIS AGENT - Root Cause Analysis (Vector DB RAG)")
    print(f"{'='*70}")

    # Step 1: REAL Vector DB RAG - semantic search over knowledge base
    rag_context = _vector_db_search(enriched_alert)
    print(f"\n[RAG] Vector DB search (ChromaDB + sentence-transformers):")
    print(f"   Query: \"{rag_context['query']}\"")
    print(f"   Incidents found: {len(rag_context['similar_incidents'])}")
    print(f"   Runbooks found: {len(rag_context['relevant_runbooks'])}")
    print(f"   Service info found: {len(rag_context['service_knowledge'])}")
    print(f"   Tool suggestions: {len(rag_context['tool_suggestions'])}")

    # Step 2: Get additional diagnostic data via MCP
    server = enriched_alert.get("server", "")
    logs = execute_mcp_tool("get_application_logs", {"host": server, "level": "ERROR"})
    metrics = execute_mcp_tool("query_metrics", {"host": server, "metric": "cpu_percent"})
    processes = execute_mcp_tool("get_process_list", {"host": server})
    print(f"[MCP] Gathered: {logs.get('total_matching', 0)} logs, metrics, {processes.get('process_count', 0)} processes")

    # Step 3: Use LLM for root cause analysis
    system_prompt = """You are a Diagnosis Agent specializing in root cause analysis for infrastructure incidents.
You have access to similar past incidents from a Vector DB (RAG), current metrics, logs, and process data.

Analyze all evidence and determine:
1. The most likely root cause
2. Your confidence level (0.0 to 1.0)
3. Evidence supporting your diagnosis
4. Recommended actions

If confidence < 0.85, identify what additional information would help.

Respond in JSON format:
{
    "root_cause": "description of root cause",
    "confidence": 0.XX,
    "evidence": ["evidence 1", "evidence 2", ...],
    "recommended_actions": ["action 1", "action 2", ...],
    "requires_more_info": true/false,
    "questions_to_investigate": ["question 1", "question 2", ...]
}"""

    user_prompt = f"""Diagnose this incident:

Enriched Alert: {json.dumps(enriched_alert, default=str)}

=== VECTOR DB RAG RESULTS ===

Similar Past Incidents (cosine similarity search):
{json.dumps(rag_context['similar_incidents'], indent=2, default=str)}

Relevant Runbooks:
{json.dumps(rag_context['relevant_runbooks'], indent=2, default=str)}

Service Knowledge:
{json.dumps(rag_context['service_knowledge'], indent=2, default=str)}

Suggested Tools (from tool knowledge base):
{json.dumps(rag_context['tool_suggestions'], indent=2, default=str)}

=== LIVE DATA (MCP) ===

Current Application Logs:
{json.dumps(logs.get('entries', []), indent=2, default=str)}

Current Metrics:
{json.dumps(metrics, indent=2, default=str)}

Running Processes (top CPU):
{json.dumps(processes.get('top_cpu', []), indent=2, default=str)}
"""

    llm_response = call_llm(system_prompt, user_prompt)
    print(f"\n[LLM] Diagnosis Agent reasoning:")

    # Parse LLM response
    try:
        content = llm_response.get("content", "{}")
        if "```json" in content:
            content = content.split("```json")[1].split("```")[0].strip()
        elif "```" in content:
            content = content.split("```")[1].split("```")[0].strip()
        diagnosis = json.loads(content)
        print(f"   [RESPONSE] ✓ Using REAL LLM response (parsed successfully)")
    except (json.JSONDecodeError, IndexError) as e:
        # Fallback diagnosis based on available data
        print(f"\n   {'='*66}")
        print(f"   ⚠️  WARNING: USING FALLBACK RESPONSE (Diagnosis Agent)")
        print(f"   {'='*66}")
        print(f"   Reason: JSON parsing failed - {type(e).__name__}")
        print(f"   LLM Success: {llm_response.get('llm_success', False)}")
        print(f"   LLM Duration: {llm_response.get('duration', 0):.2f}s")
        print(f"   LLM Response Preview: {llm_response.get('content', '')[:100]}...")
        print(f"   {'='*66}")
        print(f"   Using hardcoded fallback diagnosis:")
        print(f"   Root Cause: ETL batch job deadlock...")
        print(f"   {'='*66}\n")
        diagnosis = {
            "root_cause": "ETL batch job deadlock causing CPU saturation - process 5510 consuming 95%+ CPU for 47 minutes with connection pool exhaustion",
            "confidence": 0.72,
            "evidence": [
                "Process 5510 (etl_batch.py) using 95.2% CPU for 47 minutes",
                "Deadlock detected in ETL batch job logs",
                "Connection pool exhausted (50/50 connections)",
                "Recent deployment of data-transform v2.5.0 with new batch module",
                "Config change: batch_size increased from 1000 to 5000",
            ],
            "recommended_actions": ["kill_process 5510", "restart data-transform service", "revert batch_size config"],
            "requires_more_info": True,
            "questions_to_investigate": [
                "Is the deadlock affecting other services?",
                "What is the memory trend over the last hour?",
                "Are there similar issues on other batch hosts?",
            ],
        }

    confidence = float(diagnosis.get("confidence", 0.5))

    print(f"   Root Cause: {diagnosis.get('root_cause', 'Unknown')}")
    print(f"   Confidence: {confidence:.0%}")
    print(f"   Evidence: {len(diagnosis.get('evidence', []))} items")
    print(f"   Requires More Info: {diagnosis.get('requires_more_info', True)}")

    return {
        "diagnosis": diagnosis,
        "confidence": confidence,
        "messages": state.get("messages", []) + [
            {"role": "diagnosis_agent", "content": json.dumps(diagnosis, default=str)}
        ],
    }


def _vector_db_search(alert: dict) -> dict:
    """
    REAL Vector DB RAG search using ChromaDB + sentence-transformers.

    Performs multiple semantic searches across different knowledge categories:
    1. Similar incidents (for pattern matching)
    2. Relevant runbooks (for remediation guidance)
    3. Service knowledge (for context and policies)
    4. Tool suggestions (for which MCP tools to use)

    Args:
        alert: Enriched alert dict

    Returns:
        Dict with categorized search results and similarity scores
    """
    store = get_vector_store()

    # Build semantic query from alert context
    server = alert.get("server", "")
    service = alert.get("service", "")
    metric = alert.get("metric", "cpu_percent")
    severity = alert.get("severity", "")
    alert_type = alert.get("alert", "")

    # Primary query combining key alert signals
    primary_query = f"{alert_type} {metric} {service} {server} {severity}"

    # Enriched query for better semantic matching
    enriched_query = (
        f"High {metric.replace('_', ' ')} alert on {server} "
        f"service {service} severity {severity} "
        f"{alert.get('enriched_summary', '')}"
    )

    # 1. Search similar incidents
    incident_results = store.search_incidents(enriched_query, top_k=5)
    similar_incidents = [
        {
            "text": r["text"][:500],  # Truncate for LLM context window
            "title": r["metadata"].get("title", ""),
            "similarity_score": r["similarity_score"],
            "source": r["metadata"].get("source_file", ""),
        }
        for r in incident_results
    ]

    # 2. Search relevant runbooks
    runbook_query = f"{service} {alert_type} remediation runbook"
    runbook_results = store.search_runbooks(runbook_query, top_k=3)
    relevant_runbooks = [
        {
            "text": r["text"][:400],
            "title": r["metadata"].get("title", ""),
            "similarity_score": r["similarity_score"],
        }
        for r in runbook_results
    ]

    # 3. Search service knowledge
    service_query = f"{service} service tier owner dependencies"
    service_results = store.search_services(service_query, top_k=2)
    service_knowledge = [
        {
            "text": r["text"][:400],
            "title": r["metadata"].get("title", ""),
            "similarity_score": r["similarity_score"],
        }
        for r in service_results
    ]

    # 4. Search tool suggestions
    tool_query = f"diagnose {metric.replace('_', ' ')} {alert_type} investigate process"
    tool_results = store.search_tools(tool_query, top_k=3)
    tool_suggestions = [
        {
            "text": r["text"][:300],
            "title": r["metadata"].get("title", ""),
            "similarity_score": r["similarity_score"],
        }
        for r in tool_results
    ]

    return {
        "query": enriched_query[:100],
        "similar_incidents": similar_incidents,
        "relevant_runbooks": relevant_runbooks,
        "service_knowledge": service_knowledge,
        "tool_suggestions": tool_suggestions,
    }


# ===================================================================
# HELPER: Schema-Aware Tool Selection (RAG + LLM)
# ===================================================================

def _select_and_execute_tool_with_schema(
    query: str,
    context: Dict[str, Any],
    current_diagnosis: Dict[str, Any],
    gathered_info: Dict[str, Any],
) -> tuple[str, Dict[str, Any], bool, str]:
    """
    Use RAG + LLM to select a tool and auto-generate arguments.

    Args:
        query: What the agent wants to do
        context: Alert context (host, service, metric, etc.)
        current_diagnosis: Current diagnosis state
        gathered_info: Info gathered so far

    Returns:
        (tool_name, arguments, success, explanation)
    """
    from rag.vector_store import RAGVectorStore
    from rag.tool_schema_loader import validate_tool_arguments, get_tool_schema

    store = RAGVectorStore()

    # Step 1: Use RAG to find relevant tools and their schemas
    tool_info = store.get_tool_schema_and_args(query, context)

    if "error" in tool_info:
        return "", {}, False, tool_info["error"]

    tool_name = tool_info["tool_name"]
    schema = tool_info["schema"]
    required_params = tool_info["required_params"]
    suggested_args = tool_info["suggested_arguments"]
    schema_text = tool_info["schema_text"]

    # Step 2: Ask LLM to fill in remaining arguments based on schema
    llm_prompt = f"""You are selecting and configuring an infrastructure tool.

Tool Selected: {tool_name}
Similarity Score: {tool_info['similarity_score']:.2%}

Tool Schema:
{schema_text}

Context Available:
{json.dumps(context, indent=2, default=str)}

Current Diagnosis:
{json.dumps(current_diagnosis, indent=2, default=str)}

Suggest values for required parameters {required_params}.
For parameters with suggested values already available, confirm or adjust them.
For missing parameters, infer from context or use sensible defaults.

Respond in JSON format:
{{
  "reasoning": "Why these arguments make sense",
  "arguments": {{"param_name": "value", ...}}
}}"""

    try:
        response = call_llm(
            system_prompt="You are configuring tool arguments based on schema and context.",
            user_prompt=llm_prompt,
        )

        # Parse arguments from LLM response
        response_text = response.get("content", "{}")
        if "```json" in response_text:
            response_text = response_text.split("```json")[1].split("```")[0]

        response_json = json.loads(response_text)
        arguments = response_json.get("arguments", suggested_args)
        reasoning = response_json.get("reasoning", "")
        print(f"      [RESPONSE] ✓ LLM configured tool arguments")

    except Exception as e:
        # Fallback to suggested arguments
        print(f"      [⚠️  FALLBACK] Using suggested arguments ({type(e).__name__})")
        arguments = suggested_args
        reasoning = f"Using suggested arguments (LLM parse failed: {str(e)[:50]})"

    # Step 3: Validate arguments against schema
    is_valid, error_msg = validate_tool_arguments(tool_name, arguments)

    if not is_valid:
        return tool_name, arguments, False, f"Validation failed: {error_msg}"

    # Step 4: Execute the tool
    result = execute_mcp_tool(tool_name, arguments)
    success = result.get("success", True)

    explanation = f"Tool: {tool_name} | Args: {json.dumps(arguments)} | Reasoning: {reasoning}"

    return tool_name, arguments, success, explanation


# ===================================================================
# NODE: GATHER_INFO (Agent 3) - ReAct Loop
# ===================================================================

def gather_info_node(state: IncidentState) -> dict:
    """
    Agent 3: Information Gathering - ReAct Loop.

    Uses LLM in an iterative loop:
    REASON -> ACT (MCP tool call) -> OBSERVE -> UPDATE confidence
    Continues until confidence >= 85% or max iterations reached.
    """
    diagnosis = state["diagnosis"]
    enriched_alert = state["enriched_alert"]
    current_confidence = state["confidence"]

    print(f"\n{'='*70}")
    print(f"[AGENT-3] INFORMATION GATHERING AGENT - ReAct Loop")
    print(f"{'='*70}")
    print(f"\n[START] Initial confidence: {current_confidence:.0%}, Target: 85%")

    iterations = []
    gathered_info = {}
    max_iterations = 5
    target_confidence = 0.85

    for i in range(max_iterations):
        if current_confidence >= target_confidence:
            break

        # REASON: Ask LLM what to investigate next
        investigation_goal = f"""Current diagnosis: {diagnosis.get('root_cause', 'Unknown')}
Confidence: {current_confidence:.0%}
Server: {enriched_alert.get('server', '')}
Service: {enriched_alert.get('service', 'data-transform')}
Unanswered questions: {json.dumps(diagnosis.get('questions_to_investigate', []))}

What tool would best answer the remaining questions?"""

        print(f"\n   Iteration {i+1}/{max_iterations}:")
        print(f"      REASON: {investigation_goal[:100]}...")

        # ACT: Use RAG + LLM to select tool, generate arguments, and execute
        tool_name, tool_args, success, explanation = _select_and_execute_tool_with_schema(
            query=investigation_goal,
            context={
                "host": enriched_alert.get("server", "prod-web-01"),
                "service": enriched_alert.get("service", "data-transform"),
                "metric": enriched_alert.get("metric", "cpu_percent"),
                "level": "ERROR",
            },
            current_diagnosis=diagnosis,
            gathered_info=gathered_info,
        )

        if not success:
            print(f"      ACT FAILED: {explanation}")
            continue

        print(f"      ACT: {tool_name}({json.dumps(tool_args)})")

        # OBSERVE: Get the result (already executed in _select_and_execute_tool_with_schema)
        result = execute_mcp_tool(tool_name, tool_args)
        result_str = json.dumps(result, default=str)

        print(f"      OBSERVE: {result_str[:120]}...")

        gathered_info[f"iteration_{i+1}_{tool_name}"] = result

        # UPDATE confidence based on result
        confidence_boost = _calculate_confidence_boost(tool_name, result, diagnosis)
        current_confidence = min(current_confidence + confidence_boost, 0.98)

        print(f"      UPDATE: Confidence {current_confidence:.0%} (+{confidence_boost:.0%})")

        iterations.append({
            "iteration": i + 1,
            "tool": tool_name,
            "args": tool_args,
            "result_summary": result_str[:200],
            "confidence_after": current_confidence,
            "confidence_boost": confidence_boost,
        })

    print(f"\n[DONE] Final confidence: {current_confidence:.0%} after {len(iterations)} iterations")

    return {
        "confidence": current_confidence,
        "gathering_iterations": iterations,
        "gathered_info": gathered_info,
    }


def _calculate_confidence_boost(tool_name: str, result: dict, diagnosis: dict) -> float:
    """Calculate how much a tool result boosts confidence."""
    # Heuristic: certain tools provide more confidence than others
    boost_map = {
        "get_process_list": 0.06,
        "get_application_logs": 0.07,
        "query_metrics": 0.05,
        "execute_command": 0.04,
        "get_dependencies": 0.03,
        "check_service_health": 0.05,
        "get_recent_changes": 0.06,
    }
    base_boost = boost_map.get(tool_name, 0.03)

    # Extra boost if result confirms diagnosis
    result_str = json.dumps(result, default=str).lower()
    if "deadlock" in result_str or "cpu" in result_str or "error" in result_str:
        base_boost += 0.02

    return base_boost


def _get_fallback_tool(iteration: int, alert: dict) -> dict:
    """Get a fallback tool using RAG tool knowledge if LLM doesn't select one."""
    server = alert.get("server", "prod-web-07")
    service = alert.get("service", "data-transform")

    # Use RAG to suggest tools based on the investigation context
    try:
        store = get_vector_store()
        query = f"investigate {alert.get('alert', '')} {alert.get('metric', '')} {server}"
        tool_results = store.search_tools(query, top_k=5)

        # Map RAG results to actual tool calls
        rag_tools = []
        for r in tool_results:
            title = r["metadata"].get("title", "").lower()
            if "query_metrics" in title or "metrics" in r["text"][:100].lower():
                rag_tools.append({"name": "query_metrics", "args": {"host": server, "metric": "memory_percent"}})
            elif "process" in title or "process_list" in r["text"][:100].lower():
                rag_tools.append({"name": "get_process_list", "args": {"host": server}})
            elif "logs" in title or "application_logs" in r["text"][:100].lower():
                rag_tools.append({"name": "get_application_logs", "args": {"host": server, "level": "ERROR"}})
            elif "health" in title or "service_health" in r["text"][:100].lower():
                rag_tools.append({"name": "check_service_health", "args": {"service_name": service}})
            elif "dependencies" in title:
                rag_tools.append({"name": "get_dependencies", "args": {"service_name": service}})
            elif "changes" in title or "recent" in r["text"][:100].lower():
                rag_tools.append({"name": "get_recent_changes", "args": {"service": service}})

        if rag_tools:
            return rag_tools[iteration % len(rag_tools)]
    except Exception:
        pass

    # Static fallback if RAG fails
    fallback_sequence = [
        {"name": "query_metrics", "args": {"host": server, "metric": "memory_percent"}},
        {"name": "get_dependencies", "args": {"service_name": service}},
        {"name": "check_service_health", "args": {"service_name": service}},
        {"name": "execute_command", "args": {"host": server, "command": "uptime"}},
        {"name": "get_recent_changes", "args": {"service": service}},
    ]
    return fallback_sequence[iteration % len(fallback_sequence)]


# ===================================================================
# NODE: PLAN_REMEDIATION (Agent 4 - Planning Phase)
# ===================================================================

def plan_remediation_node(state: IncidentState) -> dict:
    """
    Agent 4: Plan Remediation.

    Uses LLM to create a safe remediation plan based on diagnosis.
    """
    diagnosis = state["diagnosis"]
    enriched_alert = state["enriched_alert"]
    confidence = state["confidence"]
    gathered_info = state.get("gathered_info", {})

    print(f"\n{'='*70}")
    print(f"[AGENT-4] REMEDIATION AGENT - Planning Phase")
    print(f"{'='*70}")

    system_prompt = """You are a Remediation Agent responsible for creating safe action plans.
Given the diagnosis and gathered evidence, create a remediation plan.

Consider:
- Service tier (critical services need human approval)
- Blast radius (don't make things worse)
- Rollback strategy (always have a way back)
- Pre-flight and post-flight checks

Respond in JSON format:
{
    "action": "kill_process|restart_service|scale_up|rollback_deployment|config_change",
    "target": {"host": "hostname", "pid": 1234, "service": "service-name"},
    "pre_checks": ["check 1", "check 2"],
    "post_checks": ["check 1", "check 2"],
    "rollback_plan": "description of rollback steps",
    "estimated_recovery_time_seconds": 300,
    "risk_level": "low|medium|high"
}"""

    user_prompt = f"""Create a remediation plan:

Diagnosis: {json.dumps(diagnosis, default=str)}
Confidence: {confidence:.0%}
Alert: {json.dumps(enriched_alert, default=str)}
Additional Evidence: {json.dumps(gathered_info, default=str)}
"""

    llm_response = call_llm(system_prompt, user_prompt)

    try:
        content = llm_response.get("content", "{}")
        if "```json" in content:
            content = content.split("```json")[1].split("```")[0].strip()
        elif "```" in content:
            content = content.split("```")[1].split("```")[0].strip()
        plan = json.loads(content)
        print(f"\n[RESPONSE] ✓ Using REAL LLM remediation plan")
    except (json.JSONDecodeError, IndexError) as e:
        print(f"\n   {'='*66}")
        print(f"   ⚠️  WARNING: USING FALLBACK RESPONSE (Remediation Agent)")
        print(f"   {'='*66}")
        print(f"   Reason: {type(e).__name__}")
        print(f"   Using hardcoded fallback plan: kill_process 5510")
        print(f"   {'='*66}\n")
        plan = {
            "action": "kill_process",
            "target": {
                "host": enriched_alert.get("server", "prod-web-07"),
                "pid": 5510,
                "service": "data-transform",
            },
            "pre_checks": [
                "Verify process still running and consuming CPU",
                "Confirm no critical transactions in progress",
                "Verify backup/checkpoint exists",
            ],
            "post_checks": [
                "CPU usage drops below 50%",
                "No new error logs within 60 seconds",
                "Service health check passes",
                "Dependent services unaffected",
            ],
            "rollback_plan": "Restart data-transform service from last checkpoint. If that fails, rollback deployment to v2.4.1",
            "estimated_recovery_time_seconds": 120,
            "risk_level": "low",
        }

    print(f"\n[PLAN] Remediation Plan:")
    print(f"   Action: {plan.get('action', 'unknown')}")
    print(f"   Target: {json.dumps(plan.get('target', {}))}")
    print(f"   Risk Level: {plan.get('risk_level', 'unknown')}")
    print(f"   Recovery Time: {plan.get('estimated_recovery_time_seconds', 0)}s")
    print(f"   Pre-checks: {len(plan.get('pre_checks', []))}")
    print(f"   Post-checks: {len(plan.get('post_checks', []))}")

    return {"remediation_plan": plan}


# ===================================================================
# NODE: CHECK_COMPLIANCE (Agent 4 - Compliance Phase)
# ===================================================================

def check_compliance_node(state: IncidentState) -> dict:
    """
    Agent 4: Check Compliance.

    Determines if human approval is needed based on service tier and risk.
    """
    remediation_plan = state["remediation_plan"]
    enriched_alert = state["enriched_alert"]

    print(f"\n{'='*70}")
    print(f"[AGENT-4] COMPLIANCE CHECK")
    print(f"{'='*70}")

    service_tier = enriched_alert.get("service_tier", "standard")
    risk_level = remediation_plan.get("risk_level", "medium")

    # Policy: Critical services always need approval
    # High-risk actions always need approval
    # Batch services with low risk = auto-approve
    needs_approval = (
        service_tier == "critical" or
        risk_level == "high" or
        (service_tier == "standard" and risk_level == "medium")
    )

    compliance_result = {
        "service_tier": service_tier,
        "risk_level": risk_level,
        "approval_needed": needs_approval,
        "policy_applied": f"tier={service_tier}, risk={risk_level}",
        "auto_remediate_allowed": not needs_approval,
    }

    if needs_approval:
        print(f"\n[COMPLIANCE] APPROVAL REQUIRED")
        print(f"   Service Tier: {service_tier}")
        print(f"   Risk Level: {risk_level}")
        print(f"   Policy: Human approval required for {service_tier}/{risk_level}")
    else:
        print(f"\n[COMPLIANCE] AUTO-REMEDIATION ALLOWED")
        print(f"   Service Tier: {service_tier}")
        print(f"   Risk Level: {risk_level}")
        print(f"   Policy: Auto-remediation permitted")

    return {
        "compliance_result": compliance_result,
        "approval_needed": needs_approval,
    }


# ===================================================================
# NODE: HUMAN_LOOP (Simulated Human Approval)
# ===================================================================

def human_loop_node(state: IncidentState) -> dict:
    """
    Human-in-the-Loop: Simulates waiting for human approval via Slack/Teams.

    In production, this would:
    - Send approval request to Slack/Teams
    - Wait for human response (with timeout)
    - Record the decision
    """
    remediation_plan = state["remediation_plan"]

    print(f"\n{'='*70}")
    print(f"[HUMAN LOOP] Awaiting Human Approval")
    print(f"{'='*70}")

    # Simulate sending notification
    notification = execute_mcp_tool("send_notification", {
        "channel": "slack",
        "message": f"Approval needed: {remediation_plan.get('action', 'unknown')} on {json.dumps(remediation_plan.get('target', {}))}",
        "severity": "high",
    })
    print(f"\n[NOTIFY] Sent to Slack: {notification.get('message', '')[:80]}")

    # Simulate human approval (auto-approve for POC)
    print(f"[APPROVAL] Simulating human review...")
    print(f"   Action: {remediation_plan.get('action')}")
    print(f"   Risk: {remediation_plan.get('risk_level')}")
    print(f"   [APPROVED] Engineer approved the action")

    return {"human_approval": "approved"}


# ===================================================================
# NODE: EXECUTE_FIX (Agent 4 - Execution Phase)
# ===================================================================

def execute_fix_node(state: IncidentState) -> dict:
    """
    Agent 4: Execute Fix.

    Performs the actual remediation with pre-checks, execution, and post-checks.
    Uses MCP tools for infrastructure operations.
    """
    remediation_plan = state["remediation_plan"]

    print(f"\n{'='*70}")
    print(f"[AGENT-4] REMEDIATION AGENT - Execution Phase")
    print(f"{'='*70}")

    target = remediation_plan.get("target", {})
    action = remediation_plan.get("action", "")
    host = target.get("host", "")

    # PRE-FLIGHT CHECKS
    print(f"\n[PRE-FLIGHT] Running pre-checks...")
    pre_check_results = []
    for check in remediation_plan.get("pre_checks", []):
        # Simulate pre-check passing
        pre_check_results.append({"check": check, "passed": True})
        print(f"   [OK] {check}")

    # EXECUTE ACTION via MCP
    print(f"\n[EXECUTE] Performing: {action}")
    execution_result = {}

    if action == "kill_process":
        pid = target.get("pid", 0)
        execution_result = execute_mcp_tool("kill_process", {
            "host": host, "pid": pid, "signal": "SIGTERM"
        })
        print(f"   [MCP] kill_process({host}, {pid}) -> {execution_result.get('message', '')}")

    elif action == "restart_service":
        service = target.get("service", "")
        execution_result = execute_mcp_tool("execute_command", {
            "host": host, "command": f"systemctl restart {service}"
        })
        print(f"   [MCP] restart {service} -> exit_code: {execution_result.get('exit_code', -1)}")

    elif action == "rollback_deployment":
        service = target.get("service", "")
        execution_result = execute_mcp_tool("execute_command", {
            "host": host, "command": f"kubectl rollback deployment/{service}"
        })
        print(f"   [MCP] rollback {service} -> exit_code: {execution_result.get('exit_code', -1)}")

    else:
        execution_result = execute_mcp_tool("execute_command", {
            "host": host, "command": f"# Execute: {action}"
        })

    # POST-FLIGHT CHECKS
    print(f"\n[POST-FLIGHT] Running post-checks...")
    post_check_results = []
    for check in remediation_plan.get("post_checks", []):
        post_check_results.append({"check": check, "passed": True})
        print(f"   [OK] {check}")

    result = {
        "success": execution_result.get("success", True),
        "action": action,
        "target": target,
        "pre_checks_passed": all(r["passed"] for r in pre_check_results),
        "post_checks_passed": all(r["passed"] for r in post_check_results),
        "execution_detail": execution_result,
        "rollback_available": True,
    }

    return {"execution_result": result}


# ===================================================================
# NODE: VALIDATE
# ===================================================================

def validate_node(state: IncidentState) -> dict:
    """
    Agent 4: Validate that the fix worked.

    Checks system metrics after remediation to confirm resolution.
    """
    execution_result = state["execution_result"]
    enriched_alert = state["enriched_alert"]

    print(f"\n{'='*70}")
    print(f"[VALIDATE] Checking fix effectiveness")
    print(f"{'='*70}")

    server = enriched_alert.get("server", "")

    # Check metrics after fix
    health = execute_mcp_tool("check_service_health", {
        "service_name": enriched_alert.get("service", "data-transform")
    })
    print(f"\n[MCP] Service health: {'HEALTHY' if health.get('healthy') else 'UNHEALTHY'}")

    # Use LLM to assess if fix was successful
    system_prompt = """You are validating whether a remediation action was successful.
Analyze the execution result and current system state.

Respond in JSON:
{
    "validation_passed": true/false,
    "status": "resolved|needs_rollback|needs_escalation",
    "reason": "explanation"
}"""

    user_prompt = f"""Validate remediation result:
Execution: {json.dumps(execution_result, default=str)}
Service Health: {json.dumps(health, default=str)}
"""

    llm_response = call_llm(system_prompt, user_prompt)

    try:
        content = llm_response.get("content", "{}")
        if "```json" in content:
            content = content.split("```json")[1].split("```")[0].strip()
        elif "```" in content:
            content = content.split("```")[1].split("```")[0].strip()
        validation = json.loads(content)
        print(f"   [RESPONSE] ✓ Using REAL LLM validation")
    except (json.JSONDecodeError, IndexError) as e:
        # Default: if execution was successful, validate as passed
        print(f"   [⚠️  FALLBACK] Using default validation ({type(e).__name__})")
        validation = {
            "validation_passed": execution_result.get("success", False),
            "status": "resolved" if execution_result.get("success") else "needs_rollback",
            "reason": "Post-checks passed and service health confirmed" if execution_result.get("success") else "Execution failed",
        }

    print(f"   Status: {validation.get('status', 'unknown')}")
    print(f"   Reason: {validation.get('reason', '')}")

    return {"validation_result": validation}


# ===================================================================
# NODE: RESOLVED
# ===================================================================

def resolved_node(state: IncidentState) -> dict:
    """Mark incident as resolved."""
    print(f"\n[RESOLVED] Incident successfully resolved!")
    return {"outcome": "resolved"}


# ===================================================================
# NODE: ROLLBACK
# ===================================================================

def rollback_node(state: IncidentState) -> dict:
    """
    Agent 4: Rollback - undo the remediation action.
    """
    remediation_plan = state["remediation_plan"]
    enriched_alert = state["enriched_alert"]

    print(f"\n{'='*70}")
    print(f"[ROLLBACK] Executing rollback")
    print(f"{'='*70}")

    rollback_plan = remediation_plan.get("rollback_plan", "Restart service from checkpoint")
    host = remediation_plan.get("target", {}).get("host", "")

    print(f"   Plan: {rollback_plan}")

    # Execute rollback via MCP
    result = execute_mcp_tool("execute_command", {
        "host": host,
        "command": f"# Rollback: {rollback_plan}",
    })
    print(f"   [MCP] Rollback executed: exit_code={result.get('exit_code', -1)}")

    return {"outcome": "rolled_back"}


# ===================================================================
# NODE: ESCALATE
# ===================================================================

def escalate_node(state: IncidentState) -> dict:
    """
    Escalate to on-call engineer when automated resolution fails.
    """
    diagnosis = state.get("diagnosis", {})
    confidence = state.get("confidence", 0)

    print(f"\n{'='*70}")
    print(f"[ESCALATE] Escalating to on-call engineer")
    print(f"{'='*70}")

    reason = ""
    if confidence < 0.85:
        reason = f"Confidence too low ({confidence:.0%}) after gathering - cannot proceed safely"
    else:
        reason = "Remediation failed and rollback may be needed"

    # Notify via MCP
    notification = execute_mcp_tool("send_notification", {
        "channel": "pagerduty",
        "message": f"ESCALATION: {reason}. Diagnosis: {diagnosis.get('root_cause', 'Unknown')}",
        "severity": "critical",
    })

    # Create incident ticket
    incident = execute_mcp_tool("create_incident", {
        "title": f"Escalated: {diagnosis.get('root_cause', 'Unknown issue')}",
        "severity": "high",
        "service": state.get("enriched_alert", {}).get("service", "unknown"),
        "description": reason,
    })

    print(f"   Reason: {reason}")
    print(f"   Incident: {incident.get('incident_id', 'N/A')}")
    print(f"   Notified: PagerDuty on-call")

    return {
        "outcome": "escalated",
        "escalation_reason": reason,
    }


# ===================================================================
# NODE: NOTIFY (for escalations)
# ===================================================================

def notify_node(state: IncidentState) -> dict:
    """Send final notification for escalated incidents."""
    print(f"\n[NOTIFY] Final notification sent to on-call team")
    return {}


# ===================================================================
# NODE: LEARN_AND_CLOSE (Agent 5)
# ===================================================================

def learn_and_close_node(state: IncidentState) -> dict:
    """
    Agent 5: Learn & Close.

    Uses LLM to:
    - Analyze the full incident timeline
    - Extract patterns for future incidents
    - Generate/update runbook
    - Store in Vector DB for future RAG
    """
    diagnosis = state["diagnosis"]
    execution_result = state.get("execution_result", {})
    outcome = state.get("outcome", "resolved")
    gathering_iterations = state.get("gathering_iterations", [])

    print(f"\n{'='*70}")
    print(f"[AGENT-5] LEARNER AGENT - Learn & Close")
    print(f"{'='*70}")

    system_prompt = """You are a Learner Agent that analyzes completed incidents to extract patterns and improve future responses.

Given the full incident timeline, provide:
1. A pattern that can be stored for future detection
2. Runbook update suggestions
3. What worked well and what could be improved

Respond in JSON:
{
    "pattern": {
        "trigger": "description of what triggered this",
        "root_cause_category": "category",
        "resolution_action": "what fixed it",
        "confidence_score": 0.XX,
        "detection_signal": "what to look for next time"
    },
    "runbook_update": "suggested runbook entry",
    "lessons_learned": ["lesson 1", "lesson 2"],
    "automation_suggestion": "how to prevent/auto-fix next time"
}"""

    user_prompt = f"""Analyze this completed incident:

Diagnosis: {json.dumps(diagnosis, default=str)}
Outcome: {outcome}
Execution Result: {json.dumps(execution_result, default=str)}
Gathering Iterations: {len(gathering_iterations)}
"""

    llm_response = call_llm(system_prompt, user_prompt)

    try:
        content = llm_response.get("content", "{}")
        if "```json" in content:
            content = content.split("```json")[1].split("```")[0].strip()
        elif "```" in content:
            content = content.split("```")[1].split("```")[0].strip()
        learning = json.loads(content)
        print(f"\n[RESPONSE] ✓ Using REAL LLM learning pattern")
    except (json.JSONDecodeError, IndexError) as e:
        print(f"\n   {'='*66}")
        print(f"   ⚠️  WARNING: USING FALLBACK RESPONSE (Learner Agent)")
        print(f"   {'='*66}")
        print(f"   Reason: {type(e).__name__}")
        print(f"   Using hardcoded fallback learning pattern")
        print(f"   {'='*66}\n")
        learning = {
            "pattern": {
                "trigger": "High CPU + ETL batch job + recent deployment",
                "root_cause_category": "resource_exhaustion",
                "resolution_action": "kill_runaway_process + config_revert",
                "confidence_score": 0.92,
                "detection_signal": "CPU > 90% for > 30min on batch hosts after deployment",
            },
            "runbook_update": "For ETL batch CPU spikes: Check recent config changes (batch_size), kill PID if runtime > 30min, revert config if batch_size was changed",
            "lessons_learned": [
                "Config changes to batch_size should have CPU guardrails",
                "ETL jobs need timeout enforcement",
                "Recent deployment correlation was key signal",
            ],
            "automation_suggestion": "Add auto-kill for ETL processes exceeding 30min runtime with CPU > 90%",
        }

    print(f"\n[LEARN] Pattern extracted:")
    print(f"   Trigger: {learning.get('pattern', {}).get('trigger', 'N/A')}")
    print(f"   Category: {learning.get('pattern', {}).get('root_cause_category', 'N/A')}")
    print(f"   Confidence: {learning.get('pattern', {}).get('confidence_score', 0):.0%}")
    print(f"\n[RUNBOOK] Update: {learning.get('runbook_update', 'N/A')[:100]}")
    print(f"\n[CLOSE] Incident closed. Pattern stored in Vector DB for future RAG.")

    return {"learning_result": learning}


# ===================================================================
# ROUTING FUNCTIONS (Conditional Edges)
# ===================================================================

def route_after_diagnosis(state: IncidentState) -> str:
    """Route based on diagnosis confidence."""
    confidence = state.get("confidence", 0)
    if confidence >= 0.85:
        print(f"\n[ROUTE] Confidence {confidence:.0%} >= 85% -> Skip gathering, proceed to remediation")
        return "plan_remediation"
    else:
        print(f"\n[ROUTE] Confidence {confidence:.0%} < 85% -> Need more information")
        return "gather_info"


def route_after_gathering(state: IncidentState) -> str:
    """Route based on post-gathering confidence."""
    confidence = state.get("confidence", 0)
    if confidence >= 0.85:
        print(f"\n[ROUTE] Post-gathering confidence {confidence:.0%} >= 85% -> Proceed to remediation")
        return "plan_remediation"
    else:
        print(f"\n[ROUTE] Post-gathering confidence {confidence:.0%} < 85% -> Escalate")
        return "escalate"


def route_after_compliance(state: IncidentState) -> str:
    """Route based on compliance check."""
    if state.get("approval_needed", False):
        return "human_loop"
    else:
        return "execute_fix"


def route_after_validation(state: IncidentState) -> str:
    """Route based on validation result."""
    validation = state.get("validation_result", {})
    status = validation.get("status", "needs_escalation")

    if status == "resolved":
        return "resolved"
    elif status == "needs_rollback":
        return "rollback"
    else:
        return "escalate"
