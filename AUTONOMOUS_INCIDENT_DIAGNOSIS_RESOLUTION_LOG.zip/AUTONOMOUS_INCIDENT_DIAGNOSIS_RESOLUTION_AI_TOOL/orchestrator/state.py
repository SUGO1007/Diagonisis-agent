"""
LangGraph State Schema for Incident Response Workflow.

Defines the shared state that flows through all nodes in the graph.
"""

from typing import TypedDict, List, Dict, Any, Optional, Annotated
from enum import Enum


class IncidentOutcome(str, Enum):
    """Possible outcomes for an incident."""
    PENDING = "pending"
    RESOLVED = "resolved"
    ESCALATED = "escalated"
    ROLLED_BACK = "rolled_back"


class IncidentState(TypedDict):
    """
    Shared state for the LangGraph incident response workflow.

    This state is passed through all nodes and updated at each step.
    Matches the Graph_flow 2.txt architecture.
    """
    # Input
    raw_alert: Dict[str, Any]

    # Agent 1: Monitor
    enriched_alert: Dict[str, Any]

    # Agent 2: Diagnosis
    diagnosis: Dict[str, Any]
    confidence: float

    # Agent 3: Information Gathering (ReAct)
    gathering_iterations: List[Dict[str, Any]]
    gathered_info: Dict[str, Any]

    # Agent 4: Remediation
    remediation_plan: Dict[str, Any]
    compliance_result: Dict[str, Any]
    approval_needed: bool
    human_approval: Optional[str]  # "approved" / "denied" / None
    execution_result: Dict[str, Any]
    validation_result: Dict[str, Any]

    # Agent 5: Learning
    learning_result: Dict[str, Any]

    # Final
    outcome: str
    escalation_reason: str

    # LLM Messages (for agent reasoning traces)
    messages: List[Dict[str, str]]
