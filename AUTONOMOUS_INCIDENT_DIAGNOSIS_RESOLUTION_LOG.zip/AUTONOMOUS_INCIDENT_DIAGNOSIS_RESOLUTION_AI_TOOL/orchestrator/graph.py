"""
LangGraph Workflow Definition for Incident Response.

This module defines the StateGraph that orchestrates the multi-agent
incident response pipeline following the architecture in Graph_flow 2.txt.

Graph Structure:
    START -> monitor -> diagnose -> [confidence check]
        -> gather_info (if < 85%) -> [confidence check]
            -> escalate (if still < 85%)
            -> plan_remediation (if >= 85%)
        -> plan_remediation (if >= 85%) -> check_compliance -> [approval check]
            -> human_loop (if approval needed) -> execute_fix
            -> execute_fix (if auto-approved)
        -> execute_fix -> validate -> [validation check]
            -> resolved -> learn_and_close -> END
            -> rollback -> learn_and_close -> END
            -> escalate -> notify -> END
"""

from langgraph.graph import StateGraph, END

from .state import IncidentState
from .nodes import (
    # Agent nodes
    monitor_node,
    diagnose_node,
    gather_info_node,
    plan_remediation_node,
    check_compliance_node,
    human_loop_node,
    execute_fix_node,
    validate_node,
    resolved_node,
    rollback_node,
    escalate_node,
    notify_node,
    learn_and_close_node,
    # Routing functions
    route_after_diagnosis,
    route_after_gathering,
    route_after_compliance,
    route_after_validation,
)


def build_incident_response_graph() -> StateGraph:
    """
    Build the LangGraph StateGraph for incident response.

    Returns a compiled graph ready to be invoked with an initial state.
    """

    # Create the graph with our state schema
    workflow = StateGraph(IncidentState)

    # ===================================================================
    # ADD NODES (each node is an agent function)
    # ===================================================================

    workflow.add_node("monitor", monitor_node)
    workflow.add_node("diagnose", diagnose_node)
    workflow.add_node("gather_info", gather_info_node)
    workflow.add_node("plan_remediation", plan_remediation_node)
    workflow.add_node("check_compliance", check_compliance_node)
    workflow.add_node("human_loop", human_loop_node)
    workflow.add_node("execute_fix", execute_fix_node)
    workflow.add_node("validate", validate_node)
    workflow.add_node("resolved", resolved_node)
    workflow.add_node("rollback", rollback_node)
    workflow.add_node("escalate", escalate_node)
    workflow.add_node("notify", notify_node)
    workflow.add_node("learn_and_close", learn_and_close_node)

    # ===================================================================
    # ADD EDGES (define the flow)
    # ===================================================================

    # START -> monitor
    workflow.set_entry_point("monitor")

    # monitor -> diagnose
    workflow.add_edge("monitor", "diagnose")

    # diagnose -> conditional (confidence check)
    workflow.add_conditional_edges(
        "diagnose",
        route_after_diagnosis,
        {
            "gather_info": "gather_info",
            "plan_remediation": "plan_remediation",
        },
    )

    # gather_info -> conditional (post-gathering confidence check)
    workflow.add_conditional_edges(
        "gather_info",
        route_after_gathering,
        {
            "plan_remediation": "plan_remediation",
            "escalate": "escalate",
        },
    )

    # plan_remediation -> check_compliance
    workflow.add_edge("plan_remediation", "check_compliance")

    # check_compliance -> conditional (approval check)
    workflow.add_conditional_edges(
        "check_compliance",
        route_after_compliance,
        {
            "human_loop": "human_loop",
            "execute_fix": "execute_fix",
        },
    )

    # human_loop -> execute_fix
    workflow.add_edge("human_loop", "execute_fix")

    # execute_fix -> validate
    workflow.add_edge("execute_fix", "validate")

    # validate -> conditional (validation result)
    workflow.add_conditional_edges(
        "validate",
        route_after_validation,
        {
            "resolved": "resolved",
            "rollback": "rollback",
            "escalate": "escalate",
        },
    )

    # resolved -> learn_and_close
    workflow.add_edge("resolved", "learn_and_close")

    # rollback -> learn_and_close
    workflow.add_edge("rollback", "learn_and_close")

    # learn_and_close -> END
    workflow.add_edge("learn_and_close", END)

    # escalate -> notify -> END
    workflow.add_edge("escalate", "notify")
    workflow.add_edge("notify", END)

    return workflow.compile()


def visualize_graph():
    """Print the graph structure for debugging."""
    print("""
    LangGraph Incident Response Workflow
    =====================================

                        [START]
                           |
                           v
                       MONITOR (Agent 1)
                           |
                           v
                       DIAGNOSE (Agent 2)
                           |
                    [confidence check]
                     /              \\
                < 85%              >= 85%
                  /                    \\
          GATHER_INFO (Agent 3)    PLAN_REMEDIATION (Agent 4)
                  |                    |
           [confidence check]     CHECK_COMPLIANCE
            /          \\              |
         < 85%       >= 85%     [approval check]
           |             \\        /           \\
        ESCALATE    PLAN_REMEDIATION   HUMAN_LOOP
           |                  |              |
        NOTIFY          EXECUTE_FIX <--------'
           |                  |
          END             VALIDATE
                             |
                    [validation check]
                   /       |        \\
              resolved  rollback  escalate
                 |         |         |
             RESOLVED  ROLLBACK   ESCALATE
                 |         |         |
              LEARN     LEARN     NOTIFY
                 |         |         |
                END       END       END
    """)
