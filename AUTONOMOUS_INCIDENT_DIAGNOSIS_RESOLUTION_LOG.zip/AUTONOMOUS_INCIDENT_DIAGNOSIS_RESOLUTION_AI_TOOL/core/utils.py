# ═══════════════════════════════════════════════════════════════
# Utility Functions for Multi-Agent AI System
# ═══════════════════════════════════════════════════════════════
"""
Common utility functions for the agentic AI platform.
"""

import hashlib
import uuid
import json
from datetime import datetime
from typing import Any, Dict, List, Optional


def generate_id(prefix: str = "") -> str:
    """
    Generate a unique ID with optional prefix.

    Args:
        prefix: Prefix for the ID (e.g., "ALT", "DIAG", "REM")

    Returns:
        Unique ID (e.g., ALT-a1b2c3d4)
    """
    unique_part = str(uuid.uuid4())[:8].upper()
    if prefix:
        return f"{prefix}-{unique_part}"
    return unique_part


def hash_dict(data: Dict) -> str:
    """
    Generate a hash from a dictionary.

    Args:
        data: Dictionary to hash

    Returns:
        MD5 hash hexdigest
    """
    json_str = json.dumps(data, sort_keys=True)
    return hashlib.md5(json_str.encode()).hexdigest()


def hash_string(text: str) -> str:
    """
    Generate a hash from a string.

    Args:
        text: String to hash

    Returns:
        MD5 hash hexdigest
    """
    return hashlib.md5(text.encode()).hexdigest()


def get_timestamp() -> str:
    """
    Get current timestamp in ISO format.

    Returns:
        ISO format timestamp (e.g., 2024-01-15T10:30:45.123456)
    """
    return datetime.now().isoformat()


def truncate_string(text: str, max_length: int = 100, suffix: str = "...") -> str:
    """
    Truncate a string to a maximum length.

    Args:
        text: String to truncate
        max_length: Maximum length
        suffix: Suffix to add if truncated

    Returns:
        Truncated string
    """
    if len(text) <= max_length:
        return text

    return text[:max_length - len(suffix)] + suffix


def format_percentage(value: float, decimals: int = 1) -> str:
    """
    Format a value as a percentage.

    Args:
        value: Value between 0 and 1
        decimals: Number of decimal places

    Returns:
        Formatted percentage (e.g., "85.5%")
    """
    return f"{value * 100:.{decimals}f}%"


def merge_dicts(base: Dict, override: Dict) -> Dict:
    """
    Deep merge two dictionaries.

    Args:
        base: Base dictionary
        override: Dictionary to merge in

    Returns:
        Merged dictionary
    """
    result = base.copy()
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = merge_dicts(result[key], value)
        else:
            result[key] = value
    return result


def extract_error_message(error: Exception) -> str:
    """
    Extract a clean error message from an exception.

    Args:
        error: Exception instance

    Returns:
        Error message string
    """
    if str(error):
        return str(error)
    return error.__class__.__name__


def retry_with_backoff(func, max_retries: int = 3,
                       initial_backoff: float = 1.0,
                       backoff_multiplier: float = 2.0) -> Any:
    """
    Retry a function with exponential backoff.

    Args:
        func: Function to retry
        max_retries: Maximum number of retries
        initial_backoff: Initial backoff in seconds
        backoff_multiplier: Multiplier for exponential backoff

    Returns:
        Result from the function

    Raises:
        The last exception if all retries fail
    """
    import time

    last_exception = None
    backoff = initial_backoff

    for attempt in range(max_retries):
        try:
            return func()
        except Exception as e:
            last_exception = e
            if attempt < max_retries - 1:
                time.sleep(backoff)
                backoff *= backoff_multiplier

    if last_exception:
        raise last_exception


def safe_get(data: Dict, path: str, default: Any = None) -> Any:
    """
    Safely get a nested value from a dictionary using dot notation.

    Args:
        data: Dictionary to get from
        path: Dot-separated path (e.g., "server.cpu.percent")
        default: Default value if path not found

    Returns:
        Value at path or default

    Example:
        >>> safe_get({"a": {"b": {"c": 42}}}, "a.b.c")
        42
    """
    keys = path.split(".")
    current = data

    for key in keys:
        if isinstance(current, dict) and key in current:
            current = current[key]
        else:
            return default

    return current


def safe_set(data: Dict, path: str, value: Any) -> Dict:
    """
    Safely set a nested value in a dictionary using dot notation.

    Args:
        data: Dictionary to set in
        path: Dot-separated path (e.g., "server.cpu.percent")
        value: Value to set

    Returns:
        Modified dictionary

    Example:
        >>> safe_set({}, "a.b.c", 42)
        {"a": {"b": {"c": 42}}}
    """
    keys = path.split(".")
    current = data

    for key in keys[:-1]:
        if key not in current:
            current[key] = {}
        current = current[key]

    current[keys[-1]] = value
    return data


class RateLimiter:
    """Simple token bucket rate limiter."""

    def __init__(self, tokens_per_second: float = 10.0):
        self.tokens_per_second = tokens_per_second
        self.tokens = tokens_per_second
        self.last_update = datetime.now()

    def allow(self) -> bool:
        """Check if an operation is allowed."""
        now = datetime.now()
        elapsed = (now - self.last_update).total_seconds()

        self.tokens = min(
            self.tokens_per_second,
            self.tokens + elapsed * self.tokens_per_second
        )
        self.last_update = now

        if self.tokens >= 1:
            self.tokens -= 1
            return True

        return False
