# ═══════════════════════════════════════════════════════════════
# Core Module - Configuration, Logging, Utilities
# ═══════════════════════════════════════════════════════════════
"""
Core module providing configuration management, logging, exceptions,
utilities, and constants for the agentic AI platform.
"""

from .config import (
    AppConfig,
    ConfigManager,
    get_config,
    set_config,
)
from .exceptions import (
    AgenticAIException,
    ConfigurationError,
    MCPError,
    MCPConnectionError,
    MCPToolError,
    MCPTimeoutError,
    AgentError,
    DiagnosisError,
    InformationGatheringError,
    RemediationError,
    RemediationFailed,
    RemediationRolledBack,
    PreChecksFailed,
    PostChecksFailed,
    LearnerError,
    KnowledgeBaseError,
    VectorDBError,
    ValidationError,
    UnauthorizedError,
    TimeoutError,
)
from .logging import LoggerFactory, setup_logging
from .utils import (
    generate_id,
    hash_dict,
    hash_string,
    get_timestamp,
    truncate_string,
    format_percentage,
    merge_dicts,
    extract_error_message,
    retry_with_backoff,
    safe_get,
    safe_set,
    RateLimiter,
)
from .constants import (
    CONFIDENCE_THRESHOLDS,
    MAX_ITERATIONS,
    TIMEOUTS,
    SERVICE_TIERS,
    PRIORITY_LEVELS,
    MCP_SERVER_TOOLS,
    FEEDBACK_TYPES,
    LEARNING_THRESHOLDS,
    LOG_LEVELS,
    DEFAULTS,
)

__all__ = [
    # Config
    "AppConfig",
    "ConfigManager",
    "get_config",
    "set_config",
    # Exceptions
    "AgenticAIException",
    "ConfigurationError",
    "MCPError",
    "MCPConnectionError",
    "MCPToolError",
    "MCPTimeoutError",
    "AgentError",
    "DiagnosisError",
    "InformationGatheringError",
    "RemediationError",
    "RemediationFailed",
    "RemediationRolledBack",
    "PreChecksFailed",
    "PostChecksFailed",
    "LearnerError",
    "KnowledgeBaseError",
    "VectorDBError",
    "ValidationError",
    "UnauthorizedError",
    "TimeoutError",
    # Logging
    "LoggerFactory",
    "setup_logging",
    # Utils
    "generate_id",
    "hash_dict",
    "hash_string",
    "get_timestamp",
    "truncate_string",
    "format_percentage",
    "merge_dicts",
    "extract_error_message",
    "retry_with_backoff",
    "safe_get",
    "safe_set",
    "RateLimiter",
    # Constants
    "CONFIDENCE_THRESHOLDS",
    "MAX_ITERATIONS",
    "TIMEOUTS",
    "SERVICE_TIERS",
    "PRIORITY_LEVELS",
    "MCP_SERVER_TOOLS",
    "FEEDBACK_TYPES",
    "LEARNING_THRESHOLDS",
    "LOG_LEVELS",
    "DEFAULTS",
]
