# ═══════════════════════════════════════════════════════════════
# Logging Configuration for Multi-Agent AI System
# ═══════════════════════════════════════════════════════════════
"""
Centralized logging setup for the agentic AI platform.
"""

import logging
import logging.handlers
from typing import Optional
from pathlib import Path


class LoggerFactory:
    """Factory for creating and configuring loggers."""

    _loggers = {}

    @staticmethod
    def get_logger(name: str, level: str = "INFO",
                   log_file: Optional[str] = None) -> logging.Logger:
        """
        Get or create a logger with the given name.

        Args:
            name: Logger name (usually __name__ of the module)
            level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
            log_file: Optional file path for file logging

        Returns:
            Configured logger instance
        """
        if name in LoggerFactory._loggers:
            return LoggerFactory._loggers[name]

        logger = logging.getLogger(name)
        logger.setLevel(getattr(logging, level))

        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(getattr(logging, level))

        # Formatter
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)

        # File handler (optional)
        if log_file:
            Path(log_file).parent.mkdir(parents=True, exist_ok=True)
            file_handler = logging.handlers.RotatingFileHandler(
                log_file,
                maxBytes=10485760,  # 10MB
                backupCount=5
            )
            file_handler.setLevel(getattr(logging, level))
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)

        LoggerFactory._loggers[name] = logger
        return logger

    @staticmethod
    def configure_all(level: str = "INFO", log_file: Optional[str] = None):
        """Configure all existing loggers."""
        for logger_name in LoggerFactory._loggers:
            logger = LoggerFactory._loggers[logger_name]
            logger.setLevel(getattr(logging, level))

            for handler in logger.handlers:
                handler.setLevel(getattr(logging, level))


def setup_logging(level: str = "INFO", log_file: Optional[str] = None):
    """
    Setup logging for the application.

    Args:
        level: Log level
        log_file: Optional file path for file logging
    """
    LoggerFactory.get_logger("agentic_ai", level, log_file)
