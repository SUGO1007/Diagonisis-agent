# ═══════════════════════════════════════════════════════════════
# Core Constants for Multi-Agent AI System
# ═══════════════════════════════════════════════════════════════
"""
Global constants and configuration values for the agentic AI platform.
"""

# Agent Configuration
CONFIDENCE_THRESHOLDS = {
    "diagnosis": 0.80,  # Minimum confidence to proceed with gathering
    "gathering": 0.85,  # Minimum confidence to proceed with remediation
}

MAX_ITERATIONS = {
    "gathering": 10,  # Max ReAct loop iterations
    "tool_execution": 5,  # Max retries per tool call
}

TIMEOUTS = {
    "tool_execution": 30,  # seconds
    "remediation": 300,  # seconds
    "api_request": 10,  # seconds
}

# Service Tiers
SERVICE_TIERS = {
    "critical": {"max_recovery_time": 300, "requires_approval": True},  # 5 min
    "high": {"max_recovery_time": 600, "requires_approval": True},  # 10 min
    "standard": {"max_recovery_time": 1800, "requires_approval": False},  # 30 min
    "batch": {"max_recovery_time": 3600, "requires_approval": False},  # 1 hour
}

# Priority Levels
PRIORITY_LEVELS = {
    "P1": "Critical",
    "P2": "High",
    "P3": "Medium",
    "P4": "Low",
}

# MCP Server Mappings
MCP_SERVER_TOOLS = {
    "telemetry-mcp": [
        "query_metrics",
        "get_application_logs",
        "get_cpu_usage",
        "get_memory_usage",
    ],
    "ssh-exec-mcp": [
        "get_process_list",
        "kill_process",
        "execute_command",
        "get_system_info",
    ],
    "cmdb-mcp": [
        "get_server_metadata",
        "get_service_info",
        "get_recent_changes",
        "get_dependencies",
    ],
    "alerting-mcp": [
        "send_alert",
        "acknowledge_alert",
        "create_incident",
        "update_incident",
    ],
    "runbook-mcp": [
        "get_runbook",
        "execute_runbook",
        "list_runbooks",
        "validate_runbook",
    ],
}

# Feedback Types
FEEDBACK_TYPES = {
    "approve": "Human approved AI decision",
    "reject": "Human rejected AI decision",
    "modify": "Human modified AI decision",
}

# Learning Thresholds
LEARNING_THRESHOLDS = {
    "min_pattern_confidence": 0.80,  # Only learn high-confidence patterns
    "min_validation_count": 2,  # Pattern must be validated N times
    "approval_rate_for_autoremedy": 0.95,  # 95% approval rate to auto-execute
}

# Log Levels
LOG_LEVELS = {
    "DEBUG": 10,
    "INFO": 20,
    "WARNING": 30,
    "ERROR": 40,
    "CRITICAL": 50,
}

# Default values
DEFAULTS = {
    "max_retry_attempts": 3,
    "backoff_multiplier": 2,
    "initial_backoff": 1,  # seconds
    "vector_db_top_k": 3,  # Return top-3 similar incidents
    "incident_similarity_threshold": 0.7,  # Cosine similarity threshold
}
