# ═══════════════════════════════════════════════════════════════
# Custom Exceptions for Multi-Agent AI System
# ═══════════════════════════════════════════════════════════════
"""
Custom exception classes for the agentic AI platform.
"""


class AgenticAIException(Exception):
    """Base exception for all agentic AI errors."""
    pass


class ConfigurationError(AgenticAIException):
    """Raised when configuration is invalid or missing."""
    pass


class MCPError(AgenticAIException):
    """Base exception for MCP-related errors."""
    pass


class MCPConnectionError(MCPError):
    """Raised when MCP server connection fails."""
    pass


class MCPToolError(MCPError):
    """Raised when MCP tool execution fails."""
    pass


class MCPTimeoutError(MCPError):
    """Raised when MCP tool call times out."""
    pass


class AgentError(AgenticAIException):
    """Base exception for agent-related errors."""
    pass


class DiagnosisError(AgentError):
    """Raised when diagnosis fails or confidence is too low."""
    pass


class InformationGatheringError(AgentError):
    """Raised when information gathering fails."""
    pass


class RemediationError(AgentError):
    """Raised when remediation fails."""
    pass


class RemediationFailed(RemediationError):
    """Raised when remediation execution fails."""
    pass


class RemediationRolledBack(RemediationError):
    """Raised when remediation is automatically rolled back."""
    pass


class PreChecksFailed(RemediationError):
    """Raised when pre-flight checks fail."""
    pass


class PostChecksFailed(RemediationError):
    """Raised when post-flight checks fail."""
    pass


class LearnerError(AgentError):
    """Raised when learning process fails."""
    pass


class KnowledgeBaseError(AgenticAIException):
    """Raised when knowledge base operations fail."""
    pass


class VectorDBError(AgenticAIException):
    """Raised when vector database operations fail."""
    pass


class ValidationError(AgenticAIException):
    """Raised when data validation fails."""
    pass


class UnauthorizedError(AgenticAIException):
    """Raised when action requires approval but is not authorized."""
    pass


class TimeoutError(AgenticAIException):
    """Raised when operation exceeds timeout."""
    pass
