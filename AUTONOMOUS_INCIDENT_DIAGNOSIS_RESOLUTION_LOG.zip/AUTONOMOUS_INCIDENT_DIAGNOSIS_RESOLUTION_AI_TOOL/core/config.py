# ═══════════════════════════════════════════════════════════════
# Configuration Management for Multi-Agent AI System
# ═══════════════════════════════════════════════════════════════
"""
Configuration loader and manager for the agentic AI platform.
Supports environment variables and .env file loading.
"""

import os
from dataclasses import dataclass
from typing import Optional
from pathlib import Path


@dataclass
class MCPConfig:
    """MCP Server Configuration."""
    telemetry_host: str = "localhost"
    telemetry_port: int = 8001
    ssh_exec_host: str = "localhost"
    ssh_exec_port: int = 8002
    cmdb_host: str = "localhost"
    cmdb_port: int = 8003
    alerting_host: str = "localhost"
    alerting_port: int = 8004
    runbook_host: str = "localhost"
    runbook_port: int = 8005


@dataclass
class LLMConfig:
    """LLM Configuration."""
    provider: str = "mistral"  # mistral, openai, anthropic
    model: str = "mistral-large-latest"
    api_key: Optional[str] = None
    temperature: float = 0.1
    max_tokens: int = 2000
    timeout: int = 30


@dataclass
class VectorDBConfig:
    """Vector Database Configuration."""
    provider: str = "mock"  # mock, pinecone, weaviate, chromadb
    endpoint: Optional[str] = None
    api_key: Optional[str] = None
    index_name: str = "incidents"
    embedding_model: str = "all-MiniLM-L6-v2"
    similarity_threshold: float = 0.7


@dataclass
class AgentConfig:
    """Agent Configuration."""
    diagnosis_confidence_threshold: float = 0.80
    gathering_confidence_threshold: float = 0.85
    max_gathering_iterations: int = 10
    approval_required_tiers: list = None

    def __post_init__(self):
        if self.approval_required_tiers is None:
            self.approval_required_tiers = ["critical", "high"]


@dataclass
class LoggingConfig:
    """Logging Configuration."""
    level: str = "INFO"
    format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    log_file: Optional[str] = None
    enable_file_logging: bool = False
    max_bytes: int = 10485760  # 10MB
    backup_count: int = 5


@dataclass
class AppConfig:
    """Main Application Configuration."""
    app_name: str = "agentic-ai-platform"
    version: str = "1.0.0"
    environment: str = "development"  # development, staging, production
    debug: bool = False

    mcp: MCPConfig = None
    llm: LLMConfig = None
    vector_db: VectorDBConfig = None
    agent: AgentConfig = None
    logging: LoggingConfig = None

    def __post_init__(self):
        if self.mcp is None:
            self.mcp = MCPConfig()
        if self.llm is None:
            self.llm = LLMConfig()
        if self.vector_db is None:
            self.vector_db = VectorDBConfig()
        if self.agent is None:
            self.agent = AgentConfig()
        if self.logging is None:
            self.logging = LoggingConfig()


class ConfigManager:
    """
    Manages application configuration from environment variables and .env file.
    """

    @staticmethod
    def load_from_env() -> AppConfig:
        """Load configuration from environment variables."""

        # Load from .env file if it exists
        ConfigManager._load_env_file()

        config = AppConfig(
            app_name=os.getenv("APP_NAME", "agentic-ai-platform"),
            version=os.getenv("APP_VERSION", "1.0.0"),
            environment=os.getenv("ENVIRONMENT", "development"),
            debug=os.getenv("DEBUG", "false").lower() == "true",

            mcp=MCPConfig(
                telemetry_host=os.getenv("MCP_TELEMETRY_HOST", "localhost"),
                telemetry_port=int(os.getenv("MCP_TELEMETRY_PORT", 8001)),
                ssh_exec_host=os.getenv("MCP_SSH_HOST", "localhost"),
                ssh_exec_port=int(os.getenv("MCP_SSH_PORT", 8002)),
                cmdb_host=os.getenv("MCP_CMDB_HOST", "localhost"),
                cmdb_port=int(os.getenv("MCP_CMDB_PORT", 8003)),
                alerting_host=os.getenv("MCP_ALERTING_HOST", "localhost"),
                alerting_port=int(os.getenv("MCP_ALERTING_PORT", 8004)),
                runbook_host=os.getenv("MCP_RUNBOOK_HOST", "localhost"),
                runbook_port=int(os.getenv("MCP_RUNBOOK_PORT", 8005)),
            ),

            llm=LLMConfig(
                provider=os.getenv("LLM_PROVIDER", "mistral"),
                model=os.getenv("LLM_MODEL", "mistral-large-latest"),
                api_key=os.getenv("MISTRAL_API_KEY"),
                temperature=float(os.getenv("LLM_TEMPERATURE", 0.1)),
                max_tokens=int(os.getenv("LLM_MAX_TOKENS", 2000)),
                timeout=int(os.getenv("LLM_TIMEOUT", 30)),
            ),

            vector_db=VectorDBConfig(
                provider=os.getenv("VECTOR_DB_PROVIDER", "mock"),
                endpoint=os.getenv("VECTOR_DB_ENDPOINT"),
                api_key=os.getenv("VECTOR_DB_API_KEY"),
                index_name=os.getenv("VECTOR_DB_INDEX", "incidents"),
                embedding_model=os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2"),
                similarity_threshold=float(os.getenv("SIMILARITY_THRESHOLD", 0.7)),
            ),

            agent=AgentConfig(
                diagnosis_confidence_threshold=float(os.getenv("DIAGNOSIS_THRESHOLD", 0.80)),
                gathering_confidence_threshold=float(os.getenv("GATHERING_THRESHOLD", 0.85)),
                max_gathering_iterations=int(os.getenv("MAX_GATHERING_ITERATIONS", 10)),
                approval_required_tiers=os.getenv("APPROVAL_REQUIRED_TIERS", "critical,high").split(","),
            ),

            logging=LoggingConfig(
                level=os.getenv("LOG_LEVEL", "INFO"),
                log_file=os.getenv("LOG_FILE"),
                enable_file_logging=os.getenv("ENABLE_FILE_LOGGING", "false").lower() == "true",
                max_bytes=int(os.getenv("LOG_MAX_BYTES", 10485760)),
                backup_count=int(os.getenv("LOG_BACKUP_COUNT", 5)),
            ),
        )

        return config

    @staticmethod
    def _load_env_file(env_file: str = ".env"):
        """Load environment variables from .env file."""
        env_path = Path(env_file)

        if env_path.exists():
            with open(env_path) as f:
                for line in f:
                    line = line.strip()
                    # Skip comments and empty lines
                    if not line or line.startswith("#"):
                        continue

                    # Parse KEY=VALUE
                    if "=" in line:
                        key, value = line.split("=", 1)
                        os.environ[key.strip()] = value.strip().strip('"\'')

    @staticmethod
    def get_default_config() -> AppConfig:
        """Get default configuration."""
        return AppConfig()


# Global config instance
_config: Optional[AppConfig] = None


def get_config() -> AppConfig:
    """Get or load the global configuration."""
    global _config
    if _config is None:
        _config = ConfigManager.load_from_env()
    return _config


def set_config(config: AppConfig):
    """Set the global configuration."""
    global _config
    _config = config
